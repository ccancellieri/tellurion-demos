# Contributing to Tellurion

Thank you for your interest in Tellurion. Please read this page before opening
a pull request — it explains what can be accepted and why the bar exists.

## The short version

- **Bug reports, reproductions, and design discussion in issues: always
  welcome**, from anyone, no paperwork.
- **Code and documentation contributions are accepted only with a copyright
  assignment or an equivalent contributor license grant** (see below). A pull
  request opened without one cannot be merged, however good the code is, and
  will be closed with a pointer to this page.

## Why the assignment requirement exists

Tellurion is source-available under the [Business Source License 1.1](LICENSE)
and is commercially licensed by its author under a dual-licensing model. That
model works only while the licensor holds sufficient rights to every line in
the repository — it is what lets each version be sold commercially today and
convert to AGPL-3.0-only on its Change Date.

A contribution merged without a rights grant would be licensed to the project
only under the inbound license, which does not include the right to
re-license — and would therefore break the ability to sell commercial licenses
covering the whole work. This is not a hypothetical: it is the standard reason
dual-licensed projects (MySQL, MariaDB, Qt) require a CLA or assignment.

## How to contribute code

1. Open an issue first describing the change, and wait for the design to be
   agreed — this repository runs on decision records, and unsolicited large
   diffs are usually wasted work.
2. Include the following statement in the pull request description, from the
   account of the person who holds the rights to the contribution:

   > I assign to Carlo Cancellieri all right, title, and interest in the
   > copyright of this contribution, and I certify that I have the right to
   > make this assignment. I understand the contribution will be distributed
   > under the repository's LICENSE and may be commercially licensed by the
   > copyright holder.

3. Contributions authored in the course of employment need the employer's
   sign-off on the same statement.

If an assignment is not acceptable to you, that is a legitimate position —
please contribute in the form of issues, reproductions, and review comments
instead, which require no rights transfer and are genuinely valuable.

## Conduct

Be precise, be kind, and argue from evidence. Decision records and measured
numbers outrank opinion here — the issue history shows the house style.
