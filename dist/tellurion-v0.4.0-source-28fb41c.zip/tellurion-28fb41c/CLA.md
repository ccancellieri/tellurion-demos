# Contributor License Agreement

Tellurion 0.3.0 is distributed under BUSL-1.1 and may also be offered under commercial
terms. To preserve the copyright holder's ability to distribute contributions under
those terms and under a later Change License, the project must retain a single
copyright holder.

By submitting a contribution (pull request, patch, or any other material) you agree
that:

1. You are the sole author of the contribution and have the right to submit it.
2. You assign copyright in the contribution to Carlo Cancellieri, who may license it
   under BUSL-1.1, under commercial terms, under the applicable Change License, or
   under any other license.
3. Your contribution is provided without warranty of any kind.

If you cannot agree to these terms, please open an issue describing your proposed
change instead of submitting code.

This agreement is a project policy statement, not legal advice. Its assignment wording
requires qualified counsel review before it is relied on as an executed agreement.
