# Tellurion 0.4.0 licensing guide

Tellurion 0.4.0 is source-available under the [Business Source License 1.1](../LICENSE)
(`BUSL-1.1`). It is not open source before its Change Date, 2030-08-09. This guide is a
plain-language summary, not legal advice; the LICENSE and any executed commercial
agreement control.

This guide describes the terms for the public v0.4.0 release. Public
source and binary assets become available only after legal approval of that release.

## Before the Change Date

| Your use | What the terms allow |
|---|---|
| Evaluation, development, testing, training, or a time-bounded proof of concept that is not relied on for normal operations | Free non-production use |
| A natural person's personal, non-commercial production use | Free under the Additional Use Grant |
| Production use by or for a company, government, other organisation, or professional activity | Commercial licence required |

Production Use means use in normal business operations, internal operational services,
processing operational data, or providing functionality to customers or other third
parties. This explanation does not expand or replace the BUSL terms.

The BUSL permits you to view, copy, modify, create derivative works from, and
redistribute the Licensed Work subject to its terms. It does not prohibit copying as a
category.

## After the Change Date

On 2030-08-09, Tellurion 0.4.0 automatically converts to GNU Affero General Public
License Version 3 only (`AGPL-3.0-only`). Each later version has its own licence
parameters and Change Date.

## Commercial production use

Commercial rights are available only through a separate written agreement. To request
licensing information, use <https://github.com/ccancellieri>. The
[commercial licensing notice](../COMMERCIAL-LICENSE.md) explains the request path.

Tellurion 0.1.0 remains a historical AGPL-3.0-only release; rights granted for that
version remain with its recipients.
