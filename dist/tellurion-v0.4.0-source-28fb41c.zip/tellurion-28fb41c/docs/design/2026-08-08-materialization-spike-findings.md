# Materialization spike findings (#131): write-time H3 cells vs FlatGeobuf's packed R-tree

Status: answers issue #131's open question with measurements against real
data, in the mold of `2026-07-21-cell-index-spike-findings.md` (#103).
The materialization measured here was built to be thrown away; the only
tracked artifacts are this document and the inert harness under
`bench/spike-131-materialization/`.

## The question, and the recorded decision it followed

#103 settled PostGIS: GiST wins at every query size, no cell index there.
It deliberately left open the case the idea was for — drivers with no
spatial index and no geometry engine — and named FlatGeobuf as the right
first measurement *because* it is not the weakest case: every `.fgb` file
already carries a packed Hilbert R-tree, which `tellurion-flatgeobuf`
loads once and searches in memory.

The GeoID/DynaStore prior art recorded on #131 says the query-time
prefilter shape is already known to lose — the win, where it exists, comes
entirely from moving cell computation to write time. So this spike built
the **write-time materialization**: per-feature H3 coverings computed once
at ingest/write time into a sidecar keyed by the driver's feature-index
identity, measured against the R-tree the file already has, with a naive
full scan as the no-index control.

## Methodology

### Dataset

Real, unmodified OpenStreetMap data — Geofabrik's `italy/isole-latest.osm.pbf`
(the same regional sub-extract #103 used; resolved at download time to
`isole-260806.osm.pbf`, 213,406,736 bytes, MD5
`557c8e2a01dcf8c9a13941e4cbe13ec8`, matched against Geofabrik's own `.md5`
sidecar; ODbL, © OpenStreetMap contributors). Areas (closed ways +
multipolygon relations carrying area-ish tags, approximating GDAL's
`multipolygons` layer) were assembled with pyosmium: 2,125,260 qualifying
areas, stride-sampled 1-in-7 to reach the prior campaign-fixture scale:

- **large fixture: 303,609 features** — WGS84 MultiPolygons, written to a
  Hilbert-sorted, indexed FlatGeobuf (98,819,056 bytes) by the same
  `flatgeobuf` 6.0.1 / `geozero` 0.15.1 pins the tracked driver uses.
- **small fixture: 30,361 features** (every 10th of the large), 9,640,160
  bytes.

The real geometry-size skew survives the sampling: overwhelmingly small
building footprints with a long natural/landuse/boundary tail — 120
features of the large fixture (0.04%) trip the estimator fallback, the
same order as #103's 0.039%.

### The materialization

#103's exact cell parameters: H3 via `h3o` 0.10 (per #103's Q1 verdict),
res 9 primary, estimator-triggered res 6 fallback, 300-cell cap,
`ContainmentMode::Covers`. On top, the resolution ladder #103 called
required-not-optional: a res-6 parent pair set for every feature, so large
windows can match at res 6 instead of exploding a res-9 query covering.
The sidecar stores, keyed by the driver's own feature-index identity:
per-feature bbox, sorted `(cell, feature)` pair arrays for res-9 coverings,
res-6 fallback coverings, and the res-6 ladder. Binary search over a
sorted array is the file-sidecar analog of the B-tree the DynaStore prior
art uses.

One correctness finding worth keeping even though the verdict is negative:
**the covering must be of the feature's bbox, not its true geometry.** The
packed R-tree (and the OGC bbox filter the driver serves with it) answers
bbox-intersects. A geometry-true covering is a *tighter* filter — on real
data it dropped features whose bbox touches the window but whose geometry
does not (observed: 2 of 32 sampled windows differed by one feature each)
— which makes the two answer sets incomparable. With bbox coverings, the
prefilter's post-verification match set was **identical to the R-tree's at
every one of the 128 sampled windows across all runs** (verified, not
assumed). The parent-ladder path also needs a one-ring `grid_disk`
expansion of the query covering, because an H3 child can stick out of its
parent's geometric boundary.

Write-time cost, measured: **22.5 µs/feature** (6.9 s for 303,609
features, single-threaded), sidecar 18,296,064 bytes = **18.5% of the FGB
file's own size** (small fixture: 22.9 µs/feature, 1,818,740 bytes,
18.9%). For comparison, the FGB writer produced the entire file — packed
R-tree included — in 2.2 s.

### Contenders

Per query window, all returning the same answer (verified):

- **rtree** — the driver's real path: in-memory `PackedRTree::search`
  (the driver caches the tree at header warm-up), replicated from
  `crates/tellurion-flatgeobuf/src/driver.rs` against the same crate pins.
- **cells** — cover the window (res-9 path under an estimated 512 cells,
  res-6 ladder path above), binary-search the pair arrays, dedupe, verify
  candidates against the materialized bboxes.
- **bboxscan** — degenerate-materialization control: linear scan of the
  materialized per-feature bbox array (which is exactly what the R-tree's
  leaf level already stores).
- **decode100** — the shared page-decode pass (fresh open + `select_bbox`,
  first 100 features to GeoJSON), the driver's second pass; identical work
  for either indexed contender, reported separately so the contenders'
  difference is isolated to the match phase.
- **scan** — the honest no-index control: stream all features, decode
  coordinates, test the bbox (measured on 3 of the 8 locations per bucket;
  it is location-insensitive).

### Protocol and machine caveats

Four window buckets: 0.01° (~1 km), 0.05° (~5 km), 0.2° (~20 km) squares,
plus a pathological full-extent-wide × 0.01° strip (7.52° wide). 8
deterministic locations per bucket, each centered on a real feature (the
extent is mostly Mediterranean; envelope-uniform sampling would measure
empty sea). Per location: 2 warmup + 9 timed repetitions, median-of-9;
tables report the median across locations — the same discipline as
#103/#278. Two full runs per fixture, reported side by side.

Caveats: 4-vCPU container VM, single virtio disk, other agents building
concurrently during the window (load average observed 1.4–4.7); absolute
numbers carry that tax, the relative ordering was stable across both runs
and both fixtures. Cold-start numbers used an effective
`/proc/sys/vm/drop_caches` between iterations but remain the noisiest.

## Numbers

Match phase, milliseconds, median across 8 locations of per-location
median-of-9. `matched` is the R-tree/cells match count (identical).

**large fixture (303,609 features):**

| bucket | matched | rtree | cells | bboxscan | decode100 | naive scan |
|---|---:|---:|---:|---:|---:|---:|
| 0.01° run1 | 38 | 0.002 | 0.146 | 0.357 | 0.083 | 118 |
| 0.01° run2 | 38 | 0.002 | 0.148 | 0.410 | 0.087 | 120 |
| 0.05° run1 | 494 | 0.007 | 0.987 | 0.746 | 0.152 | 118 |
| 0.05° run2 | 494 | 0.005 | 0.936 | 0.526 | 0.141 | 118 |
| 0.2° run1 | 2,292 | 0.014 | 0.267 | 0.449 | 0.289 | 122 |
| 0.2° run2 | 2,292 | 0.019 | 0.303 | 0.694 | 0.300 | 122 |
| strip run1 | 1,808 | 0.035 | 1.740 | 1.003 | 0.446 | 119 |
| strip run2 | 1,808 | 0.033 | 1.691 | 0.973 | 0.412 | 122 |

**small fixture (30,361 features):**

| bucket | matched | rtree | cells | bboxscan | decode100 | naive scan |
|---|---:|---:|---:|---:|---:|---:|
| 0.01° run1 | 8 | 0.001 | 0.127 | 0.027 | 0.023 | 12 |
| 0.01° run2 | 8 | 0.001 | 0.128 | 0.029 | 0.024 | 13 |
| 0.05° run1 | 97 | 0.002 | 0.890 | 0.031 | 0.080 | 12 |
| 0.05° run2 | 97 | 0.002 | 0.912 | 0.041 | 0.085 | 13 |
| 0.2° run1 | 394 | 0.003 | 0.150 | 0.031 | 0.112 | 12 |
| 0.2° run2 | 394 | 0.003 | 0.153 | 0.034 | 0.113 | 13 |
| strip run1 | 199 | 0.005 | 1.209 | 0.042 | 0.156 | 12 |
| strip run2 | 199 | 0.006 | 1.236 | 0.050 | 0.182 | 13 |

Cold start (structure load + first 0.01° query, median of 7 with page-cache
drops; noisy — individual iterations spanned 18–144 ms on the large
fixture): rtree 70 ms vs cells sidecar 42 ms (large); 3.3 ms vs 4.8 ms
(small). A wash within this machine's noise, in both directions.

## Why the R-tree wins: the EXPLAIN-equivalent

The R-tree's search input is already the right shape: an in-RAM tree over
exactly the bboxes the query semantics need, so cost scales with result
cardinality at tiny constants (2–35 µs from 38 to 2,292 matches).

The cell prefilter pays two costs the R-tree never pays, one per path:

- **Res-9 path (small/medium windows): the query covering itself.** At
  0.05°, `h3o` polyfills ~245 res-9 query cells, which costs ~0.9 ms
  before a single lookup happens — the subsequent binary searches and the
  1.02–1.3× candidate verification are microseconds. #103 saw the same
  mechanism as a `Seq Scan` + JIT tax on a 1,507-hex `= ANY(...)`; here,
  with PostgreSQL removed entirely, the covering computation is the whole
  loss. It is a *query-time* cell computation that the write-time
  materialization was supposed to eliminate — but it can only eliminate
  the *feature-side* computation; the window-side covering is
  irreducible in any cell scheme.
- **Res-6 ladder path (large/pathological windows): candidate dilution.**
  The covering is cheap (~37 cells at 0.2°) but res-6 cells average
  36 km², so candidates run 1.5–4× the match count at 0.2° and 8–20× on
  the strip (up to 42,518 candidates for 1,985 matches), and bbox
  verification over the diluted set dominates. Tightening the ladder
  resolution shifts cost back to the covering; that trade is structural,
  not tunable away.

Both mechanisms scale with window geometry, not with result size — which
is backwards from what an index is for, and is the same "gap grows where
you need help most" shape #103 measured against GiST.

The bboxscan control sharpens the point: a brute-force linear scan over
303,609 materialized bboxes (0.4–1.0 ms) beats the cell lookup on the
medium and strip buckets. When a cell structure cannot reliably beat the
flat array its own sidecar stores — never mind the logarithmic tree the
file already carries for free — there is no residual headroom for it.

For end-to-end perspective: the driver's page decode (~0.1–0.45 ms) dwarfs
the R-tree match phase everywhere, and the no-index scan is ~120 ms at
300k features. Any index at all is a ~100–1000× win over scanning;
between the two indexes, the one that is free wins every bucket.

## Verdict: not worth building

At 30k and 300k features, small/medium/large/pathological windows, warm
and cold, the write-time-materialized cell prefilter **never beats the
packed R-tree FlatGeobuf already carries** — the match phase loses by
10–300× warm, cold start is a wash, and it costs 22.5 µs/feature of write
time plus 18.5% of the base file in storage to maintain (recurring on
every write via the outbox lane, per #103's Q5, and impossible for files
written outside this project). This was the strong case for cells —
write-time materialization, real data, the ladder built, the query planner
given both paths — and it still loses to the index that costs nothing.

Per #131's own framing, the negative verdict propagates a strong prior to
the weaker candidates:

- **GeoParquet / Iceberg / memory driver**: these lack FlatGeobuf's
  R-tree, but the bboxscan control measured here is precisely what a
  "materialize bboxes, scan them linearly" fallback costs — ~0.4–1 ms at
  300k rows, already at parity with the cell structure. If anything is
  ever materialized for those drivers, it should be a flat bbox
  sidecar/statistics column (or a packed R-tree, which FlatGeobuf
  demonstrates is buildable at write time for near-zero cost), **not** an
  H3 cell set. A cell-shaped structure earns its keep only for
  cell-native surfaces (DGGS aggregation), not for bbox/intersects
  serving.
- **PostGIS**: untouched — #103's GiST verdict stands.

No production code changes ship from this spike. What stays: this
document, and the standalone harness under
`bench/spike-131-materialization/` (its own cargo workspace, so `h3o`
never enters the tracked root workspace — the same ground rule #103's
harness followed; the root `Cargo.toml`/`Cargo.lock` are untouched).
