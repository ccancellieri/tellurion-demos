# Dynamic multi-tenant control plane

Status: approved design for issue #48. This design builds on the shipped
authentication, policy, relational-registry, reload, and runtime-config work
tracked by #34, #42, #110, #144, and #155.

## 1. Objective

Make Tellurion administrable through a secure control plane without coupling
the OGC/STAC data plane to a particular database or identity product.

The control plane manages the hierarchy:

```text
platform -> tenant -> catalog -> collection -> assets/representations
```

Configuration is dynamic. YAML carries a small static boot envelope plus an
explicit first-boot seed; the seed is not the permanent source of truth. Once
initialized, a deployment's control store may diverge from the seed
indefinitely.

The design must support:

- PostgreSQL for shared and multi-replica deployments;
- SQLite for a lightweight local deployment;
- OIDC/OAuth2 authentication;
- SAML federation through an identity broker that exposes OIDC to Tellurion;
- platform, tenant, catalog, and collection-scoped administration;
- path-based access policies over a canonical administrative URL hierarchy;
- atomic revisions, audit, recovery, and deterministic replica convergence;
- a tenant-aware control panel that does not expose raw configuration as its
  primary interface.

## 2. Non-goals

- Tellurion does not become a SAML service provider in this slice.
- Tellurion does not issue passwords or replace an identity provider.
- A tenant administrator cannot register an arbitrary trusted token issuer.
- Administrative writes are not added to OGC or STAC protocol routes.
- No database-specific type crosses the core control-store contract.
- Notification delivery is never required for correctness.

## 3. Architecture

```text
boot envelope (store locator, read every boot)
          +
YAML seed (imported first boot only)
          |
          v
  backend-neutral ControlStore
  +---------------------------+
  | config + registry         |
  | principals + role binding |
  | policies                  |
  | revisions + audit         |
  | durable change outbox     |
  +---------------------------+
          |
          v
validated immutable snapshot / scoped registry readers
          |
          v
atomic AppContext swap and cache invalidation
          |
          v
OGC/STAC data plane
```

The control plane and data plane are logically separate. A deployment may
mount both in one process, or run a data-plane-only process with the control
routes disabled. Protocol crates never depend on the control-plane HTTP or UI
crates.

### 3.1 Storage seam

The existing `ConfigStore` remains the compatibility seam for file-backed,
whole-document configuration. Dynamic administration introduces an async
`ControlStore` contract rather than stretching synchronous file semantics over
a network database.

The core contract exposes operations equivalent to:

```text
bootstrap_if_empty(seed) -> bootstrapped | already_initialized
current_revision() -> revision
load_snapshot(revision?) -> versioned snapshot
transact(expected_revision, actor, changeset) -> committed revision
changes_since(cursor?, limit) -> ordered change page
```

The change cursor is the composite `(revision, ordinal)` position of the last
consumed outbox event. A revision-only cursor is insufficient when a bounded
page ends in the middle of one revision: resuming after that revision would
silently skip its remaining events.

`transact` is the only mutation boundary. A backend must atomically persist the
domain changes, revision, audit record, and outbox event. Two writers using the
same expected revision cannot both succeed.

Domain-facing capabilities remain narrow:

- configuration and profile reads;
- tenant/catalog/collection registry reads and writes;
- principal and scoped role-binding reads and writes;
- policy reads and writes;
- audit and ordered change reads.

Concrete backend factories provide these capabilities from one transactional
store. The relational backend also implements the existing scoped registry
reader contract, so catalog and collection lookups remain paginated and do not
require scanning an entire deployment.

### 3.2 Initial backends

- PostgreSQL is the shared-deployment backend.
- SQLite is the local lightweight backend.
- YAML is a bootstrap, import, export, and compatibility format.
- The existing file-backed runtime remains available as an explicitly selected
  legacy mode. It does not expose the dynamic multi-user control plane.

Adding another backend requires passing the same control-store contract suite,
including transaction, compare-and-swap, audit, ordered-change, and restart
tests. A lowest-common-denominator CRUD adapter is not sufficient.

## 4. Bootstrap and migration

Tellurion must be able to locate the authoritative store before it can read
dynamic configuration. The boot input is therefore split into:

- a static `control_store` locator, read at every process start, containing
  only backend selection, a connection-secret reference, and bounded polling
  settings;
- the `AppConfig` seed, considered only when the selected store is empty.

The locator contains no database password or token. A PostgreSQL locator names
an environment variable or secret-provider reference holding the connection
URL; a SQLite locator names its local database path. Changing the authoritative
store is an explicit migration, not a dynamic configuration mutation.

`bootstrap-if-empty` executes once, transactionally:

1. acquire the backend's initialization lock;
2. verify that no control revision exists;
3. parse and fully validate the YAML seed;
4. insert platform configuration, registry resources, trusted issuers, initial
   role templates, and the initial sysadmin mapping;
5. write revision 1, audit, and the initial outbox event;
6. commit.

If a revision already exists, the seed is ignored while the static store
locator is still read so the process can reconnect. Tellurion never silently
reimports or merges a changed YAML seed.

Explicit sysadmin operations provide:

- previewed import as a normal versioned changeset;
- export of a redacted or secret-reference-only snapshot;
- comparison between a seed/export and the current effective state;
- migration from legacy file mode to SQLite or PostgreSQL;
- rollback by creating a new revision from a previous snapshot.

Schema migrations use a backend lock and a schema version. A process does not
accept administrative writes until its store schema is compatible.

## 5. Canonical state

The logical model includes:

- platform settings and named profiles;
- tenants;
- catalogs owned by exactly one tenant;
- collections owned by exactly one catalog;
- assets, representations, storage references, and routing declarations;
- trusted OIDC issuers and tenant claim/group mappings;
- principals identified by `(issuer, subject)`;
- role templates, scoped role bindings, and policy statements;
- revisions, audit events, and ordered outbox events.

Secrets are structurally absent. Configuration stores references to environment
variables or an external secret manager, never client secrets, bearer tokens,
passwords, or private keys.

Each mutable resource has an entity version for focused conflict reporting.
Every committed transaction also advances a deployment-wide monotonic revision
used for replica convergence and whole-system audit ordering.

## 6. Change propagation and Pgpool safety

The durable revision and outbox are the only correctness mechanism.

Each replica:

1. polls `current_revision` with bounded jitter;
2. reads every outbox event after its applied revision;
3. rebuilds or invalidates the affected immutable state;
4. validates the candidate state;
5. atomically activates it;
6. records its applied revision.

Missed, duplicated, or out-of-order wake-up signals cannot prevent eventual
convergence because consumers always reconcile from the durable revision.

PostgreSQL `LISTEN/NOTIFY` is an optional latency optimization only. It is
disabled by default behind Pgpool or another session-pooling proxy. Operators
may enable it only on a verified dedicated, non-pooled connection; revision
polling remains active even then. A notification contains only the committed
revision, never configuration data.

SQLite uses revision polling. Future transports may wake consumers, but none
may replace durable reconciliation.

## 7. Authentication

### 7.1 Human users

The browser uses OIDC Authorization Code with PKCE. The control panel uses a
secure server-side session or `HttpOnly`, `Secure`, same-site cookies with CSRF
protection; tokens are not persisted in browser local storage.

Tellurion validates access tokens through OIDC discovery and JWKS, including
issuer, audience, expiry, not-before, and key rotation. A principal is keyed by
the stable `(issuer, sub)` pair; display names and email-like claims are
non-authoritative attributes.

SAML is supported through Keycloak, Authentik, Entra, Okta, or another broker
that accepts SAML upstream and exposes OIDC downstream. Tellurion retains one
token-validation model.

### 7.2 Trusted issuers and mappings

Only a sysadmin can register a trusted issuer. A tenant administrator may
select from those issuers and manage the tenant's allowed group/claim mappings.
It cannot introduce a new trust root.

Identity-provider mappings and local scoped bindings are both stored in the
control store. Effective roles are derived from the validated token plus the
stored mappings and bindings; raw unregistered claims never imply authority.
Granting platform sysadmin through an external group requires an explicit
platform mapping.

### 7.3 Service and recovery identities

Service accounts use OAuth2 Client Credentials at the external identity
provider and receive explicitly scoped bindings.

An optional break-glass recovery credential is disabled by default. When
enabled, it comes only from an external secret, is limited to sysadmin recovery,
is heavily audited, and never appears in the control store, UI, or export.

## 8. Authorization model

Authorization is default-deny and evaluated at one middleware checkpoint after
authentication and scope resolution. Handlers do not contain bespoke role
checks.

Built-in role templates are:

- `sysadmin`: trusted issuers, backends, platform configuration, tenant
  lifecycle, global profiles, platform policies, and full audit;
- `tenant_admin`: catalogs, tenant settings, tenant-scoped identities,
  bindings, and policies;
- `catalog_admin`: collection lifecycle, catalog metadata/settings,
  visibility, styles, and catalog-scoped delegation;
- `collection_editor`: assigned collection data, assets, metadata, and styles;
- `publisher`: publication state and visibility without identity management;
- `viewer`: explicitly granted reads;
- `service_account`: no implicit grants; capabilities are assigned explicitly.

These are templates, not hard-coded authorization branches. Operators may
define custom roles as policy bundles.

### 8.1 Scope and delegation

A binding is attached to platform, tenant, catalog, or collection scope. Grants
may flow down the resource hierarchy but never up. Explicit deny wins over
allow; absence of an allow is deny.

An administrator can assign only permissions within its own effective
delegation ceiling. A catalog admin cannot manufacture or delegate platform or
tenant authority through a custom role.

Data-plane protocol lanes remain distinct from control-plane administrative
capabilities. They share the authenticated principal and policy engine without
conflating an OGC read/write grant with an administrative grant.

### 8.2 Canonical administrative paths

Administrative resources use a stable nested hierarchy:

```text
/_control/v1/platform/...
/_control/v1/tenants/{tenant}/...
/_control/v1/tenants/{tenant}/catalogs/{catalog}/...
/_control/v1/tenants/{tenant}/catalogs/{catalog}/collections/{collection}/...
```

Common subresources include `settings`, `effective-settings`, `principals`,
`role-bindings`, `policies`, `assets`, `styles`, `jobs`, and `audit` where the
scope supports them.

Policy statements may match HTTP method and anchored path patterns, for
example:

```text
GET  /_control/v1/tenants/acme/catalogs/**
POST /_control/v1/tenants/acme/catalogs/cadastre/collections
PUT  /_control/v1/tenants/acme/catalogs/cadastre/collections/*/styles/**
```

Path matching is not a raw prefix check. Before policy evaluation Tellurion:

- strips only the configured application root path;
- rejects ambiguous escaping, encoded separators, dot segments, and traversal;
- matches a registered route template;
- resolves every external id to an internal id;
- verifies tenant -> catalog -> collection ownership;
- constructs a typed authorization scope;
- evaluates method, canonical path, principal, binding, role, and conditions.

Patterns support anchored segment wildcards (`*` and `**`), not arbitrary
regular expressions. This prevents prefix collisions and inconsistent URL
normalization from becoming authorization bypasses.

## 9. Administrative API

The control API is separate from OGC/STAC routes and may be disabled as a
unit. It provides granular, scope-filtered resources rather than exposing the
whole configuration document to delegated administrators.

Every mutable resource uses an `ETag`; updates require `If-Match`. Creation,
import, and long-running operations accept an idempotency key. Conflicts return
`409` with enough version information for the client to refresh and display a
focused diff.

Mutations support:

- dry-run validation;
- effective-value and provenance inspection;
- impact and dependency preview;
- atomic multi-resource changesets;
- standard `application/problem+json` errors;
- audit correlation.

Only sysadmin may import, export, or compare a whole deployment snapshot.
Deletion of tenant, catalog, and collection resources is staged through
disable/tombstone before an explicit permanent delete with dependency preview.

## 10. Control panel

The control panel is a separate workspace from the map/catalog browser, while
sharing the API adapter and visual components. Its navigation follows the
authorized resource tree and always displays the active scope in a selector
and breadcrumb.

Each field-oriented settings form shows:

- effective value;
- provenance level and source;
- local override;
- `final` ownership;
- reset-to-inherited action;
- server-published documentation and validation constraints.

Normal administrators do not edit a large YAML document. A sysadmin-only
advanced surface may preview redacted import/export and changeset diffs.

Creation wizards keep reference-in-place and ingest/copy as explicit choices.
Collection administration covers metadata, assets, representations, routing,
styles, and publication only when the principal holds the corresponding
capabilities.

The access workspace manages principals, service accounts, role templates,
bindings, and policies in the current scope. A read-only policy simulator
evaluates a proposed principal, method, and canonical path without issuing a
token or impersonating the principal. It reports the bindings, statements, and
conditions that produced allow or deny.

Audit, jobs, replica revision, and reload failures are visible at the narrowest
scope the user may inspect. The UI is keyboard accessible, responsive, and
never renders secrets or raw tokens.

## 11. Failure and recovery semantics

- If the control store is unavailable, the data plane continues serving its
  last valid snapshot.
- Administrative writes fail closed with `503` while the store is unavailable.
- A candidate that fails rebuild or validation is not activated.
- Optimistic conflicts fail with `409`; no last-writer-wins fallback exists.
- Rollback creates a new audited revision instead of deleting history.
- Replica lag and failed revision application are observable.
- Outbox retention cannot advance past the oldest supported consumer revision
  without an explicit snapshot/resync path.

Audit records contain principal, issuer, method, canonical path, internal and
external scope, matched authorization result, old/new revision, redacted diff,
outcome, correlation id, idempotency key, timestamp, and applying instance.
They contain no bearer token, secret, password, or unnecessary personal data.

## 12. Verification contract

The feature is not complete until it passes:

- one backend-neutral contract suite against SQLite and PostgreSQL;
- idempotent and concurrent bootstrap tests;
- entity-version and deployment-revision compare-and-swap tests;
- transaction tests proving domain write, audit, and outbox are atomic;
- multi-replica tests with missed, duplicated, and reordered wake-up signals;
- Pgpool-path tests proving convergence without `LISTEN/NOTIFY`;
- restart and failed-revision recovery tests;
- complete role/delegation matrices across all four scopes;
- cross-tenant isolation tests;
- path canonicalization and authorization-bypass tests;
- OIDC discovery, audience, expiry, JWKS rotation, and claim-mapping tests;
- brokered-SAML integration exercised as downstream OIDC;
- browser tests for authorization-filtered navigation, dry-run/diff/apply,
  conflict recovery, inheritance, audit, accessibility, and responsive layout;
- secret and personal-data scans over audit and export fixtures.

## 13. Delivery slices

Each slice is tracked by a dedicated issue and implemented in an isolated
worktree. Dependencies and acceptance criteria are recorded before code starts.

1. Backend-neutral control-store contract, revisions, audit, and outbox.
2. SQLite backend and YAML bootstrap/migration path.
3. PostgreSQL backend, polling convergence, and Pgpool-safe integration tests.
4. OIDC platform-admin authority, trusted issuers, and principal model.
5. Hierarchical role bindings, delegation ceiling, and canonical path policy.
6. Versioned administrative API and effective-config provenance.
7. Platform sysadmin control panel.
8. Tenant, catalog, and collection administration.
9. Policy simulator, audit explorer, replica status, and recovery workflows.
10. End-to-end security, migration, accessibility, and deployment verification.

Implementation worktrees share one external build cache where practical. A
worktree and its branch are removed after their issue is merged and verified so
parallel delivery does not create unbounded disk growth.
