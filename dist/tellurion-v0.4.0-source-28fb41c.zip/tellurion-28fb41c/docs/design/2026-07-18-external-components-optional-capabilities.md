# Architecture stance: external components are optional capabilities

Status: adopted — normative stance for issue #32 (closed). This is a standing
rule for the platform phase, not a feature design. It governs how every future
external dependency enters the codebase, and the precedents section below
already describes the codebase as it stands, not just an aspiration.

## The stance

**Tellurion stays a single, self-sufficient binary. Every external component
earns its place as an optional capability behind a trait — exactly as storage
drivers do today.** Nothing outside the process is ever a *boot* requirement.
The absence of an external system degrades a feature; it never stops the server
from starting and serving its protocol surface.

This keeps two product shapes honest at once: a standalone on-premise install
(a desktop-GIS-like experience served over HTTP) and a modular cloud deployment
that composes with infrastructure an organization already runs. We reuse an
external component where it is genuinely superior and stable, and we introduce a
new piece only when it beats what exists on performance without costing
stability.

## What "optional capability" means, concretely

An external system enters the codebase under all three of these, or it does not
enter:

1. **Behind a trait.** It is reached only through a capability trait in
   `tellurion-core` (the `StorageDriver` capabilities, `TileCache`,
   `ConfigStore` are the existing shape). Protocol crates depend on the trait,
   never on the component. The `Router` refuses a missing capability at resolve
   time with `Error::CapabilityUnsupported`, or at config load for an explicitly
   routed lane — never mid-handler, never at boot.

2. **Behind a default-off cargo feature where it brings dependencies.** If
   wiring the component pulls a client library or SDK into the graph, that code
   lives in its own crate behind a feature that is **off by default**. The
   default build must not compile a hard dependency on any external system it
   does not strictly need.

3. **Declared in config, not conjured from the environment.** Configuration
   declares what exists; environment variables carry only secrets, and they are
   *indirected by name* — config names the env var, the value never appears in
   config. `StorageDecl { id, driver, url_env }` is the canonical shape:
   `url_env` names the variable holding the connection secret. Behavior in
   config, secrets in env, nothing else in env.

## The catalogue of externals, and where each sits

- **Relational / PostGIS storage** — a driver, not a requirement. It is the
  first concrete backend, but "routing over abstract storage" is the core
  concept; the protocol crates carry no database dependency at all. A collection
  routed to a storage whose backend is unreachable degrades *that collection*;
  it does not abort boot.
- **Object storage** — already optional, already behind drivers: the file/
  object-backed drivers (PMTiles, FlatGeobuf, GeoParquet) read archives from
  local files or an object store and require no running database process at
  all.
- **Cache L2 (Valkey)** — the optional second layer behind `TileCache` /
  `LayeredCache` (#16). An L1-only deployment is the default; the L2 drops in
  behind the same trait with no protocol or driver change.
- **Auth / identity provider** — the server validates OIDC/JWT against any
  provider (Keycloak as the reference deployment; a file-based principal store
  covers the standalone shape). Tellurion never grows its own identity database,
  and auth is a middleware capability, not a boot dependency.
- **Search engine** — no search engine in the core. If full-text or faceted
  search ever outgrows what storage drivers can push down, an external index
  arrives later as *another optional driver* advertising a search capability
  (see the transactional-outbox design), never as a boot requirement.
- **Message transport** — should the outbox ever need an out-of-process
  transport, it too is an optional capability behind a trait, and the in-process
  applier remains the default.

## The precedents this codifies

This is not a new rule — it names a pattern the codebase already follows, and
requires future work to keep following it:

- **Default-off driver features.** In `tellurion-server`, `pmtiles`,
  `flatgeobuf`, `geoparquet`, and `ui` are all `default`-off. The stated
  rationale in those manifests is exactly this stance: turning a driver on
  standalone (`--no-default-features --features pmtiles`) proves a backend
  serves traffic with the database driver — and every crate it pulls in —
  compiled out of the graph. `tellurion-ingest`'s dataset loader takes this
  further still: it shells out to the host's `ogr2ogr` binary instead of
  linking a native library at all, so the external component never enters
  the compiled dependency graph in the first place.
- **The routing layer.** The `Router` resolves `(tenant, collection, lane)` to
  a capability trait object; no protocol code names a concrete backend. Adding
  or removing an external backend touches wiring and config, not handlers.
- **Capability traits.** `StorageDriver`'s optional accessors
  (`feature_source`, `tile_source`, …) default to `None`. "This deployment does
  not have that capability" is a first-class, representable state — which is
  precisely what lets absence degrade a feature instead of breaking the build or
  the boot.

## The test for future PRs

Every PR that introduces or touches an external integration must answer yes:

> **Does the default build still boot and serve its protocol surface with no
> external processes running?**

Concretely: `cargo build` (default features) produces a binary that starts,
serves OGC API Common (landing, conformance, OpenAPI), and serves any collection
routed to a file/object-backed driver — with no database, no cache server, no
identity provider, and no message broker running. A capability that is absent
must surface as a degraded feature or a resolve-time `CapabilityUnsupported`,
never as a failed boot. If a change cannot pass this test, the dependency it
adds is a core requirement in disguise, and it does not merge in that shape.
