# Relational tenant and registry routing (issues #42 and #143)

Status: shipped. Closes the gap the second slice left open: a catalog or
collection published into the `registry_catalogs`/`registry_collections`
tables was already visible through `RegistryReader` (a paginated
`GET /collections` could see it), but `Router` and `Resolver` still only ever
indexed `AppConfig.catalogs`/`.collections` — the YAML file — so the same
collection had no way to actually route or resolve a request. This slice
makes `registry.backend: relational` mean what it says: tenants, catalogs,
and collections are read from the database at boot and reload, not just at
query time.

## 1. Normalized-input design

`Router::build` and `StaticResolver::build` used to read `AppConfig.tenants`/
`.catalogs`/`.collections` directly. Both now delegate to a
`build_from_snapshot` counterpart that takes all three declaration lists as
explicit slices instead — the same normalized input, regardless of source.
`build`/`build_from_snapshot` is the one and only index-building
implementation either way; there is no second, relational-specific copy of
the loop that builds `Router`'s routing tables or `StaticResolver`'s
external/internal id maps.

The two sources that feed that normalized input:

- **File** (the default): `Router::build`/`StaticResolver::build` pass
  `config.tenants`/`config.catalogs`/`config.collections` straight through —
  zero I/O and unchanged behavior.
- **Relational**: `tenant::snapshot_tenants` first walks a `TenantReader`;
  `registry::snapshot_from_registry` then walks a `RegistryReader` under
  those tenant IDs. The resulting `(tenants, catalogs, collections)` feeds
  the identical `build_from_snapshot` calls.

`context::build_router_and_resolver` is the single entry point the wiring
layer (`main.rs`/`reload.rs`) calls instead of choosing a path itself. It
dispatches on `config.registry.backend` and, for the relational case, walks
the registry exactly once and builds `Router` and `Resolver` from that one
result — never two independent walks, which could otherwise hand the two
indexes different views of a registry mutated in between (a `Router` entry
with no matching `Resolver` entry is unreachable from any URL regardless of
what it can serve once resolved, so the two must always agree).

## 2. Double-source rule

`registry.backend: relational` combined with a non-empty `tenants:`,
`catalogs:`, or `collections:` section in the same config document is a hard
boot/validation error (`AppConfig::validate`), not a precedence rule.
Rationale: an operator who forgets to remove a leftover declaration block
after switching backends would otherwise get silent, surprising behavior —
whichever precedence won would serve; the other source's declarations would
simply 404, with no error anywhere pointing at why. A named boot failure is
strictly better than a plausible-looking deployment that's authenticating or
routing against stale tenant data. `file` (the default) is entirely
unaffected — declaring all three sections there is the normal shape.

Referential integrity for a relational snapshot's own declarations
(unique internal/external ids at their scope, resolvable tenant/storage/
catalog references, valid routing/tiles/places3d/schema shapes) is checked
by `config::validate_registry_snapshot`, which shares its implementation
(`validate_catalogs_and_collections`) with `AppConfig::validate`'s own check
of a YAML `catalogs:`/`collections:` list — a database row gets no less
scrutiny than a hand-written config entry.

## 3. Snapshot pagination

`TenantReader::list_tenants` is paged to exhaustion first using a keyset
cursor (`next`, never `OFFSET`). That authoritative tenant list is then the
starting point for the registry walk: `list_catalogs` is paged for each
tenant, followed by `list_collections` for each collected catalog. Production
uses a page size of 1000; test-only helpers shrink it to exercise multi-page
walks without seeding thousands of rows.

Bearer-token membership and tenant-policy ownership remain operator config,
but their tenant IDs are deliberately not resolved during the pre-read YAML
shape check. They are resolved after the tenant walk against this exact
snapshot. A stale file-side reference therefore fails boot/reload, while a
new database tenant needs no duplicate YAML declaration.

## 4. Reload semantics and the operator flow

The SIGHUP/file-watch reload trigger that already existed (issue #47) is the
only refresh mechanism for a relational backend too — there is no polling
and no watch on the database itself. Publishing new rows into
`registry_catalogs`/`registry_collections` has no effect on a running
process until an operator triggers a reload: `kill -HUP <pid>`, or a touch
of the config file (which a mounted ConfigMap update already does on its
own, per the existing file-watch trigger).

Reload order: the registry and tenant readers are built (and, for
`relational`, connected), tenants are walked and validated, then catalogs and
collections are walked beneath them. Auth/policy tenant references and the
complete registry snapshot are validated before `Router`/`Resolver` and the
authoritative `ContextState.tenants` are atomically swapped. Any failure
leaves the previous state and readers untouched. A relational registry going
unreachable between successful reloads therefore means "the reload didn't
happen," never a partially updated server.

Operator flow to adopt `registry.backend: relational`:

1. Save each tenant, catalog, and collection declaration as its own YAML file,
   then remove (or leave empty) `tenants:`/`catalogs:`/`collections:` in the
   config file. Keep `auth:` and `policy:` there; their tenant IDs will be
   checked against the database snapshot.
2. Set `registry.backend: relational` and `registry.storage` to a declared
   storage id.
3. Run `tellurion-ingest registry create-tables` once against that storage's
   database (idempotent — safe to re-run).
4. Publish parents before children so the foreign keys hold on every write:
   `tellurion-ingest registry publish-tenant tenant.yaml`, then
   `tellurion-ingest registry publish-catalog catalog.yaml`, then
   `tellurion-ingest registry publish-collection collection.yaml`.
5. Restart the process, or send it `SIGHUP` (or touch the config file) if
   it's already running.
6. For every later publish/update: trigger another reload the same way —
   `SIGHUP` or a config-file touch. There is nothing else to run; the
   process does not notice a database change on its own.
