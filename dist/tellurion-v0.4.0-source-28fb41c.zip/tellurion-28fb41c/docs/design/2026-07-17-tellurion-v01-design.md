# Tellurion v0.1 — Design

> **Superseded for current licensing and distribution policy.** This historical
> v0.1 design record is retained unchanged; see the 0.3.0 BSL community and
> commercial release decision for the current policy.

Status: approved 2026-07-17 · revised same day: **routing is the core concept; PostGIS
is a driver, not a requirement.**

## Goal

A small, fast, clean-room geospatial serving engine in Rust that demonstrably
outperforms an equivalent Python (FastAPI + asyncpg) stack on identical data and
hardware. v0.1 is a performance demonstrator with a real, conformant protocol surface —
not a feature-complete platform. The benchmark comparison target is the existing
Python-based geoid/dynastore deployment.

## Scope

**In:** OGC API Common (landing, conformance, OpenAPI) · OGC API Features Part 1
(Core + GeoJSON) · OGC API Tiles Part 1 (WebMercatorQuad, MVT + PNG) · storage
**routing layer** with a PostGIS driver as first concrete backend · read-only serving ·
an ingest CLI · Prometheus metrics · the four-layer deployment pyramid.

**Out (deliberately):** cloud-provider SDKs, STAC/Records, built-in authentication
(reverse proxy's job), transactional write APIs, CRS other than CRS84/3857, L2 cache
implementation (interface is ready; see Cache).

## Core concept: routing over abstract storage

Everything the protocol layer touches goes through the **Router**. No protocol code may
name a concrete backend — this is compile-enforced: the protocol crates have no
database dependencies at all.

```
request → protocol handler → Router.resolve(tenant, collection) → StorageDriver
```

- **Storage traits** (`tellurion-core::storage`): capability interfaces, e.g.
  `FeatureSource` (items query, single item, count) and `TileSource` (MVT for z/x/y).
  A driver implements the capabilities it has; the Router refuses at resolve time —
  not at request time deep in a handler — when a capability is missing.
- **Drivers** are separate crates registered with the Router at startup.
  v0.1 ships `tellurion-postgis`. Any storage (DuckDB, object-store parquet, ES, …)
  can be added without touching protocol code.
- **Tenancy is a routing dimension, not a database construct.** A tenant + catalog +
  collection triple resolves to a driver and a physical target via configuration.
  The PostGIS
  driver uses one schema with per-collection physical tables — **no schema-per-tenant**
  (avoids PG catalog-lock contention and runtime DDL entirely) and no runtime DDL on
  the serving path.
- **Configuration is generic.** A `ConfigStore` trait supplies the registry (storages,
  tenants, catalogs, collections, styles). v0.1 implements a file-based store (YAML);
  the trait is the seam for DB-, object-store-, or Valkey-backed config later. Env vars
  carry secrets/infra only (`DATABASE_URL`, `PORT`, `TELLURION_CONFIG`).

```yaml
storages:
  - id: main
    driver: postgis
    url_env: DATABASE_URL
tenants: [ { id: public } ]
catalogs: [ { id: default, tenant: public } ]
collections:
  - id: demo
    catalog: default
    storage: main
    table: demo              # physical target, driver-interpreted
    geometry: geom
    pk: id
    datetime: observed_at    # optional
    tiles: { minzoom: 0, maxzoom: 14, caps: { z0: 2000, z10: 20000 } }
    style: { fill: "#3388ff66", stroke: "#3366cc", stroke_width: 1.0 }
```

## Architecture

Cargo workspace, one binary, twelve library crates:

```
tellurion (server)    axum app: routing table, middleware (timeout, limit, shed), metrics, wiring
tellurion-core        config model + ConfigStore, Router + storage traits, cache, errors
tellurion-postgis     first concrete driver: ST_AsMVT / ST_AsGeoJSON, pool, statement timeouts
tellurion-pmtiles     read-only driver: CatalogSource + TileSource over local PMTiles v3 archives
tellurion-flatgeobuf  read-only driver: CatalogSource + FeatureSource over local .fgb files (packed R-tree)
tellurion-geoparquet  read-only driver: CatalogSource + FeatureSource over local GeoParquet files (row-group pruning)
tellurion-features    OGC API Features handlers (trait-typed, driver-agnostic)
tellurion-tiles       OGC API Tiles handlers + cache policy (trait-typed, driver-agnostic)
tellurion-render      MVT -> PNG/glTF rasterization and footprint extrusion (pure: bytes in, bytes out)
tellurion-places      3D Tiles 1.1 delivery: tileset.json discovery + the Glb tile lane
tellurion-styles      OGC API Styles read-only surface: MapLibre style documents and metadata
tellurion-stac        STAC API: Catalog landing + Collections, mapped from the collection descriptor
tellurion-ingest      CLI: dataset loading via ogr2ogr shell-out, seeding
```

Dependency direction: `server → {features, tiles, places, styles, stac} → core ←
{postgis, pmtiles, flatgeobuf, geoparquet}`; `{tiles, places} → render` at the
response boundary only. Only `server` (wiring) and `ingest` may know concrete
drivers exist.

### Data path

- **Features:** handler → `FeatureSource::items(query)` → PostGIS driver emits one SQL
  statement producing GeoJSON in the database (`ST_AsGeoJSON`), streamed out. Keyset
  pagination (ordered by pk), never OFFSET. `bbox` via `&&` on GiST; `datetime` btree.
- **MVT tiles:** handler → cache probe → `TileSource::mvt_tile(z,x,y)` → driver runs one
  `ST_AsMVT(ST_AsMVTGeom(...))` against `ST_TileEnvelope` with per-zoom simplification
  and caps.
- **PNG tiles:** MVT-first. PNG lane probes the same MVT cache (tile identity is the
  key; encoding is a variant), decodes with geozero, rasterizes with tiny-skia using
  the collection style.

### Cache

`TileCache` trait; v0.1 ships the in-process L1: moka with a byte weigher, budget as a
percentage of the cgroup memory limit. The composition point (`LayeredCache`) is in
place so a **Valkey L2** drops in behind the same trait when clustered deployment
arrives — protocol and driver code will not change.

### Operational rules (lessons applied)

1. **One cache, byte-budgeted** — never entry-count sized; encoding variants share one
   tile identity.
2. **Bounded requests** — 60s hard ceiling, per-zoom caps, PG statement timeouts
   matching the HTTP ceiling, cancellation propagated on client disconnect.
3. **Queue, then shed** — tower load-shed + bounded concurrency ahead of the pool;
   saturation degrades gracefully, never OOMs, never stampedes the backend. Per-tenant
   admission control sits one layer further out, ahead of that shared ceiling and before
   routing resolves a catalog or collection: a small bounded queue with a deadline, and
   a fair-share slice of the ceiling per tenant (equal by default, weighted via settings),
   so one tenant's burst can queue briefly and get honestly rejected without starving
   another tenant's baseline traffic or ever monopolizing the ceiling itself.
4. **Pool sizing derived, not guessed** — from cores + backend capacity; one knob.
5. **Memory is observed** — `/metrics` exports RSS beside request histograms.
6. **Behavior in config, not env** — env is for secrets/infra only.
7. **No runtime DDL** — physical tables are created by ingest/operators, never by the
   serving path.

## Deployment pyramid

1. Static binary (musl, CI-built) + systemd unit — appliance installs, benchmarks.
2. OCI image — multi-stage, non-root, arbitrary UID (OpenShift restricted SCC safe).
3. Compose — PostGIS + tellurion + seeded demo data; local dev and single-node bench.
4. k8s base manifests + kustomize overlays (k3s / EKS / OpenShift); same YAML
   consumable by `podman kube play`. No Helm.

## Benchmarking protocol

`bench/` contains oha-driven scenarios and a written protocol: cold/warm MVT sweeps
across zooms, PNG renders, feature pages, mixed load; identical dataset and PG
instance; p50/p95/p99, throughput, RSS, CPU. Results land in `bench/results/`
(gitignored); summaries go in the README. Comparison environments: tellurion on-prem
(binary/compose) vs the Python reference deployment, plus like-for-like local runs.

## Testing

- Unit tests per crate; `render` fully DB-free; SQL builders golden-tested; Router
  resolution and capability refusal covered without any database.
- Integration tests behind a `pg` feature: PostGIS via compose, seed, exercise
  Features + Tiles, assert conformance shapes (links, numberMatched, content types)
  and tile validity (MVT parses; PNG dimensions).
- CI: fmt, clippy (deny warnings), unit tests, then the PG integration job.

## Roadmap (tracked as issues)

- **3D places**: a further OGC protocol family — 3D feature access, styled/rendered
  vector tiles, and 3D tile delivery (GeoVolumes-style), reusing the Router and the
  style model.
- **Styles**: OGC API Styles surface over the per-collection style config.
- **Valkey L2 cache** behind `TileCache` for clustered deployments.
- **Additional drivers** (DuckDB/parquet object store first candidates).

## Licensing

AGPL-3.0 with commercial dual licensing; contributions only under copyright assignment
(CLA.md). Clean-room rule: no code copied from any prior project; lessons only.
