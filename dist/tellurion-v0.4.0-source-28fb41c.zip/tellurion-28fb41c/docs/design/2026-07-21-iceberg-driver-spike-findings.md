# Iceberg driver spike findings

Status: closes #45. The driver itself already landed as a read-only
`CatalogSource` + `FeatureSource` implementation in `crates/tellurion-iceberg`;
this document is the deliverable #45 was re-scoped to once that code shipped —
the tradeoffs and verdicts that were previously only in the source and commit
history.

## What the spike set out to answer

Can Tellurion serve OGC API Features traffic straight off an Apache Iceberg
table reached through a real REST catalog, with no database of its own,
following the same driver contract every other file-backed driver (PMTiles,
FlatGeobuf, GeoParquet) already proves — and how far can CQL2 pushdown reach
before it has to fall back to an honest refusal?

## What it proved

- **Table access.** The driver never opens a table off a bare filesystem
  path. Every table is resolved through a real Iceberg REST catalog (the
  `iceberg-catalog-rest` crate's `RestCatalog`, speaking the standard
  `GET /v1/config` + `GET /v1/namespaces/{ns}/tables/{table}` protocol) — no
  SQL catalog, no AWS Glue. The catalog's `warehouse` property is never set;
  every `LoadTableResult`'s own `metadata-location` is what the driver's
  `FileIO` resolves all later reads from.
- **Snapshot pinning.** A table (and its schema, manifest list, current
  snapshot) is loaded exactly once per backend lifetime and cached for the
  backend's lifetime. A commit made after that point is invisible to every
  later call on that backend instance — there is no re-read and no staleness
  check.
- **Declared geometry, validated at load.** Iceberg has no native geometry
  type, so the WKB geometry column and its four covering bbox columns are
  operator declarations carried in a query-string-shaped locator
  (`<rest-catalog-uri>?namespace=...&table=...&geometry=...&bbox=xmin,ymin,xmax,ymax`)
  in the existing `StorageDecl.url_env` field — no new config surface. At
  load time each declared column is checked against the pinned schema
  (`Binary` for geometry, `Double`/`Float` for each bbox column); a missing or
  wrong-typed column is a precise, named refusal.
- **CQL2 filtering, genuinely pushed down.** `filter_capable()` reports
  `true`. `compile_predicate` turns a CQL2 filter into a real
  `iceberg::expr::Predicate` over comparison (`=`, `<>`, `<`, `>`, `<=`,
  `>=`), `IS [NOT] NULL`, `[NOT] IN`, and `AND`/`OR`/`NOT` on the table's own
  boolean/integer/floating-point/string columns — the subset `iceberg-rust`
  can express faithfully. A `datetime` interval query compiles the same way
  against an operator-declared `timestamptz` column.
  Single-item lookup (`item`) evaluates its filter honestly in-process
  against the one fetched row (three-valued SQL logic), rather than refusing
  filtered lookups outright: an excluded row and a missing id come back
  identically, matching `tellurion-postgis`'s own single-item semantics.
- **One id per row, on every read surface.** A physical row has exactly one
  flat-position id, identical whether it's read through an unfiltered
  `items` page, a bbox/CQL2/`datetime`-narrowed one, or `item` with or
  without its own filter — an id harvested from any listing always
  round-trips through `item` to the same row.
- **Rows read through the crate's own Arrow/Parquet reader**
  (`iceberg::arrow::ArrowReaderBuilder`), not a hand-rolled decoder.
- **Derived facts, never invented.** `row_estimate` comes from the snapshot's
  own `total-records` summary property; `extent` is folded from every live
  data file's bbox-column statistics (all-or-nothing — one file missing
  stats and the whole derivation gives up rather than reporting a partial
  bbox); `srid` stays `None` because nothing in Iceberg metadata or this
  slice's locator declares one.
- **Feature-gated and standalone-provable.** Default off
  (`--features iceberg`), same posture as `pmtiles`/`flatgeobuf`/`geoparquet`;
  the standalone build genuinely decouples from `postgis`.
- **57 hermetic tests.** Every test builds a real, disk-backed Iceberg table
  through Iceberg's own in-process memory catalog and real writer/append
  calls, then serves it over a real HTTP loopback listener speaking only the
  two REST endpoints this driver's own client calls. No test reaches a real
  network service — a committed binary fixture can't substitute here because
  Iceberg metadata embeds absolute file paths and a fresh UUID per commit, so
  every test builds its own from scratch.

## What it deliberately does not do

- **No writes.** Read-only: no write path, no DDL, nothing beyond the
  mandatory `CatalogSource` plus optional `FeatureSource`.
- **No tiles.** `TileSource` is never implemented; a collection routed to an
  `iceberg` storage on the tiles lane fails the router's ordinary
  missing-capability check.
- **No CRS reprojection.** `crs_capable` stays at its trait default `false`
  (unchanged, not overridden) — the same posture `flatgeobuf`/`geoparquet`
  take; `tellurion-postgis` is the only driver in the workspace that
  overrides it.
- **No spatial CQL2 predicates.** Every `SpatialOp` (`S_WITHIN`,
  `S_CONTAINS`, `S_DISJOINT`, `S_TOUCHES`, `S_OVERLAPS`, `S_CROSSES`,
  `S_EQUALS`) and `S_INTERSECTS` are refused by name — they would target the
  WKB geometry column, which has no scalar comparison in Iceberg. `bbox` is
  the only spatial predicate this driver pushes down.
- **No `LIKE`/`BETWEEN`/`CASEI`, no temporal functions.** All refused by
  name, never silently dropped or partially applied.
- **No `datetime` parameter on single-item lookup.** OGC API Features never
  defines one there, so `compile_datetime_predicate` stays an `items`-only
  path.
- **No SQL or Glue catalog.** REST is the only catalog transport this driver
  speaks.
- **No object-store access.** The driver wires `iceberg::io::
  LocalFsStorageFactory` and nothing else — every manifest and data-file
  read resolves straight off local disk (or a mount reachable as one). No
  S3/GCS/ADLS-backed `FileIO` is wired in this slice.
- **No validation against a real external REST catalog.** Every claim above
  is proven against the REST protocol shape this crate's own fixture server
  speaks, not against a third-party catalog implementation (Nessie/Polaris-
  class or otherwise).
- **No guaranteed id stability across restarts or compaction.** A fresh
  snapshot pin can renumber every row's flat position; nothing today claims
  otherwise.

## Performance characteristics

Pushdown depth depends entirely on whether a CQL2 filter or `datetime`
interval is active, and the two paths behave very differently:

- **Bbox-only queries prune for real.** With no CQL2 filter and no
  `datetime` interval, `bbox` is pushed into `TableScan::with_filter`, so
  Iceberg's own manifest evaluator prunes whole data files by column
  statistics before any Parquet read, and `ArrowReader` applies a genuine
  Parquet `RowFilter` on the files that remain. `number_matched` is the exact
  sum of every planned task's `record_count`.
- **A CQL2 filter or `datetime` interval disables that pruning entirely, on
  purpose.** Pushing `bbox` (or the filter) into the scan would let Iceberg
  discard files and rows before this driver ever sees them, which breaks the
  one-id-per-row guarantee above — a pruned file's rows would silently
  renumber every later row's position. So the moment either is active,
  `items` reads the full, unfiltered, un-bboxed plan and decides
  `bbox`/`filter`/`datetime` in-process, per row. This is a full walk of
  every row of every planned file on every call — a deep page under a filter
  re-reads every file before it and every row of every file after — and
  `number_matched` is always `None` (an exact count would require reading
  every row). This is a deliberate, documented tradeoff for the id
  guarantee, not an oversight.
- **Manifest listing is real network I/O**, and it is cached.
  `IcebergBackend::planned_tasks` caches the resolved `Vec<FileScanTask>`
  keyed by bbox plus filter/datetime fingerprint, in a `moka` cache bounded
  to 256 entries with a manually-checked TTL (default 300s, overridable per
  storage via the locator's `plan_cache_ttl_s`) — the same shape the
  router's own descriptor cache uses. Because the whole table is pinned to
  one snapshot for the backend's lifetime, a cached plan can never actually
  go stale during that lifetime; the TTL exists to match the established
  cache shape and so a future snapshot-refresh feature doesn't inherit a
  cache with no staleness concept at all.
- **File-skip on read** locates the starting file for a resumed page cheaply
  from each task's own `record_count`, never re-touching the manifest for a
  page that starts past the first few files — sound for both the unfiltered
  whole-table plan and the bbox-only pushdown plan, since neither ever
  partially prunes rows out of a task's declared count.

## Operational requirements

- **Catalog:** REST only, via `iceberg-catalog-rest`'s `RestCatalog`. No SQL
  catalog, no AWS Glue.
- **Storage:** local filesystem only, via `iceberg::io::LocalFsStorageFactory`
  — a table's data files must be reachable as local paths (or a mount that
  looks like one) from wherever the server process runs.
- **Config:** one locator string per storage, in the existing
  `StorageDecl.url_env` field — no new `StorageDecl` field, no new config
  concept. Namespace, table, geometry column, and bbox columns are mandatory;
  a missing one is refused at driver-build time naming the field.
- **Dependency footprint:** `iceberg`/`iceberg-catalog-rest` 0.9 pin
  `arrow`/`parquet` to `^57.1`, a second compiled arrow/parquet tree
  alongside the workspace's own `parquet` 59.1 (used by
  `tellurion-geoparquet`) — two separately compiled instances, no shared
  `RecordBatch` type, no free conversion between them. Accepted as a cost,
  not resolved by this slice.

## Productionizing: what's left, and what belongs to other tracks

What's left is concrete and mostly outside this driver's own scope:

- **Object-store access.** Wiring an S3/GCS/ADLS-backed `FileIO` alongside
  (or instead of) the local-filesystem one this spike hard-codes is required
  before this driver can serve a table whose data files live in the object
  storage almost every production Iceberg deployment actually uses. Not
  attempted here.
- **Validation against a real external REST catalog.** Everything above is
  proven against this crate's own fixture server, which speaks exactly the
  two REST endpoints the driver's client calls. Pointing this driver at a
  real deployment (Nessie/Polaris-class or otherwise) needs its own
  end-to-end pass first.
- **Per-driver CQL2 conformance (#105, open).** `filter_capable()` is a
  single crate-wide bool today; this driver's real conformance surface —
  comparison/null/`IN`/boolean-connective predicates over scalar columns,
  nothing spatial, nothing temporal, nothing `LIKE`/`BETWEEN` — should be
  expressed as this driver's own declared conformance classes once #105
  replaces the bool, rather than continuing to advertise (or under-claim)
  one flag for the whole capability.
- **Spatial indexing for index-less drivers (#103, open).** #103's own
  survey already names this driver's real posture — file/manifest pruning
  from column statistics, explicit refusal of `S_INTERSECTS` — as one of the
  drivers a shared H3/S2 cell index would target. Closing that gap is out of
  scope here and belongs to #103's own spike.
- **CRS reprojection** is a separate, cross-driver piece of work (only
  `tellurion-postgis` does this today) and isn't specific to Iceberg.
- **Id stability across restarts or compaction.** Flat-position ids aren't
  guaranteed stable today. Whether that instability should become the
  documented contract, or be engineered away with a stable id scheme
  independent of file order, is an open call this spike does not make.
- **Paging-token opacity.** The token's plaintext embedded snapshot id is
  defensively sound (a stale one is refused outright) but is an internal
  physical identifier riding on the wire; hardening it is a small, separate
  follow-up if it turns out to matter.

## Verdict

The spike answered both of its own questions: Tellurion can serve real OGC
API Features traffic off an Iceberg table through a standard REST catalog
with no database of its own, and CQL2 pushdown lands as an honest, verifiable
subset — never a partial or silently-wrong one. The result already exceeds
"spike" scope: a read-only `CatalogSource` + `FeatureSource`, real bbox and
CQL2 pushdown, snapshot-pinned paging with a plan cache, and 57 hermetic
tests, merged in `crates/tellurion-iceberg`. What remains before a production
deployment is bounded and largely orthogonal to this driver's own logic:
object-store-backed storage access, validation against a real external REST
catalog, and the two adjacent tracks (#105, #103) this driver's findings feed
but do not resolve.
