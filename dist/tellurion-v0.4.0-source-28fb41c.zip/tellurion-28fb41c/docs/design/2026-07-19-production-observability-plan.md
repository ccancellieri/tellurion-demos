# Production observability implementation plan

**Goal:** Add bounded per-lane request metrics, truthful structured slow-request diagnostics, separate liveness/readiness, and a configurable tested SIGTERM drain for issue #62.

**Architecture:** One request-local phase collector in `tellurion-core` is used by transparent resolver, registry, style, routed-source, and cache wrappers. The server owns label classification, slow-event policy, readiness polling, probe routes, and shutdown orchestration. Protocol handlers and fenced filter, policy, write/outbox, volume-driver, benchmark, and UI code remain unchanged.

**Technology:** Rust, Tokio task-local state, Axum middleware and graceful shutdown, the existing Prometheus exporter, `tracing`, Serde YAML, and Tower test services.

## Global constraints

- Work only in the issue #62 worktree and never modify the shared main checkout.
- Keep one issue-linked pull request and small first-person commits with no attribution trailers.
- Never expose internal ids, credentials, raw queries, headers, physical names, or attacker-controlled unmatched path values in metrics or probe responses.
- Preserve `http_request_duration_seconds`; extend its bounded labels instead of adding a duplicate histogram.
- Do not modify protocol handlers, filters, policy, write/outbox, volume-driver, benchmark, or UI code.
- Every behavior starts with a failing test and ends with scoped formatting, warnings-denied clippy, and tests.

---

### Task 1: Configuration and inherited slow threshold

**Files:**

- Modify `crates/tellurion-core/src/config.rs`
- Modify `crates/tellurion-core/src/settings.rs`
- Modify `config/example.yaml`, `config/e2e.yaml`, and both deployment config files

**Produces:** `MetricCollectionRef`, four new `ServerConfig` fields, `SettingsDecl::slow_request_ms`, `EffectiveSettings::slow_request_ms`, and `DEFAULT_SLOW_REQUEST_MS = 1_000`.

- [ ] Add failing tests for defaults, explicit parsing, zero-duration rejection, zero threshold rejection at every settings level, empty allowlist segments, duplicate triples, and nearest-level precedence.
- [ ] Run `cargo test -p tellurion-core settings::tests config::tests`; expect compilation failure because the fields do not exist.
- [ ] Add this public allowlist shape and serde-backed server fields:

```rust
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct MetricCollectionRef {
    pub tenant: String,
    pub catalog: String,
    pub collection: String,
}
```

- [ ] Extend `resolve_effective_settings` with the existing nearest-level `find_map` pattern and a 1000 ms default.
- [ ] Validate positive durations/thresholds, non-empty public segments, and unique triples.
- [ ] Put explicit production defaults in every reference config; allowlist only the demo collection in example/e2e.
- [ ] Run `cargo fmt --all --check`, warnings-denied core clippy, and all core tests.
- [ ] Commit with `I add production observability settings`.

---

### Task 2: Request-local exclusive phase accounting

**Files:**

- Create `crates/tellurion-core/src/observability.rs`
- Modify `crates/tellurion-core/src/lib.rs`

**Produces:** `Phase::{Routing, Query, Cache, Encode}`, `PhaseSnapshot`, `scope_request`, async `in_phase`, and synchronous `enter_phase`. All are no-ops outside a request scope.

- [ ] Add paused-Tokio-time tests proving nested phases are exclusive, guards restore state after errors/panics, no-scope calls are harmless, and `encode(total)` saturates at zero.
- [ ] Pin this nested result: two milliseconds cache work, three milliseconds nested query, then five milliseconds cache work produces cache=7 ms and query=3 ms.
- [ ] Run `cargo test -p tellurion-core observability::tests`; expect missing-module failure.
- [ ] Implement private task-local mutable state. Each guard records elapsed time minus child time on drop and restores its parent.
- [ ] Export only the immutable snapshot and scope/phase entry functions.
- [ ] Run focused fmt, clippy, and tests.
- [ ] Commit with `I add request phase accounting`.

---

### Task 3: Transparent core wrappers and storage readiness

**Files:**

- Modify `crates/tellurion-core/src/observability.rs`
- Modify `crates/tellurion-core/src/context.rs`
- Modify `crates/tellurion-core/src/router.rs`

**Produces:** observed resolver/registry/style wrappers, observed feature/tile/volume sources, cache/population phase nesting, and `Router::probe_storages() -> Result<()>`.

- [ ] Add delegating-wrapper tests for every trait method, success/null/error behavior, feature filter capability, tile vector layers, grant filters, and fallback ordering.
- [ ] Add router tests showing every catalog is probed once and one failing catalog produces a named core error.
- [ ] Run focused tests and confirm missing wrappers/methods.
- [ ] Wrap context-owned resolver, registry, and style objects once during construction/reload.
- [ ] Wrap routed read sources at `features_source`, `tiles_source`, and `volume_source`; do not wrap write/outbox traits.
- [ ] Nest cached population as Encode inside Cache so query wrappers subtract backend time from encode and population time from cache:

```rust
in_phase(Phase::Cache, async {
    let populate = Box::pin(in_phase(Phase::Encode, populate));
    cache.get_or_populate_with_ttl(key, populate, ttl).await
}).await
```

- [ ] Implement storage probing through each mandatory existing `CatalogSource`; do not add a second driver-health capability.
- [ ] Run all core gates.
- [ ] Commit with `I observe shared request boundaries`.

---

### Task 4: Readiness state, polling, and probe routes

**Files:**

- Create `crates/tellurion-server/src/readiness.rs`
- Modify `crates/tellurion-server/src/app.rs`
- Modify `crates/tellurion-core/src/config.rs`

**Produces:** cloneable `Readiness`, `probe_once`, polling `run`, and top-level `healthz`/`readyz` handlers.

- [ ] Add failing tests for initial false, ready, failed, recovered, and irreversible draining states.
- [ ] Add fake registry/storage success, failure, and Tokio-timeout tests.
- [ ] Add route tests: health is always 200; ready is 503 problem+json until successful, 200 while ready, and 503 during drain; tenant auth never applies.
- [ ] Add `readyz` to the reserved tenant segments and extend the validation test for both probe names.
- [ ] Implement generic response bodies that reveal no dependency details.
- [ ] Log detailed probe failures only on state transitions and one recovery event.
- [ ] Run server/core fmt, clippy, and focused tests.
- [ ] Commit with `I split liveness from readiness`.

---

### Task 5: Per-lane metrics and structured slow logs

**Files:**

- Modify `crates/tellurion-server/src/metrics.rs`
- Modify `crates/tellurion-server/src/app.rs`

**Produces:** state-aware `observe_request`, finite lane classification, bounded public labels, effective threshold lookup, extended histogram, and one slow-request event.

- [ ] Add failing tests for Features, Tiles metadata, MVT, PNG, styled PNG, 3D, Styles, STAC, control, and unmatched lane values.
- [ ] Render a private Prometheus recorder after requests with distinct unknown tenant/collection values; assert neither raw value appears.
- [ ] Capture a local tracing writer; assert exactly one slow event strictly above threshold and none at/below it.
- [ ] Assert the event has total/routing/query/cache/encode fields and excludes URI, query, authorization, internal ids, and physical names.
- [ ] Derive lane from `MatchedPath` and response content type. Resolve tenant before using it as a label. Emit collection only for an exact fully-qualified allowlist match; otherwise use fixed sentinel values.
- [ ] Scope `next.run(request)` inside `scope_request`, record the histogram after response classification, and emit the warning after threshold resolution.
- [ ] Run all server fmt, clippy, and unit tests.
- [ ] Commit with `I add bounded lane diagnostics`.

---

### Task 6: Configurable graceful drain and SIGTERM proof

**Files:**

- Modify `crates/tellurion-server/src/shutdown.rs`
- Modify `crates/tellurion-server/src/main.rs`
- Modify `crates/tellurion-server/tests/binary.rs`
- Modify `crates/tellurion-server/Cargo.toml` and `Cargo.lock`

**Produces:** injectable `serve_until(listener, app, readiness, drain_timeout, shutdown_future) -> anyhow::Result<()>` and the production signal adapter.

- [ ] Add deterministic listener tests with a gated in-flight handler; prove readiness flips before drain and the admitted request completes with 200.
- [ ] Add a paused-time deadline test proving a stuck request cannot keep the process alive.
- [ ] Add a Unix-only real-binary test that sends SIGTERM with test-only `libc::kill`, waits for clean exit, and force-kills only during failed-test cleanup.
- [ ] Mark draining before waking Axum, apply the configured timeout after signal, return serve errors, and log one completion/deadline event.
- [ ] Start readiness polling after context construction and preserve the existing startup-address log.
- [ ] Run shutdown unit and binary tests plus server fmt/clippy.
- [ ] Commit with `I prove bounded graceful shutdown`.

---

### Task 7: Deployment and operator documentation

**Files:**

- Modify `docker/Dockerfile`
- Modify `deploy/k8s/base/deployment.yaml`
- Modify `README.md`
- Modify deployment-contract tests in `crates/tellurion-server/src/main.rs`

- [ ] Add a failing test asserting Docker `/healthz`, Kubernetes liveness `/healthz`, readiness `/readyz`, and a 15-second termination grace for the ten-second default.
- [ ] Update only the probe paths and grace period; preserve security context and ports.
- [ ] Document metric labels/allowlisting, slow-log fields, readiness dependencies, and drain ordering, including aggregation examples that drop `collection`.
- [ ] Run the deployment test and `git diff --check`.
- [ ] Commit with `I document production operations`.

---

### Task 8: Convergence, verification, issue ledger, and cleanup

- [ ] Fetch and rebase the isolated branch onto current `origin/main`; never update the shared checkout.
- [ ] Review wrapper delegation for grant filters, CRS, vector layers, filter capability, fallback order, cache coalescing, reload atomicity, and problem+json behavior.
- [ ] Confirm no fenced handler/filter/policy/write/volume/bench/UI file changed.
- [ ] Run:

```bash
cargo fmt --all --check
cargo clippy --workspace --all-targets -- -D warnings
cargo test --workspace
cargo build --workspace --no-default-features
cargo build -p tellurion --no-default-features --features pmtiles
cargo build -p tellurion --no-default-features --features flatgeobuf
cargo build -p tellurion --no-default-features --features geoparquet
cargo build -p tellurion --features valkey
```

- [ ] Run attribution/context-path/secret/PII/internal-id scans over the explicit `origin/main...HEAD` diff and commit-message range.
- [ ] Obtain an independent read-only review with no critical or important correctness, privacy, cardinality, drain, or fence finding.
- [ ] Push one PR closing #62, wait for every CI job, and merge only while clean.
- [ ] Verify #62 closed. Open follow-up issues only for concrete deferred gaps.
- [ ] Remove only this issue's worktree, generated target directory, and merged branches; leave the shared checkout and every other worktree untouched.
