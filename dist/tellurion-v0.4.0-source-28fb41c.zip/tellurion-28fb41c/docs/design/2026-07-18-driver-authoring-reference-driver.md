# Driver authoring guide and reference in-memory driver

Status: approved 2026-07-18 for issue #64.

## Goal

Make Tellurion's storage capability contract understandable and independently
testable by a third-party driver author. Deliver one consolidated guide and a
small GeoJSON-backed reference driver whose contract tests fail whenever the
core trait surface changes.

## Scope

This slice adds:

- `docs/driver-authoring.md`, covering the mandatory and optional driver
  surfaces, descriptor derivation, paging, errors, filtering, and boot
  validation;
- a workspace crate named `tellurion-memory` containing an immutable,
  GeoJSON-backed reference driver;
- executable capability-contract tests and a checklist that a third-party
  author can apply to another driver.

The reference driver is a development and documentation fixture. It is not a
new production-configurable backend and is not registered by
`tellurion-server`. This keeps production wiring and configuration unchanged
while making the complete authoring pattern public and compile-checked.

## Design principles

1. **A real external-crate shape.** The reference lives in its own crate and
   depends on `tellurion-core`, as a third-party driver would. It does not live
   inside core or gain privileged access to router internals.
2. **Mandatory means implemented; optional means honest.** It implements the
   mandatory `CatalogSource` and advertises only `FeatureSource`. Tiles,
   volumes, filtering, and writes remain absent instead of being stubbed.
3. **Immutable data makes the contract easy to inspect.** GeoJSON is validated
   once at construction and stored in deterministic feature-id order. Request
   methods perform no mutation, I/O, or locking.
4. **Protocol policy stays outside drivers.** The reference returns data and
   driver-level errors. Protocol crates continue to own links, media types,
   problem responses, authorization, and response documents.
5. **No new configuration concept.** A factory receives preloaded drivers by
   storage id. It does not read behavior from environment variables or add
   fields to `StorageDecl`.

## Crate and public API

The new crate contains focused modules:

- `src/lib.rs`: crate-level walkthrough and public re-exports;
- `src/driver.rs`: factory, storage-driver wrapper, catalog source, and feature
  source implementations;
- `src/dataset.rs`: validated immutable GeoJSON collection, spatial metadata,
  lookup, and paging;
- `src/error.rs`: reference-driver errors and their mapping to
  `tellurion_core::Error`;
- `tests/contract.rs`: router-level capability contract;
- `tests/features.rs`: data semantics, paging, and refusal behavior.

The public construction surface is deliberately small:

```rust
let roads = MemoryDataset::from_feature_collection("roads", geojson)?;
let driver = MemoryDriver::new([roads])?;

let mut factory = MemoryDriverFactory::new();
factory.insert("memory-main", driver)?;
registry.register(Arc::new(factory));
```

`MemoryDriverFactory::build` looks up `StorageDecl.id` in that preloaded map.
A missing registration and a duplicate dataset name are configuration errors.
The factory name is `memory`; no server feature or runtime configuration is
added in this slice.

## GeoJSON validation and derived metadata

`MemoryDataset::from_feature_collection` accepts a GeoJSON FeatureCollection
object and rejects:

- any other top-level GeoJSON type;
- a feature without a string or numeric `id`;
- duplicate feature ids;
- a malformed geometry or coordinate;
- a non-object `properties` member;
- a `geometry` property that would collide with the physical geometry column.

Features are indexed by their stringified GeoJSON id in a `BTreeMap`. This
provides deterministic keyset order independent of input order. Numeric and
string ids that stringify identically are considered duplicates because the
Features item path also addresses ids as strings.

Construction derives the physical metadata exposed by `CatalogSource`:

- collection name from the builder argument;
- geometry column `geometry` and primary key `id`;
- SRID 4326 because GeoJSON coordinates use CRS84 longitude/latitude order;
- one geometry type only when all non-null geometries share it;
- extent from all valid non-null geometries;
- exact row estimate;
- a union of property names with conservative broad JSON type names;
- no temporal-column claim, because arbitrary JSON strings do not establish a
  temporal schema.

Null geometries remain valid features. They contribute to unfiltered pages and
item lookup but not to the spatial extent or a bbox-selected result.

The geometry walker supports every RFC 7946 geometry type, including nested
geometry collections, and computes envelopes from coordinates rather than
trusting an optional feature-level `bbox`. Bbox intersection includes features
that touch the query boundary. Property types map as follows: booleans to
`boolean`, integral numbers to `bigint`, other numbers to `double precision`,
strings to `text`, and arrays, objects, or conflicting observed types to `json`.
Null alone does not establish a type; an all-null property is reported as
`json`.

## Feature query contract

The reference `FeatureSource` implements:

- `item`: exact id lookup; an absent id is `Ok(None)`;
- `items`: deterministic keyset paging and optional bbox intersection;
- `number_matched`: the exact count after bbox selection and before the page
  window;
- `next_token`: a versioned, encoded form of the last returned feature id only
  when more matching features remain.

Tokens use `v1.` followed by the lowercase hexadecimal UTF-8 bytes of the last
returned id. This intentionally simple format is easy for an author to inspect
without another dependency, while remaining opaque at the API contract: callers
must only follow the server-provided `next` link. Versioning lets the driver
reject an unknown future token format instead of misreading it. The immutable
dataset makes the walk stable for its entire lifetime. A malformed token, a
token naming no feature, zero page size, or an invalid bbox returns
`Error::Invalid`.

The driver does not advertise `filter_capable`. A direct call that nevertheless
passes a filter is rejected with `Error::Invalid` as defense in depth. A
datetime query is rejected the same way because the reference dataset declares
no temporal-column capability. Unsupported inputs are never ignored.

OGC API Features response assembly remains in the protocol crate. The driver
returns a continuation token; the handler places it in a `next` link. The
driver's exact `number_matched` supports the standard response semantics without
requiring every production backend to compute an expensive count.

## Error mapping

The reference crate demonstrates the shared boundary explicitly:

- invalid preload data, duplicate collections, and missing factory
  registration become `tellurion_core::Error::Config`;
- malformed tokens, invalid bbox values, and unsupported query refinements
  become `tellurion_core::Error::Invalid`;
- unexpected backend failures would become `tellurion_core::Error::Storage`,
  though this immutable in-memory implementation has no fallible I/O path;
- a missing feature remains `Ok(None)`, not an error.

Protocol crates retain the only mapping from these core errors to RFC 9457
problem responses. The guide documents the mapping but does not introduce a
driver-specific HTTP type.

## Boot validation and capability tests

`tests/contract.rs` builds the ordinary `Registry` and `Router` with the
reference factory. It proves:

1. a collection routed to the reference driver's Features lane passes
   `Router::validate_catalog`;
2. catalog-derived table, geometry, primary key, extent, row count, and schema
   are visible through the existing descriptor path;
3. an explicit Tiles lane routed to the driver fails with the existing precise
   missing-capability error;
4. a configured physical name absent from the memory catalog fails validation;
5. factory lookup is by storage id and missing registrations fail as
   configuration errors.

`tests/features.rs` proves:

1. a multi-page walk returns every feature exactly once in stable order;
2. bbox selection, exact `number_matched`, and null-geometry behavior;
3. exact item lookup and missing-item behavior;
4. malformed and stale tokens fail rather than restarting a page walk;
5. malformed GeoJSON and duplicate ids fail at construction;
6. filtering and datetime are explicitly refused;
7. `filter_capable()` remains false.

The driver-authoring checklist names these tests beside each obligation. Trait
signature drift breaks compilation of the reference crate, while semantic drift
breaks a named contract test.

## Guide structure

`docs/driver-authoring.md` follows the path a third-party author takes:

1. choose mandatory and optional capabilities;
2. implement `CatalogSource` and physical metadata derivation;
3. implement one optional source completely before advertising it;
4. implement deterministic paging and treat tokens as opaque;
5. map driver errors into the shared core error boundary;
6. declare or refuse CQL2 filtering honestly;
7. register a `DriverFactory` without leaking backend assumptions into protocol
   crates;
8. exercise router boot validation and the conformance checklist;
9. verify default builds remain independent of optional external components.

The guide cites the normative OGC API Features requirements relevant to driver
behavior, but it does not claim that implementing a storage trait alone makes an
HTTP deployment conformant. Conformance belongs to the assembled API surface.

## Parallel-work boundaries

This issue does not modify:

- the CQL2 AST, parser, validators, or backend translators;
- authorization policy or protocol handler enforcement;
- 3D volume traits or driver internals;
- feature writes, schema write validation, or transactional outbox code;
- benchmark scenarios;
- server routes or protocol response models.

The expected tracked changes are the new crate, the authoring guide, this design
record, workspace membership, and the lockfile. If concurrent work changes a
core trait signature, this branch rebases and adapts the reference implementation
without changing that trait.

## Verification

Before the issue PR is opened:

```text
cargo fmt --all --check
cargo clippy -p tellurion-memory --all-targets -- -D warnings
cargo test -p tellurion-memory
cargo test -p tellurion-core
cargo test --workspace
```

The PR also scans its diff and commit history for accidental private context,
personal information, or tool attribution before publication.

## Deferred work

- Runtime registration of an in-memory or file-backed GeoJSON production driver
  is a separate product decision.
- Replacing protocol crates' specialized test doubles is optional follow-up work;
  those doubles often model handler-specific faults that a canonical happy-path
  fixture should not absorb.
- A general cross-driver conformance-test crate may be extracted after a second
  external author proves which helpers are stable enough to publish.
