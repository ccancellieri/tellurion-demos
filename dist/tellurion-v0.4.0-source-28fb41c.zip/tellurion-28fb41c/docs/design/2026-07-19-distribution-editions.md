# Distribution and licensing: the three-edition model

> **Superseded for current licensing and distribution policy.** This historical
> distribution record is retained unchanged; see the 0.3.0 BSL community and
> commercial release decision for the current policy.

Status: proposed — decision record for a Community / Enterprise / Cloud edition
split. It records the owner's direction of 2026-07-19 and the analysis behind
it. It is an engineering and architectural record, **not legal advice**. Any
license text, commercial EULA, contributor agreement, or entitlement wording it
touches on requires review by qualified counsel (Italian and EU software law)
before adoption. The closing section restates this.

## Context and the decision

Tellurion has grown the structural seams for a product-line split: routing over
abstract storage, capability traits, default-off driver features, an optional
policy layer, and a file-backed configuration default. The product direction is
now to package that into three editions:

1. **Community** — free, licensed under GNU AGPL-3.0-only, embedded and
   local-first. A single binary plus local file formats: the embedded
   single-file OGC driver now in development (a SQLite/GeoPackage-based
   read/write driver) alongside the existing local-file drivers (PMTiles,
   FlatGeobuf, GeoParquet, and the local raster path). No database service and
   no container runtime required out of the box; no mandatory account,
   telemetry, or license server; no artificial limits on ordinary local
   analysis.
2. **Enterprise** — commercial, on-premise. Private enhanced database
   capabilities, distributed storage and query, scalable caching, governance /
   SSO / audit, high availability, and operations tooling. Distributed as
   private artifacts (not on crates.io), with offline-capable signed license
   entitlements, fail-closed premium modules that return `application/problem+json`
   errors, entitlement expiry that preserves administrative and export access,
   no phone-home requirement, and no invasive telemetry.
3. **Cloud** — managed multi-tenant service. A private control plane for tenant
   lifecycle, billing, and provisioning, built over the same public data-plane
   contracts the Community edition exposes.

**Recommended model:** feature-based separation. The Community edition stays
AGPL and open; Enterprise and Cloud value is delivered as separate proprietary
modules and services that are genuinely new private code. An organization —
including a commercial enterprise — **may use the Community AGPL edition without
paying.** Payment buys the proprietary modules, commercially licensed builds,
the managed service, and support. AGPL does not restrict commercial or
enterprise use of the Community edition; it attaches reciprocity obligations
(share source of derivatives, including to users served over a network), and the
commercial license is an alternative set of terms for parties that prefer not to
take on those obligations.

### What this decision supersedes

This packaging direction supersedes the earlier framing that the embedded driver
ships default-on *next to* a database-service-first experience. The Community
edition's defaults become embedded and local-first: a database service is
optional infrastructure chosen for scale, not a prerequisite to get started. The
in-flight embedded-driver implementation itself is unchanged by this decision and
must not be edited under this workstream; only the distribution and default-
configuration positioning changes here.

---

## 1. Published state and irrevocable recipient rights

Fourteen crates are published on crates.io at version 0.1.0, each declaring
`license = "AGPL-3.0-only"` (inherited from the workspace manifest):

`tellurion` (the server binary), `tellurion-core`, `tellurion-features`,
`tellurion-tiles`, `tellurion-render`, `tellurion-styles`, `tellurion-places`,
`tellurion-stac`, `tellurion-postgis`, `tellurion-pmtiles`,
`tellurion-flatgeobuf`, `tellurion-geoparquet`, `tellurion-ingest`,
`tellurion-memory`.

Audit facts for these archives:

- Internal dependencies are normalized to versioned registry references at
  0.1.0; there are no path or git dependencies leaking into the published
  archives, and every archive resolves cleanly at 0.1.0.
- No secrets, credentials, private URLs, or personal data are present. Test
  fixtures use obviously dummy localhost values.
- **Compliance gap:** none of the 14 archives embeds a `LICENSE` file. The SPDX
  identifier in each `Cargo.toml` is correct and machine-readable and crates.io
  displays the license, but the archives do not carry the AGPL text itself.
  License-scanning tooling may flag this. The fix is to embed the already-
  declared AGPL text as a `LICENSE` file in each crate root in a future release;
  it changes no license, it only ships the text of the license already declared.

**Rights recipients hold irrevocably.** Anyone who has obtained a 0.1.0 archive
holds, perpetually and irrevocably, the rights AGPL-3.0-only grants: to run the
software for any purpose (including private, commercial, governmental use), to
study and modify it, to redistribute it and modified versions, and to operate it
as a network service — provided they meet AGPL's obligations (license derivative
works under AGPL-3.0-only, make Corresponding Source available to users
interacting with a modified version over a network, and retain copyright and
license notices).

**Yanking hides; it does not revoke.** Yanking a 0.1.0 version removes it from
new dependency resolution and from search on crates.io and prevents new
`Cargo.toml` entries from selecting it. It does **not** revoke any rights already
granted, does not delete or disable copies already downloaded or deployed, does
not force any user to update, and does not remove the ability to redistribute
copies already obtained. The 0.1.0 grant is permanent for everyone who has it.

---

## 2. Copyright ownership and what it enables

The tracked history shows a single copyright holder. All 278 commits are
authored by Carlo Cancellieri (across three email addresses that are variants of
the same person's contact list); there are no external contributors, no
co-authored commits, and no third-party attribution trailers. The repository
declares dual licensing (AGPL-3.0-only plus a commercial license) with a
Contributor License Agreement (`CLA.md`) requiring copyright assignment to the
single holder, and names the copyright holder in `README.md` and
`COMMERCIAL-LICENSE.md`.

**What single-holder status enables.** Because one party owns the copyright to
all first-party code, that party can license the same code under additional terms
without anyone else's consent. This is the legal basis for dual licensing: AGPL
binds licensees (third parties), not the copyright owner, who remains free to
also offer the identical code under a separate commercial license, and to build
proprietary products on it. Relicensing decisions for first-party code do not
require third-party permission.

**What it does not do.** It does not reach back into already-published archives:
a future license change binds only new code and new versions; the 0.1.0 grant
stands (see Section 1). It does not, by itself, differentiate Enterprise from
Community — offering the same code under two sets of terms is a terms difference,
not a capability difference. Paid capability differentiation requires genuinely
new code (Sections 4, 6, 7).

**External contribution policy going forward.** To preserve single-holder status
— the precondition for every model below — every outside contribution must be
covered by the CLA's copyright assignment before it is merged. Today the CLA is
policy enforced by human review; strengthening it into a mechanically recorded
signed agreement (for example a signed-off assertion checked in CI, or a
managed CLA service) is a governance improvement to consider, and its wording is
a matter for counsel. Contributions offered without CLA agreement are handled as
issues, not merges.

---

## 3. Dependency compatibility across distribution scenarios

The dependency audit covered the current workspace (16 member crates — the 14
published above plus `tellurion-cog` and `tellurion-iceberg`, which are workspace
members not yet published at 0.1.0) and 514 external dependencies, 530 packages
total. Zero packages have UNKNOWN or missing license metadata; none are vendored.

**No strong-copyleft third-party dependencies exist.** The audit found no
GPL-2.0, no AGPL, no SSPL, no BUSL, and no Elastic-licensed third-party
dependencies anywhere in the graph. This is the central fact for every scenario
below: among third-party code there are **no** copyleft blockers to a
proprietary or commercial build. The only copyleft third-party dependencies are
two weak-copyleft transitives — `r-efi@5.3.0` and `r-efi@6.0.0`, each licensed
`MIT OR Apache-2.0 OR LGPL-2.1-or-later` — and both offer a permissive branch of
the OR to select. Several dependencies use compound expressions (for example
`ring` = Apache-2.0 AND ISC; the `aws-lc-*` family; `moka`; `unicode-ident`;
`arrow-array`); all are permissive in aggregate and warrant only routine review
in an enterprise context.

### Scenario A — AGPL Community distribution

**Clean.** No dependency is incompatible with AGPL-3.0-only distribution. The
Community edition ships under AGPL-3.0-only as-is.

### Scenario B — commercially licensed Enterprise distribution

Building a proprietary or closed-source binary that links the first-party
Tellurion crates requires a commercial license for those first-party crates. The
party who must (and can) grant that license is the **copyright holder** — Carlo
Cancellieri — licensing his own AGPL-licensed code under commercial terms to
himself and to customers. No third party's permission is needed, because there
are no strong-copyleft third-party dependencies. The only third-party items to
address are the two weak-copyleft `r-efi` transitives, resolved by selecting
their permissive OR-branch (MIT or Apache-2.0); this is a build-configuration and
compliance-documentation task, not a blocker. Compound-license dependencies
warrant a routine enterprise license review but impose no reciprocity.

### Scenario C — proprietary plugins

A **first-party** proprietary Enterprise module that builds on the AGPL crates is
lawful for the same reason as Scenario B: the copyright holder licenses his own
AGPL code to himself under commercial terms, so his own modules are not
constrained by AGPL reciprocity. A **third-party** proprietary plugin that links
the AGPL trait crates is a different question — whether such linking creates an
AGPL derivative work is an open legal question that dynamic loading does not by
itself settle (Section 6). That question is marked for counsel; the safe default
is that third-party proprietary plugins linking the AGPL crates take on AGPL
obligations unless a commercial license is obtained.

### Scenario D — managed Cloud

Operating the Community data-plane as a network service engages AGPL's
network-copyleft: users who interact with a modified version over the network are
entitled to its Corresponding Source. For the owner's own hosted operation this
is satisfied either by keeping the served data-plane's source available or by the
owner's commercial license to his own operation. The proprietary control plane
(tenant lifecycle, billing, provisioning, secrets) is separate private code that
is not a derivative of the AGPL data-plane crates and consumes only their public
contracts. Third-party dependency posture is identical to Scenario B: clean.

---

## 4. Three future models

### Model A — feature-based separation (recommended)

Keep the Community edition AGPL and open. Deliver Enterprise and Cloud value as
separate proprietary modules and services that are **genuinely new private
code**, distributed via private artifacts and composed in a private repository
that depends on the public crates (Section 5). An enterprise may still run the
Community AGPL edition for free; payment buys the proprietary modules, commercial
builds, the managed service, and support.

- **Pros.** It is honest open core: nothing already published is retracted or
  relicensed; the single-holder status already permits it; the paid
  differentiation is new code, which is the legally clean basis for charging
  (not renaming or re-gating identical AGPL code); community trust in the open
  edition is preserved; the public/private boundary maps cleanly onto the crate
  graph and CI.
- **Cons.** Enterprise value must be built as new private code — existing AGPL
  capability cannot simply be walled off and sold; two build graphs and two
  repositories must be maintained; feature-gating and boundary discipline are
  required; the open Community edition remains fully forkable, which is the
  inherent trade of open core.
- **Migration effects.** No change to the published 0.1.0 archives. A new private
  composition repository is created; the public workspace is unchanged; future
  public releases of the database driver stay a basic compatibility driver
  (Section 7).
- **Legal review needs.** Commercial license and EULA text; entitlement and
  offline-license-key terms; selection and documentation of the `r-efi`
  permissive branch; trademark posture for the "Tellurion" name.

### Model B — dual-licensing the common core

Offer the same core under AGPL-3.0-only **or** a commercial license, in the
MySQL/Grafana style. The owner can do this for his own code without third-party
consent.

- **Pros.** Legally the simplest — the owner relicenses code he already owns;
  one codebase; a proven model; a buyer who cannot accept AGPL's reciprocity can
  obtain the identical code under commercial terms.
- **Cons.** By itself it creates no Enterprise *feature* differentiation — it is
  a terms difference, not a capability difference; the AGPL edition remains
  usable and forkable by anyone; it monetizes relief from reciprocity, not
  features; it depends on keeping strict single-holder ownership through the CLA
  for all future contributions.
- **Relationship to A.** B and A compose: dual-license the common core for
  reciprocity relief *and* sell proprietary modules for feature value. The
  recommended stance is A layered over B.
- **Migration effects.** No change to published archives; requires publishing the
  commercial-license terms and keeping the CLA airtight.
- **Legal review needs.** Commercial license text; robustness of the CLA's
  assignment for every future contribution.

### Model C — a future source-available Community license

Relicense **future** Community versions from AGPL to a separate source-available
license (for example a time-delayed or re-hosting-restricted source-available
license).

- **Honest statement (required).** This cannot claw anything back. The already-
  published AGPL-3.0-only 0.1.0 archives, and any forks made from them, remain
  usable — including commercially — forever under AGPL. A future relicense binds
  only new code and new versions; downstream users and forks may continue from
  0.1.0 under AGPL indefinitely. Relicensing does not remove rights already
  granted.
- **Naming precision.** A source-available license is **not** an open-source
  license and must not be described as one. This model would end the Community
  edition's open-source status for new versions.
- **Scope precision.** This model means relicensing future versions to a
  *separate* license. It does not mean adding restrictions to AGPL; AGPL text is
  not modified, and no non-commercial clause is bolted onto it.
- **Pros.** Can constrain competitive re-hosting of future versions while keeping
  source visible.
- **Cons.** A real cost to community and ecosystem trust; loss of open-source
  status for new versions; no retroactive protection (0.1.0 and its forks stay
  AGPL forever); still depends on single-holder ownership and the CLA.
- **Migration effects.** Applies only from a future version onward; existing
  users keep AGPL rights on prior versions.
- **Legal review needs.** Drafting the source-available license itself requires
  qualified counsel; so do the changelog and communications that must state the
  0.1.0 carry-over honestly.

---

## 5. Package and repository boundary

The public and private surfaces are separated at the crate and repository level.

**Public Community surface** (AGPL, on crates.io and in the public workspace):

- The contracts and protocol implementations: config model, router, storage and
  capability traits, cache interface (`tellurion-core`); OGC API Features, Tiles,
  Styles, STAC, and 3D places handlers.
- Rendering and styles for local use (`tellurion-render`, `tellurion-styles`).
- The local and file drivers (PMTiles, FlatGeobuf, GeoParquet, local raster) and
  the embedded single-file driver once it lands.
- The in-memory reference driver (`tellurion-memory`).
- The ingest CLI for ordinary local loading (`tellurion-ingest`).
- The demo UI and the CLI.
- The Community binary with an embedded-first default configuration.

**Private Enterprise surface** (proprietary, private artifacts only):

- Enhanced database capabilities **beyond** the published 0.1.0 baseline. Future
  public releases of the existing database driver remain a basic compatibility
  driver; the scale and operations capabilities are new private code.
- Distributed query and distributed / scalable caching.
- Heavy ingestion orchestration.
- SSO, governance, and audit.
- High availability and operations tooling.
- The Enterprise composition binary and images.

**Private Cloud surface** (proprietary, operated only):

- Tenant lifecycle, metering and billing, the hosted control plane, secrets, and
  managed operations.

**The rule.** Private source never enters the public workspace, the public git
history, the public crate archives, the public build contexts, or the public CI
artifacts. The private side lives in a **separate private composition
repository** that depends on the public crates as ordinary versioned
dependencies. The public build must succeed with **zero** private-registry
credentials — a contributor or CI job with only public access must be able to
build, test, and run the full Community edition. Any capability that cannot be
built without private credentials is, by definition, part of the private surface
and does not belong in the public workspace.

---

## 6. Driver and module boundary

**Keep the in-process Rust trait boundary.** The capability traits in
`tellurion-core` (the `StorageDriver` accessors, the cache and config traits) are
the composition seam. An Enterprise module implements those traits and is wired
into a private composition binary that also depends on the public crates. This is
the simplest technically sound choice: it reuses the existing architecture with
no new runtime machinery, keeps type safety across the boundary, and needs no
plugin loader, no ABI freeze, and no serialization layer between the engine and
its drivers.

An out-of-process protocol boundary (drivers as separate processes speaking a
wire protocol) is the alternative. It would decouple release cycles and language
choices and would give a cleaner physical separation, but it adds a protocol to
design and version, serialization overhead on the hot path, and operational
surface (process supervision, transport, failure handling). It is not warranted
for the current need and is recorded here only as the considered alternative.

**On the legal reasoning, be precise.** Dynamic loading, an out-of-process split,
or any linking arrangement does **not** by itself settle AGPL derivative-work
questions. The Enterprise composition is lawful because the **copyright holder
licenses his own AGPL code under commercial terms** to himself and to customers
(Model A), not because a technical linking arrangement evades copyleft. The paid
differentiation must be genuinely new private code; renaming or repackaging
identical AGPL code does not make it proprietary. For **third-party** proprietary
plugins that link the AGPL crates, whether the result is an AGPL derivative work
is an open legal question — marked for counsel — and the technical boundary
chosen here does not answer it.

---

## 7. Per-crate classification of the 14 published crates

Categories: **Continue-as-Community** (stays AGPL, actively developed in the open);
**Community-maintenance-only** (stays AGPL, kept correct but not a growth area);
**Supersede-with-private-enhanced** (0.1.0 stays AGPL forever; future public
releases stay a basic driver; new capability lands privately as new code);
**Internal-from-next-capability** (a crate becomes unpublished from its next
increment); **Permissive-SDK-candidate** (a contract crate that could be
relicensed permissively to let third parties build drivers without AGPL
reciprocity — subject to legal review).

| Crate | Classification | Note |
|---|---|---|
| `tellurion` (server binary) | Continue-as-Community | The Community binary; ships the embedded-first default configuration. |
| `tellurion-core` | Continue-as-Community; also Permissive-SDK-candidate | Load-bearing foundation for every edition — must stay open. Its trait/contract surface is the natural candidate if the owner later wants third-party driver authors to build without AGPL reciprocity; a clean permissive SDK extraction would need refactoring and is a relicensing decision for counsel. |
| `tellurion-features` | Continue-as-Community | OGC API Features handler. |
| `tellurion-tiles` | Continue-as-Community | OGC API Tiles handler. |
| `tellurion-render` | Continue-as-Community | MVT→PNG rasterization and styling for local use. |
| `tellurion-styles` | Continue-as-Community | OGC API Styles, read-only. |
| `tellurion-places` | Continue-as-Community | 3D places / 3D Tiles delivery. |
| `tellurion-stac` | Continue-as-Community | STAC API surface. |
| `tellurion-pmtiles` | Continue-as-Community | Local/object file tile driver. |
| `tellurion-flatgeobuf` | Continue-as-Community | Local file feature driver. |
| `tellurion-geoparquet` | Continue-as-Community | Local file feature driver. |
| `tellurion-ingest` | Continue-as-Community | Basic local loader; heavy/distributed ingestion orchestration is new private code, not a reclassification of this crate. |
| `tellurion-memory` | Community-maintenance-only | In-memory reference driver; kept correct as a driver-authoring reference, not a feature-growth area. |
| `tellurion-postgis` | Supersede-with-private-enhanced | See the special section below. |

**Categories deliberately left empty among the 14.**
*Internal-from-next-capability* is applied to **none** of the 14. Making an
already-published Community crate unpublished from its next increment would strip
capability from open code and is not done; that category is reserved for
not-yet-published or future crates. The two workspace members not published at
0.1.0 — `tellurion-cog` (local raster, a natural Community driver) and
`tellurion-iceberg` (a REST-catalog / lakehouse driver, whose use case is
scale-tier) — are the crates whose Community-vs-Enterprise placement should be
decided separately before their first publish; that decision is out of scope for
this record.

### Special section — the database driver (`tellurion-postgis`)

- The published **0.1.0 archive stays AGPL-3.0-only and remains available
  forever.** Nothing in this decision retracts it, and yanking would not revoke
  the rights already granted on it (Section 1).
- **Future public releases remain a basic compatibility driver** — a correct,
  conformant PostGIS driver for the Community edition, maintained in the open.
- **New scalability and operations capabilities land privately, as new code.**
  The paid differentiation must be genuinely new private code, not a renamed or
  re-gated copy of the published AGPL driver. From the product direction, the
  differentiating capability areas are: distributed / scalable caching and
  distributed query, advanced admission control (per-tenant fairness and cgroup-
  aware budgets), and governance (SSO, audit, fine-grained authorization at
  scale). These are the Enterprise surface; the basic driver stays Community.

Any decision to relicense a currently-permissive-eligible contract surface, or to
publish `tellurion-cog` / `tellurion-iceberg` under a particular edition, is
subject to legal review before it is executed.

---

## 8. Actions requiring the owner's explicit approval

None of the following is executed by this record; each requires the owner's
explicit, separate approval:

- Changing the root `LICENSE`, `COMMERCIAL-LICENSE.md`, or `CLA.md`.
- Creating, splitting, or changing the visibility of any public or private
  repository (including standing up the private composition repository).
- Any crates.io action — publishing a new version, publishing the `LICENSE`-file
  compliance fix, or yanking any version.
- Adopting a commercial EULA or entitlement / offline-license-key terms.
- Filing for, or asserting, a trademark on the "Tellurion" name.
- Releasing any Enterprise or Cloud artifact.
- Any relicensing of future versions (Models B or C), including selecting or
  drafting a source-available license.

### Not legal advice

This document is a technical and architectural decision record. It is **not legal
advice** and does not establish licensing facts on its own. The final text of any
license, commercial EULA, contributor agreement, or entitlement, and the
adjudication of the open third-party-plugin derivative-work question, require
review by qualified counsel in Italian and EU software law before adoption.
