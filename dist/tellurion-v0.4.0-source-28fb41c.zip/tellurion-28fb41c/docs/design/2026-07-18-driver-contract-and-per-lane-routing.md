# Driver contract v2, derived descriptors, per-lane routing

Status: shipped — design for issues #18 (driver surface breadth), #19 (derived
collection descriptors), #21 (per-lane routing), with the write/index/search
rules of #25/#67 as constraints. #18, #19, #21, and #20 (PMTiles/FlatGeobuf/
GeoParquet drivers) are closed and implemented as described below; the
Iceberg spike (#18 tail) has not started. #25's write lane and #67's derived-
index and search-routing lanes are themselves implemented too — see the
transactional-outbox doc for their own status.

## 1. Driver contract v2

The v0.2 contract grew organically: `StorageDriver` + `FeatureSource` +
`TileSource` + `ConfigStore` + `StyleStore` + `TileCache`, PostGIS implementing
everything. v2 separates what every driver MUST do from what a driver MAY do,
and makes the "may" part advertised rather than assumed.

Mandatory core (every driver):

- `CatalogSource` (new, #18): enumerate the collections this storage can
  serve, with enough physical metadata (table/layer name, geometry column,
  pk, srid) to validate routing at config load. This is the introspection
  entry point that #19 builds on.
- `capacity_hint()` (already shipped in v0.2): drives derived server
  concurrency; drivers that cannot answer return a conservative default.

Capability traits (advertised, optional):

- `FeatureSource` — items/bbox/keyset paging.
- `TileSource` — MVT tile production (server-side encode or native, the trait
  does not care).
- `RasterSource` (future) — rendered/raster reads for formats that carry
  imagery.
- `WriteSink` (future, gated on #25) — transactional writes + outbox append.
- `IndexSink` / `SearchSource` (future, #25) — derived-view apply + search
  reads with a freshness high-water mark.

Rules carried over from v0.1/v0.2, unchanged and load-bearing:

- Protocol crates depend on traits only; driver crates are the only place a
  storage SDK/wire client appears; driver configs stay private to the driver
  crate.
- Capability checks happen at compile time where possible (trait bounds) and
  at config load otherwise (#21 validation) — never at request time.

## 2. Derived collection descriptors (#19)

Configuration stores ONLY: routing (which storage serves which lane for which
collection) and operator OVERRIDES (style, zoom caps, exposed properties,
3D options). Everything else — geometry column type, srid, pk, property
schema, spatial extent (#27), feature count class — is DERIVED by asking the
driver (`CatalogSource` + per-trait introspection), cached with a TTL, and
NEVER persisted.

Precedence: override > derived > default. A derived value never writes back
into config; an override never silently masks a derivation failure (boot logs
the divergence). The effective surface is inspectable read-only at
`/collections/{cid}` and a future `/collections/{cid}/effective` — compute
and show, don't store.

Rationale (one line): a persisted copy of physical reality is a second source
of truth that WILL drift; recomputing from the backend makes an entire bug
family unrepresentable.

## 3. Per-lane routing (#21)

Routing stays the core concept: the router resolves `(tenant, collection,
lane)` → a driver bound to a capability trait. Lanes are the protocol verbs,
not backend names:

```yaml
collections:
  - id: roads
    tenant: public
    routing:
      features: main        # FeatureSource
      tiles:    tiles-store # TileSource (may differ from features)
      search:   index       # SearchSource, freshness-gated (#25)
      write:    main        # WriteSink; index fed via outbox, never directly
    # omitted lanes default to the single storage when unambiguous
```

Validation at config load, fail fast: a lane naming a storage whose driver
does not implement the lane's trait is a boot error listing the capability
the driver lacks. No lane defaults that can silently poison another lane:
lane-specific tuning fields are `Option` with no cross-lane fallback.

Read lanes may declare an ordered fallback tail (`search: [index, main]`)
where the tail is only consulted on freshness-gate refusal or driver error —
a preference, not a merge. Write lanes are exact: one driver, no fallback.

## 4. Write/index constraints (#25, summarized)

Any future `WriteSink`/`IndexSink` implementation is bound by: index = derived
view rebuildable by replay; per-collection transactional outbox; monotonic
sequence, ordered idempotent apply, single consumer (lease only when
clustered); search routes to the index only within a freshness bound, else
falls back to the primary; reconcile = replay the sequence gap, never a full
diff. Full statement lives in #25 and is not duplicated here.

## 5. First implementations

- PostGIS: implements everything mandatory + FeatureSource + TileSource +
  (later) WriteSink. Introspection via information_schema + geometry_columns +
  ST_EstimatedExtent (#27).
- PMTiles (#20): CatalogSource (archive header) + TileSource. Read-only,
  object_store-backed; the proof that a protocol crate runs with the PostGIS
  feature compiled out (#18 acceptance).
- FlatGeobuf (#20): CatalogSource (header) + FeatureSource (http range
  reads, spatial index).
- GeoParquet (#20): CatalogSource (parquet metadata) + FeatureSource
  (predicate pushdown where the reader supports it).
- Iceberg (#18 spike, last): CatalogSource (REST catalog) + FeatureSource;
  TileSource only if server-side MVT encode (shared with #20) proves cheap
  enough.
