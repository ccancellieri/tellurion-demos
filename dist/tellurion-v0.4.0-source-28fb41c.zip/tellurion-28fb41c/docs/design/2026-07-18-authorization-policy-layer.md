# Authorization policy: RBAC + ABAC on top of tenant membership

Status: shipped, including the tile-lane filter pushdown, filtered
single-item GET, features `/collections` listing parity, and relational
registry grant-scope checks §5/§6 originally deferred — design for the
second half of issue `#34`.
The first half (`#17`, extended by `#34`'s OIDC support — see
`2026-07-18-oidc-bearer-token-auth.md`) established *authentication*: a
bearer token or verified JWT resolves to a set of tenant memberships, and a
request may act as a tenant it's a member of, or not. This doc covers what's
built on top of that: fine-grained *authorization* — cross-tenant visibility,
role-based grants, and attribute-based row-level filtering — evaluated once
a request's tenant/catalog/collection have already been resolved to internal
ids.

## 1. Shape

Three new pieces, all optional, all independently absent-by-default:

- **Visibility** (`CatalogDecl.visibility` / `CollectionDecl.visibility`, a
  `VisibilityDecl`): `public: bool` plus `shared_with: [tenant ids]`. Absent
  (the default) is fully private — visible only to a subject with membership
  in the resource's own owning tenant. A collection inherits its catalog's
  visibility unless it declares a non-default one of its own (see
  `Router::effective_visibility`).
- **Policy** (`AppConfig.policy`, a `PolicyConfig`): `roles` (platform-shared,
  available to every tenant) and `tenant_policies` (tenant-custom, visible to
  one tenant only). Each role is a name plus a list of grants; a grant names
  the lanes and collection scope it covers and, optionally, a CQL2-text
  filter template.
- **Richer subjects** (`auth::Subject`, `TenantAuthorizer::subject`): a
  credential now resolves to `(tenant, role)` membership pairs plus an
  arbitrary claims map, not just the flat tenant-membership set `#17`/`#34`
  already used for the coarse tenant gate. `BearerTokenDecl` gained `roles`
  (tenant id -> role names) and `claims`; `OidcClaimsConfig` gained an
  optional `roles` claim.

```yaml
catalogs:
  - id: default
    tenant: public
    visibility:
      public: false
      shared_with: [partner-tenant]

policy:
  roles:
    - name: reader
      grants:
        - scope: { collections: [demo] }
          lanes: [features, tiles]
    - name: org-scoped-reader
      grants:
        - scope: { collections: [demo] }
          lanes: [features]
          filter: "org = {{claims.org}}"
  tenant_policies:
    - tenant: public
      roles:
        - name: reader
          grants:
            - scope: { collections: [demo] }
              lanes: [features, tiles]

auth:
  bearer_tokens:
    - token: dev-token
      tenants: [public]
      roles: { public: [reader] }
      claims: { org: acme }
```

See `config/example.yaml` for the full commented block with every field's
default noted inline.

## 2. Where this runs: strictly post-resolution

`policy::authorize_resource` is the single evaluation entry point. Every
protocol handler calls it *after* its own `Resolver`/`Router` resolve step —
it receives internal tenant/catalog/collection ids only, never an external
one, and it never does its own id resolution. This mirrors the rest of the
codebase's "resolve once, at the top of the handler, then work entirely in
internal ids" discipline (`resolver.rs`'s own doc) and keeps the module
genuinely framework-free: `policy.rs` imports nothing HTTP-shaped.

The credential itself is extracted and turned into a `Subject`
(`TenantAuthorizer::subject`) by each protocol crate's own small
`extract_credential` helper — duplicated once per crate (features, tiles,
places, stac) rather than shared, for the same reason `auth.rs`'s own
`extract_credential` in the server layer isn't reusable: `tellurion-core`
stays framework-free, so nothing it exposes can take an `axum::http::
HeaderMap`. Each duplicate is a ten-line function; the alternative (a new
shared crate, or loosening core's own rule) costs more than it saves.

## 3. Two independent gates

`authorize_resource` evaluates two conditions in order, and both must pass:

### 3.1 Platform isolation (non-overridable)

A subject may see a resource only if:

- it holds membership (any role set, including empty) in the resource's own
  owning tenant, **or**
- the resource's effective visibility is `public: true`, **or**
- the resource's `shared_with` names a tenant the subject holds membership
  in.

Failing this is `Deny`, full stop — no role, no grant, no tenant-custom
policy document can override it. This is deliberately structural: a
tenant-custom policy is looked up *by the resource's own tenant*
(`resolve_role_table(config, resource.tenant_id)`), so even a
misconfigured grant that happens to reference another tenant's collection
id is inert — it is only ever consulted when evaluating a request whose
resolved collection already belongs to that tenant, and a stray reference
to some other tenant's collection id then simply never matches
(`GrantScope::matches`). "Tenant-custom policies can narrow, never widen
across tenants" holds by construction, not by an extra check bolted on top.

### 3.2 RBAC / ABAC, once isolation passes

**Cross-tenant reads never consult RBAC.** A subject who cleared isolation
via `public`/`shared_with` rather than direct membership holds, by
directive 1's own `(tenant, role)` model, no role at all in the resource's
tenant — there is nothing for a grant to match against. Such a read is
always unrestricted. Modeling "tenant B's members read tenant A's data,
filtered" is not supported in this slice — see §6.

**Per-tenant activation.** For a subject who *is* a member: the resource's
tenant has an *effective role table* — platform-shared roles
(`policy.roles`) overlaid by that tenant's own tenant-custom document
(`policy.tenant_policies`), if one exists. A role name declared at both
levels has the tenant-custom grants win outright (whole-role replacement —
the same "nearest wins, maps replace whole, never merged" rule
`SettingsDecl` already applies to `tile_caps`/`stac`). If that overlaid
table is **empty** (no platform roles at all, and no tenant-custom document
for this tenant), RBAC is inactive: access is unrestricted, exactly as
every deployment behaved before this module existed. This is directive 10's
"nothing configured = unchanged" generalized from "the whole policy layer"
down to "this specific tenant" — an operator can turn on RBAC for one
tenant without touching any other.

Once active, RBAC is default-deny: the subject must hold at least one role,
in this tenant, with at least one grant matching the lane and the
collection scope (`GrantScope`: both `catalogs`/`collections` empty matches
everything; otherwise the collection's own internal id or its owning
catalog's must appear).

**Combining matched grants.** Multiple grants can match (several held
roles, or several grants on one role). Any unconditional match (`filter:
None`) makes the whole decision unrestricted — holding one unfiltered grant
always wins over a filtered one from a different role. Otherwise, every
matched grant's filter is claim-substituted and OR-combined
(`Filter::Or`); if none survive substitution (see §4), the decision is
`Deny`.

## 4. Claim substitution and the missing-claim rule

A grant's `filter` is CQL2-text with `{{claims.NAME}}` placeholders. At
evaluation time, each placeholder is replaced by the CQL2 literal spelling
of `subject.claims[NAME]` — a quote-escaped string, a bare number, or
`true`/`false`; an array/object/null claim value has no CQL2 literal shape.

**A placeholder whose claim is missing from the subject makes that specific
grant unsatisfied — excluded from evaluation, not an error, and not a
fallback to "unfiltered".** This is the conservative choice: a grant that
says "only rows where `org = {{claims.org}}`" has no honest substitution for
a subject with no `org` claim, and guessing wrong in either direction
(unfiltered access, or a filter that can never match) is worse than simply
not counting the grant. If every matching grant fails this way, the
decision is `Deny` — the same default-deny a subject with no matching role
at all gets.

Two independent syntax checks exist for a grant's filter template:

- **Eager, at config-load time** (`config::validate_grant_filter_template`):
  every placeholder substituted with a fixed dummy string literal, then run
  through `filter::parse_text`. Catches a broken template regardless of
  claim values — unbalanced parens, a typo'd operator.
- **Defense-in-depth, at request time** (inside `authorize_resource`
  itself): the *real* substituted text is parsed again. This catches what
  the eager check structurally cannot — a claim whose real declared shape
  doesn't fit where the template expects it (e.g. `T_AFTER(observed_at,
  {{claims.since}})` when `since` is configured as a JSON number: the dummy
  check always substitutes a string, which satisfies `T_AFTER`'s
  bare-string-or-`TIMESTAMP(...)` grammar; a real numeric claim does not).
  A failure here is `Err`, not `Deny` — a malformed policy is a
  server-authoring bug (maps to 500), never something a well-behaved client
  caused.

## 5. Which lanes can push a filter down

An `Allow { filter: Some(_) }` decision needs somewhere to go. Whether a
lane can push it into the actual fetch is a property of the *resolved
driver*, not a fixed property of the lane: every caller passes
`lane_supports_filter` as the resolved source's own `filter_capable()`
(`FeatureSource::filter_capable`/`TileSource::filter_capable`), and
`authorize_resource` denies outright — never silently serving unfiltered —
whenever the only matching grants require a filter and the resolved source
reports `false`.

- **Features items-list, single-item GET** (`GET /collections/{cid}/items`,
  `GET /collections/{cid}/items/{fid}`) **and STAC's own items-list /
  single-item GET / item-search** (`/items`, `/items/{fid}`, `/search`'s
  cursor-paged and `ids`-mode paths alike): the grant's filter is AND-merged
  with any user-supplied `filter`/`intersects` into the same `Filter` AST
  `ItemsQuery::filter` already carries for the list lanes; the single-item
  lanes push it straight into `FeatureSource::item`'s own `filter`
  parameter, which PostGIS ANDs into the single-row `WHERE` clause the same
  way `sql::compile_filter` already compiles one for the items-list query
  (`sql::build_item_plan`). A row the filter excludes comes back `Ok(None)`,
  indistinguishable from a genuinely absent id — no existence leak.
- **Tiles — vector, unstyled PNG, styled PNG, and 3D places (glb) alike.**
  All four share one MVT-first fetch (`fetch_mvt`, duplicated once per
  crate — `tellurion-tiles`/`tellurion-places`) and one shared cache. A
  driver whose `TileSource::filter_capable()` reports `true` (PostGIS —
  `sql::build_mvt_plan` ANDs the filter into the MVT subquery's own `WHERE`
  clause, the identical `sql::compile_filter` compiler) gets its filter
  pushed both into that query and into the cache key, via a policy
  fingerprint (`cache::TileKey::policy_fingerprint`, see that type's own doc
  for the exact composition): a stable hash of the resolved,
  post-claim-substitution filter, `None` for unrestricted access. This is
  what makes filtered and unfiltered requests for the same tile coordinate
  never collide in the cache, while still letting two subjects who resolve
  to the *same* effective filter share one entry, and keeping the
  unfiltered case's cache key byte-for-byte what it always was. A driver
  that stays at the trait default (`false` — PMTiles, whose pre-baked
  archives have no query to narrow) still denies a filtered-only grant
  exactly as before.
- **3D places' true-solid-geometry path (`#15`/`#41`, `VolumeSource`).**
  Covered by the pushdown too, through the volume query's own seam:
  `VolumeSource::volume_tile` takes the same grant filter `TileSource::mvt_tile`
  does, with a matching `filter_capable()` marker, and the PostGIS driver
  compiles the filter into the volume query's `WHERE` clause with the same
  filter compiler the MVT subquery uses. The `glb_tile` handler's places
  checkpoint gates on the *resolved volume source's own* capability when one
  applies — not the sibling `TileSource`'s — so a filtered-only grant against
  true solid geometry is served, filtered. The fail-closed denial remains
  only for a volume source that genuinely can't compile a filter. See
  `tellurion-places::handlers::authorize_places`'s own doc.

A subject whose *only* matching grant carries a filter is denied on a lane
whose resolved driver can't compile one (never silently served unfiltered);
a subject who additionally holds an unconditional grant reads normally.

## 6. Out of scope (this slice)

Named here, not hidden:

- **Filtered cross-tenant reads.** §3.2 — a non-member reading via
  `public`/`shared_with` always reads unrestricted; there is no way in this
  slice to grant a *filtered* view to another tenant's members.
- ~~**Filtering the `VolumeSource` query itself.**~~ Landed since this doc
  was first written — see §5: the volume query now has a real filter seam
  and a filtered grant is served, filtered, on the solid-geometry path.
- **Structured per-tenant OIDC role claims.** `OidcClaimsConfig::roles` is
  flat — every role it names applies uniformly across every tenant
  membership the token carries. A claim shaped like Keycloak's nested
  `resource_access` (different roles per tenant, from one token) isn't
  parsed.
- **Cross-tenant reachability through the outer `#17` gate.** The existing
  per-tenant `enforce_tenant_auth` middleware (`tellurion-server::app`) is
  untouched by this slice — it still hard-denies a subject with zero
  membership in the URL's own tenant before a request ever reaches a
  handler. This means `shared_with`/`public` cross-tenant access, as
  implemented, is reachable when `auth:` is unconfigured (fully open) or
  when the subject already has *some* relationship to the resource's tenant
  via that outer gate; a subject who authenticates only as tenant A hitting
  tenant B's own URL prefix to reach a resource B shares with A is blocked
  by that outer gate before this module ever runs. Relaxing the outer gate
  to defer to this module's own isolation check needs a resource-level
  (catalog, at minimum) probe at a URL layer that today intentionally only
  resolves as far as the tenant segment — a real but separable follow-up;
  every isolation/RBAC/ABAC rule in this doc is fully implemented and
  fully unit-tested against `policy::authorize_resource` directly,
  independent of whether the outer gate's own relaxation ever lands.

## 7. Testing

Fully testable without any IdP, matching the existing OIDC design's own
guarantee — `policy::authorize_resource`'s unit tests
(`tellurion-core/src/policy.rs`) build `Subject`s by hand; the per-crate
HTTP-level tests in `tellurion-features`/`tellurion-tiles`/
`tellurion-places`/`tellurion-stac` use static bearer tokens exclusively
(no JWT signing, no fake IdP server needed to exercise the policy layer
itself — that machinery already exists for the OIDC half in `auth.rs` and
is untouched here).

## 8. The write lane (`#68`)

`PolicyLane::Write` grants the two item-mutation endpoints
(`PUT`/`DELETE /collections/{cid}/items/{fid}`,
`tellurion-features::write_handlers`), the same tenant/catalog/collection
scoping as any read lane and evaluated through the identical
`policy::authorize_resource` checkpoint — `write_handlers::
authorize_write_lane` is that crate's own copy of `handlers.rs`'s
`authorize_lane`, scoped to `PolicyLane::Write`. A write grant is never
implied by any read grant, and no read grant is ever implied by a write
grant: a role that should do both names both lanes explicitly.

Row-level write conditions (a grant that would only let a subject write rows
matching some predicate) are out of scope for this slice — `WriteSink::apply`
has no filter parameter to receive one, and there is no honest way to
enforce it at this layer without one. Rather than silently ignore a `filter`
declared alongside `write` in a grant's `lanes`, or silently widen it to an
unfiltered grant, `AppConfig::validate` rejects the combination outright, at
config-load time, with a message naming both the offending lane and the
reason (`validate_grant`) — the same "enforced or refused, never silently
ignored" principle every other policy rule in this doc already follows.

Before this lane existed, every write was fail-closed under any configured
access control at all (`auth:` present, or any `policy:` roles declared) —
there was no grant shape that could ever authorize one. That gate is gone;
a deployment with no access control configured (no `auth:`, so no way to
resolve a `Subject` at all) keeps the exact open-by-default behavior every
other lane already has without `auth:`.
