# Tellurion v0.2 — 3D Places, Styles, and 3D Rendering

Status: shipped in v0.2.

## Goal

Introduce "3D places" as the next protocol family: 3D features (footprint + height →
extruded volumes), style documents, and both vector and server-rendered/styled tile
delivery of 3D content. Same doctrine as v0.1: **routing is the core concept**, drivers
stay capability-based and backend-neutral, protocol crates stay DB-free, caches stay
byte-budgeted and L2-ready.

## Standards mapping (statuses as of 2026-07 — re-verify before claiming conformance)

| Surface | Standard | Status | Use |
|---|---|---|---|
| Volume hierarchy + 3D content discovery | OGC API — 3D GeoVolumes (OGC 22-001) | candidate draft | Follow its URL shape (`/collections/{cid}/3dtiles`) but declare honestly — no approved conformance class to claim |
| 3D content delivery | 3D Tiles 1.1 (OGC 22-025, community standard) | approved | `tileset.json` with implicit quadtree tiling + **glTF binary (.glb) content only** — skip legacy b3dm/i3dm |
| Style documents | OGC API — Styles (OGC 20-009) | long-running draft | `/styles`, `/styles/{id}`, `/styles/{id}/metadata`; MapLibre Style JSON as the native encoding |
| Styled tiles | combines OGC API — Tiles Part 1 (approved) tile addressing with the per-style resource pattern from OGC API — Maps (OGC 20-058, approved) | Tellurion convention — this specific URL shape is not itself defined by either spec | `/collections/{cid}/styles/{styleId}/map/tiles/{tms}/{tileMatrix}/{tileRow}/{tileCol}.png` |
| 3D-attribute vector tiles | MVT 2.1 via Tiles Part 1 | approved | height/min_height as MVT properties → client `fill-extrusion` (MapLibre) |
| CityJSON 2.0 | community standard | approved | OUT of v0.2 (future encoding; keep scope tight) |

## Architecture: the MVT-first lane generalizes to 3D

The v0.1 PNG lane is MVT-first (probe PNG cache → miss → probe/populate MVT → render →
cache). v0.2 extends the same pattern to two new encodings, so **the driver layer is
untouched** — `TileSource::mvt_tile` remains the only geometry-fetch path, and the
PostGIS driver needs zero changes for 3D beyond config declaring which properties carry
height:

```
TileKey.encoding: Mvt | Png | Glb | PngStyled(style_id)
lane Glb:       probe Glb → miss → MVT lane → extrude + mesh → glb → cache
lane PngStyled: probe     → miss → MVT lane → render with style doc → cache
```

- Extrusion inputs come from MVT feature properties (`height_property`,
  `min_height_property`, `default_height`) declared in config — the driver already
  ships properties in the tile; no new SQL.
- Consequence: any current or future driver that can serve MVT gets 3D places for
  free. This is the routing abstraction paying off.
- Trade-off accepted: extrusion from tile-local MVT means geometries clipped at tile
  borders get vertical seam faces. The 256-cell MVT buffer keeps this visually
  acceptable for v0.2. True solid-geometry sources (e.g. a future CityJSON store) can
  later add a `VolumeSource` capability trait without breaking anything — the Router
  refuses it today via `CapabilityUnsupported`.

## New / changed components

1. **tellurion-core** (small, additive):
   - `Encoding::{Glb, PngStyled(String)}` on `TileKey` (cache key must include the
     style id).
   - `Places3dConf { height_property, min_height_property: Option, default_height:
     f64, exaggeration: f64 }`, optional on `CollectionDecl`.
   - `StyleStore` trait (mirror of `ConfigStore` — styles are config-like and their
     storage stays generic: file impl in v0.2, DB/Valkey-backed later). Style
     documents are MapLibre Style JSON.
2. **tellurion-render** (pure, still no I/O):
   - `extrude_mvt_to_glb(mvt, places3d, tile_bounds) -> Result<Vec<u8>>`: footprint
     polygons → prism meshes (fan-triangulated caps, quad-strip walls), quantized
     positions, single-buffer glb. The glb container is small enough to hand-write
     (JSON chunk + BIN chunk) — no glTF crate dependency.
   - `render_mvt_to_png_styled(mvt, style_subset)`: extend the renderer to accept
     per-layer paint from a resolved style document (fill/stroke/opacity by layer
     name) instead of the single collection `StyleConf`.
3. **tellurion-places** (new protocol crate, DB-free):
   - `GET /collections/{cid}/3dtiles` → 3D Tiles 1.1 `tileset.json`: implicit
     quadtree tiling aligned with WebMercatorQuad, geometricError ladder derived from
     the zoom range, content template pointing at
     `.../3dtiles/tiles/{level}/{y}/{x}.glb` (spec-required `{level}`/`{x}`/`{y}`
     tokens, placed row-first), region bounds from collection extent plus
     max height.
   - `GET /collections/{cid}/3dtiles/tiles/{tileMatrix}/{tileRow}/{tileCol}.glb`
     → Glb lane; 204 when empty.
4. **tellurion-styles** (new protocol crate, DB-free):
   - Read-only surface: `/styles`, `/styles/{styleId}` (content negotiation, MapLibre
     JSON native), `/styles/{styleId}/metadata`; per-collection style associations
     listed in collection metadata links.
   - Styled tile route in tellurion-tiles:
     `/collections/{cid}/styles/{styleId}/map/tiles/WebMercatorQuad/{tileMatrix}/{tileRow}/{tileCol}.png`
     → PngStyled lane.
5. **tellurion** (server): mount places + styles routers; aggregate their conformance
   consts; `config/example.yaml` gains `places3d:` and `styles:` sections.
6. **Bench**: add glb and styled-PNG sweeps (cold/warm) with RSS tracking — meshing
   is the first CPU+allocation-heavy lane and must respect the same request ceiling,
   per-zoom caps and load-shed as everything else.

## Out of scope for v0.2

CityJSON encoding; b3dm/i3dm legacy; terrain/quantized-mesh; style editing (the
manage-styles conformance class requires authorization, which Tellurion doesn't have
yet); oblique 2.5D server-rendered scenes (client `fill-extrusion` plus glb cover the
need).
