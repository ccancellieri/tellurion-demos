# Dynamic Multi-Tenant Control Plane Implementation Plan

**Goal:** Build a database-backed, dynamically configurable Tellurion control
plane with OIDC authentication, hierarchical path policies, scoped
administration, and a tenant-aware web interface.

**Architecture:** A backend-neutral asynchronous control-store contract owns
configuration, registry resources, authorization bindings, audit, and a durable
change outbox. SQLite and PostgreSQL implement the same contract. Serving
processes consume validated immutable snapshots and ordered changes; the
administrative API and UI remain isolated from OGC/STAC routes.

**Tech stack:** Rust 2021, Tokio, Axum 0.8, tokio-postgres/deadpool-postgres,
rusqlite 0.40, serde, arc-swap, TypeScript 6, custom elements, Vite, and Vitest.

## Global constraints

- YAML seed data is imported only when the selected control store is empty.
- A static boot envelope is read on every start to locate the store.
- PostgreSQL and SQLite pass the same backend-neutral contract suite.
- Revision polling and the durable outbox are authoritative; notifications are
  optional wake-ups and default off behind Pgpool.
- OIDC/OAuth2 is native; SAML is accepted only through an OIDC broker.
- Authorization is default-deny and scoped platform -> tenant -> catalog ->
  collection.
- Policies match canonical registered routes, never raw string prefixes.
- Administrative writes are atomic with revision, audit, and outbox records.
- Secrets are references only and never enter store rows, audit, or exports.
- Each slice has its own issue and worktree and is merged before dependents.
- Worktrees share one Cargo target cache and are removed after merge.

## Delivery graph

```text
1 contract
├── 2 SQLite ────────┐
└── 3 PostgreSQL ────┤
                     ├── 4 boot/migration ── 5 convergence
1 ── 6 OIDC identity ── 7 path policy
4 + 5 + 6 + 7 ── 8 admin API ── 9 platform UI ── 10 tenant UI
all ── 11 operational/security acceptance
```

## Task 1: Backend-neutral control-store contract

**Files:**

- Create: `crates/tellurion-core/src/control_model.rs`
- Create: `crates/tellurion-core/src/control_store.rs`
- Modify: `crates/tellurion-core/src/error.rs`
- Modify: `crates/tellurion-core/src/lib.rs`
- Modify: `crates/tellurion-core/Cargo.toml`

**Interfaces:**

```rust
pub type ControlRevision = u64;

pub struct PrincipalIdentity { pub issuer: String, pub subject: String }
pub enum ControlScope {
    Platform,
    Tenant { tenant_id: String },
    Catalog { tenant_id: String, catalog_id: String },
    Collection { tenant_id: String, catalog_id: String, collection_id: String },
}
pub struct RoleBinding {
    pub principal: PrincipalIdentity,
    pub role: String,
    pub scope: ControlScope,
}
pub enum PolicyEffect { Allow, Deny }
pub struct PolicyCondition { pub kind: String, pub config: serde_json::Value }
pub struct PathPolicy {
    pub id: String,
    pub effect: PolicyEffect,
    pub methods: Vec<String>,
    pub patterns: Vec<String>,
    pub conditions: Vec<PolicyCondition>,
}
pub struct ControlSnapshot {
    pub config: AppConfig,
    pub role_bindings: Vec<RoleBinding>,
    pub path_policies: Vec<PathPolicy>,
}
pub struct VersionedControlSnapshot {
    pub snapshot: ControlSnapshot,
    pub revision: ControlRevision,
}
pub struct ControlChangeSet {
    pub idempotency_key: Option<String>,
    pub operations: Vec<VersionedControlOperation>,
}
pub struct ControlCommit {
    pub revision: ControlRevision,
    pub changed_resources: Vec<String>,
}
pub struct ControlEventCursor {
    pub revision: ControlRevision,
    pub ordinal: u32,
}
pub struct ControlEvent {
    pub revision: ControlRevision,
    pub ordinal: u32,
    pub changed_resources: Vec<String>,
}
pub struct AuditRequestContext {
    pub method: String,
    pub canonical_path: String,
    pub correlation_id: String,
}
pub enum BootstrapOutcome { Bootstrapped(ControlRevision), AlreadyInitialized(ControlRevision) }
pub struct VersionedControlOperation {
    pub expected_entity_version: Option<String>,
    pub operation: ControlOperation,
}
pub enum ControlOperation {
    ReplacePlatformSettings(AppConfig),
    PutTenant(TenantDecl),
    PutCatalog(CatalogDecl),
    PutCollection(CollectionDecl),
    TombstoneResource { scope: ControlScope },
    PermanentlyDeleteResource { scope: ControlScope },
    PutRoleBinding(RoleBinding),
    DeleteRoleBinding { principal: PrincipalIdentity, scope: ControlScope, role: String },
    PutPathPolicy(PathPolicy),
    DeletePathPolicy { id: String },
}

#[async_trait]
pub trait ControlStore: Send + Sync {
    async fn bootstrap_if_empty(&self, seed: &ControlSnapshot, actor: &PrincipalIdentity)
        -> Result<BootstrapOutcome>;
    async fn current_revision(&self) -> Result<Option<ControlRevision>>;
    async fn load_snapshot(&self) -> Result<VersionedControlSnapshot>;
    async fn transact(&self, expected: ControlRevision, actor: &PrincipalIdentity,
        request: &AuditRequestContext, changes: &ControlChangeSet)
        -> Result<ControlCommit>;
    async fn changes_since(&self, after: Option<ControlEventCursor>, limit: u32)
        -> Result<Vec<ControlEvent>>;
}
```

- [ ] Add failing tests for duplicate ids, broken ownership references, missing
  binding scopes, empty changesets, non-monotonic events, and invalid snapshots.
- [ ] Run `cargo test -p tellurion-core control_model -- --nocapture`; confirm
  compilation fails because the new module is absent.
- [ ] Implement the types and validation, delegating configuration validation to
  `AppConfig::validate()` and returning named core errors.
- [ ] Under `test-support`, add
  `assert_control_store_contract(store: Arc<dyn ControlStore>)`; verify
  bootstrap-once, reload, CAS conflict, idempotency, atomic audit/outbox, and
  ordered change paging.
- [ ] Implement an in-memory conformance store behind `test-support`; it is a
  test double and never a production backend.
- [ ] Run `cargo test -p tellurion-core control_store --features test-support`,
  `cargo clippy -p tellurion-core --all-targets --features test-support -- -D warnings`,
  and `cargo fmt --all --check`.
- [ ] Commit as `Add the dynamic control-store contract`.

## Task 2: SQLite backend

**Depends on:** Task 1.

**Files:**

- Create: `crates/tellurion-control-sqlite/Cargo.toml`
- Create: `crates/tellurion-control-sqlite/src/lib.rs`
- Create: `crates/tellurion-control-sqlite/src/schema.rs`
- Create: `crates/tellurion-control-sqlite/migrations/001_control_store.sql`
- Create: `crates/tellurion-control-sqlite/tests/control_store.rs`
- Modify: `Cargo.toml`, `Cargo.lock`

**Interface:**

```rust
pub struct SqliteControlStore;
impl SqliteControlStore {
    pub async fn open(path: impl AsRef<Path>) -> Result<Self>;
}
```

- [ ] Add a failing test that installs schema version 1 once, reopens the same
  file, and preserves the current revision.
- [ ] Run `cargo test -p tellurion-control-sqlite migration_is_idempotent` and
  confirm the missing implementation failure.
- [ ] Implement normalized resource tables plus append-only revisions, audit,
  and outbox; enable foreign keys, WAL, and a bounded busy timeout.
- [ ] Implement CAS with `BEGIN IMMEDIATE`; apply domain changes, audit, outbox,
  and revision in one transaction. Use `spawn_blocking` for rusqlite work.
- [ ] Run the shared contract against a temporary file.
- [ ] Add an idempotency test that replays one key 1,000 times and observes one
  revision and one audit/outbox pair.
- [ ] Run crate tests, warning-free clippy, and format checks; commit as
  `Add the SQLite control-store backend`.

## Task 3: PostgreSQL backend

**Depends on:** Task 1. Independent of Task 2.

**Files:**

- Create: `crates/tellurion-control-postgres/Cargo.toml`
- Create: `crates/tellurion-control-postgres/src/lib.rs`
- Create: `crates/tellurion-control-postgres/src/schema.rs`
- Create: `crates/tellurion-control-postgres/src/store.rs`
- Create: `crates/tellurion-control-postgres/migrations/001_control_store.sql`
- Create: `crates/tellurion-control-postgres/tests/control_store_live.rs`
- Modify: `Cargo.toml`, `Cargo.lock`

**Interface:**

```rust
pub struct PostgresControlStore;
impl PostgresControlStore {
    pub async fn connect(database_url: &str) -> Result<Self>;
}
```

- [ ] Add an ignored live test using `TELLURION_TEST_CONTROL_DATABASE_URL` and a
  unique schema; run migrations twice and invoke the shared contract.
- [ ] Run the ignored test and confirm the missing implementation failure.
- [ ] Implement transactions using `SELECT ... FOR UPDATE` on the singleton
  revision row and keyset ordering on `(revision, ordinal)` for outbox pages.
- [ ] Do not execute `LISTEN` in the constructor or pooled store methods.
- [ ] Add a test wrapper that changes pooled connections between calls and prove
  ordinary revision polling observes every commit.
- [ ] Run crate tests, the ignored live contract, warning-free clippy, and format
  checks; commit as `Add the PostgreSQL control-store backend`.

## Task 4: Boot envelope, bootstrap, and migration

**Depends on:** Tasks 1–3.

**Files:**

- Create: `crates/tellurion-core/src/bootstrap.rs`
- Create: `crates/tellurion-server/src/control_bootstrap.rs`
- Modify: `crates/tellurion-core/src/config.rs`, `lib.rs`
- Modify: `crates/tellurion-server/src/main.rs`, `app.rs`, `Cargo.toml`
- Modify: `crates/tellurion-ingest/src/operator.rs`
- Modify: `config/example.yaml`, `README.md`

**Interfaces:**

```rust
pub struct BootEnvelope {
    pub control_store: ControlStoreLocator,
    pub seed: AppConfig,
}
#[serde(tag = "backend", rename_all = "snake_case")]
pub enum ControlStoreLocator {
    LegacyFile,
    Sqlite { path: PathBuf, poll_interval_ms: u64 },
    Postgres { url_env: String, poll_interval_ms: u64, pooled_proxy: bool },
}
pub async fn open_control_store(envelope: &BootEnvelope)
    -> Result<Arc<dyn ControlStore>>;
```

- [ ] Add parsing tests for legacy, SQLite, PostgreSQL secret references,
  missing locators, inline credentials, and poll intervals outside 250–60,000 ms.
- [ ] Run `cargo test -p tellurion-core bootstrap`; confirm failure.
- [ ] Implement store selection, secret resolution, bootstrap-on-empty, and
  authoritative snapshot loading. Never log URL or seed content.
- [ ] Preserve the existing file store/watcher only for explicit legacy mode;
  do not mount dynamic control routes there.
- [ ] Add operator commands
  `migrate-control-store --config config.yaml --dry-run|--apply`; apply refuses a
  non-empty destination.
- [ ] Test bootstrap, mutate store, alter seed, restart, and prove store state
  wins while the locator is still read.
- [ ] Run focused core/server/ingest tests, clippy, and format checks; commit as
  `Bootstrap dynamic configuration from a static store locator`.

## Task 5: Replica convergence and atomic activation

**Depends on:** Tasks 1–4.

**Files:**

- Create: `crates/tellurion-server/src/control_consumer.rs`
- Modify: `crates/tellurion-core/src/context.rs`
- Modify: `crates/tellurion-server/src/main.rs`, `reload.rs`, `metrics.rs`,
  `readiness.rs`

**Interface:**

```rust
pub async fn run_control_consumer(
    ctx: Arc<AppContext>, store: Arc<dyn ControlStore>, registry: Arc<Registry>,
    readiness: Readiness, poll_interval: Duration,
);
```

- [ ] Add paused-time tests for no change, one revision, missed revisions,
  duplicate wake-ups, invalid candidate retention, and later recovery.
- [ ] Run `cargo test -p tellurion control_consumer`; confirm failure.
- [ ] Extract one snapshot activation function used by file reload and control
  reload; build all dependencies before one `AppContext` swap.
- [ ] Implement jittered polling, ordered catch-up, validation, backoff, and
  applied-revision update only after successful activation.
- [ ] When a consumer is older than retained outbox history, load one validated
  current snapshot and resume from that revision; never guess across a gap.
- [ ] Add metrics for store revision, applied revision, lag, activation time,
  activation failures, and poll failures without revision-valued labels.
- [ ] In pooled-proxy mode, start no notification listener and prove polling-only
  convergence.
- [ ] Run focused server tests, clippy, and format checks; commit as
  `Apply control-store revisions atomically`.

## Task 6: OIDC principals and platform administration

**Depends on:** Tasks 1 and 4. Completes issue #155's OIDC-admin gap.

**Files:**

- Create: `crates/tellurion-core/src/identity.rs`
- Modify: `crates/tellurion-core/src/auth.rs`, `config.rs`, `context.rs`, `lib.rs`
- Modify: `crates/tellurion-server/src/app.rs`

**Interfaces:**

```rust
pub struct TrustedIssuerSet;
impl TrustedIssuerSet {
    pub async fn authenticate(&self, token: &str) -> Result<AuthenticatedSubject>;
}
pub struct AuthenticatedSubject {
    pub principal: PrincipalIdentity,
    pub claims: HashMap<String, serde_json::Value>,
}
```

- [ ] Add tests for trusted/unknown issuers, signature, audience, expiry, required
  `sub`, independent JWKS caches, rotation, and token-redacted errors.
- [ ] Run focused auth tests and confirm new cases fail.
- [ ] Add verified `(issuer, sub)` identity to `Subject`; preserve memberships and
  ABAC claims. Give static recovery tokens only configured synthetic identities.
- [ ] Select a validator using unverified `iss` only after matching the trusted
  snapshot; never fetch discovery for an untrusted issuer.
- [ ] Resolve platform admin from stored platform bindings; retain static
  `platform_admin` only for optional break-glass recovery.
- [ ] Add an OIDC fixture representing SAML upstream authentication and prove no
  SAML parser or metadata route exists in Tellurion.
- [ ] Resolve tenant membership and roles from stored issuer/group/claim mappings;
  raw token claims without a registered mapping grant no role.
- [ ] Run core/server auth tests, clippy, and format checks; commit as
  `Authorize platform administrators through trusted OIDC principals`.

## Task 7: Hierarchical bindings and canonical path policies

**Depends on:** Tasks 1 and 6.

**Files:**

- Create: `crates/tellurion-core/src/control_policy.rs`
- Create: `crates/tellurion-core/src/control_path.rs`
- Modify: `crates/tellurion-core/src/control_model.rs`, `lib.rs`
- Create: `crates/tellurion-control/Cargo.toml`
- Create: `crates/tellurion-control/src/lib.rs`, `middleware.rs`
- Modify: `Cargo.toml`, `Cargo.lock`

**Interfaces:**

```rust
pub struct ControlRequestContext {
    pub method: String,
    pub canonical_path: String,
    pub route_template: String,
    pub scope: ControlScope,
}
pub fn authorize_control(subject: &AuthenticatedSubject,
    request: &ControlRequestContext, snapshot: &ControlSnapshot)
    -> ControlDecision;
pub enum ControlDecision { Allow, Deny }
```

- [ ] Add a table-driven role matrix covering all scopes, downward inheritance,
  no upward inheritance, explicit deny, default deny, and delegation ceilings.
- [ ] Add attack tests for encoded separators, dot segments, repeated separators,
  invalid UTF-8, trailing ambiguity, prefix collisions, and false ownership.
- [ ] Run core policy/path tests and confirm modules are absent.
- [ ] Compile anchored literal, `*`, and `**` segment patterns during snapshot
  validation; perform no request-time regex compilation.
- [ ] Reject any delegated statement outside the actor's effective allow envelope.
- [ ] Implement one middleware checkpoint: canonicalize, resolve ids, verify
  ownership, build scope, authorize, attach audit context, then call the handler.
- [ ] Run core/control tests, clippy, and format checks; commit as
  `Add hierarchical path-based control policies`.

## Task 8: Versioned administrative API

**Depends on:** Tasks 4–7. Extends issue #110 beyond whole-document mutation.

**Files:**

- Create: `crates/tellurion-control/src/dto.rs`, `problem.rs`, `router.rs`,
  `service.rs`, `session.rs`, `simulator.rs`
- Create: `crates/tellurion-control/tests/admin_api.rs`
- Modify: `crates/tellurion-control/src/lib.rs`
- Modify: `crates/tellurion-server/src/app.rs`, `main.rs`, `Cargo.toml`

**Interface:**

```rust
pub fn router() -> axum::Router<Arc<AppContext>>;
pub struct MutationOptions {
    pub expected_entity_version: String,
    pub idempotency_key: Option<String>,
    pub dry_run: bool,
}
pub struct MutationPreview {
    pub valid: bool,
    pub effective_diff: serde_json::Value,
    pub impacted_resources: Vec<String>,
}
```

- [ ] Add route tests for platform/tenant/catalog/collection settings, trusted
  issuers, claim mappings, bindings, policies, assets, styles, audit, effective
  views, and the server-published settings schema; legacy mode has none.
- [ ] Add tests for auth, scope, `If-Match`, dry-run, idempotency, conflicts,
  final settings, inheritance reset, atomic changesets, audit redaction, and
  `application/problem+json`.
- [ ] Run the admin API test and confirm failure.
- [ ] Implement scope-filtered reads with ETag, deployment revision, effective
  values, and leaf provenance; delegated admins never receive raw snapshots.
- [ ] Translate DTOs to validated changesets, run delegation/impact checks, and
  invoke `ControlStore::transact` once for an applied mutation.
- [ ] Implement staged disable/tombstone and separate permanent delete requiring
  a fresh ETag and no live children.
- [ ] Implement policy simulation without session creation, token emission, or
  impersonation.
- [ ] Implement OIDC Authorization Code with PKCE: generate state, nonce, and
  verifier; validate the callback; create an encrypted server-side session or
  signed `HttpOnly`, `Secure`, same-site cookie; require CSRF on mutations; and
  revoke the local session on logout. Add state-replay, nonce, callback-error,
  expiry, cookie, and CSRF tests.
- [ ] Run control/server tests, clippy, and format checks; commit as
  `Expose the hierarchical administrative API`.

## Task 9: Platform sysadmin UI

**Depends on:** Task 8.

**Files:**

- Create: `ui/src/lib/control-api.ts`, `control-api.test.ts`
- Create: `ui/src/elements/control-shell.ts`, `scope-navigation.ts`,
  `settings-editor.ts`, `identity-providers-panel.ts`, `audit-panel.ts`
- Create: `ui/src/control-workspace.css`
- Modify: `ui/src/main.ts`, `style.css`
- Modify: `crates/tellurion-server/src/ui_assets.rs`

**Interface:**

```typescript
export interface ControlApi {
  get<T>(path: string): Promise<{ value: T; etag: string }>;
  preview<T>(path: string, value: T, etag: string): Promise<MutationPreview>;
  apply<T>(path: string, value: T, etag: string): Promise<MutationResult>;
}
export interface MutationPreview {
  valid: boolean;
  effectiveDiff: unknown;
  impactedResources: string[];
}
export interface MutationResult { revision: number; etag: string; }
```

- [ ] Add client tests for credentials, CSRF, ETag, `If-Match`, idempotency,
  RFC 9457, login, forbidden, and conflict responses.
- [ ] Implement a control-only adapter; never persist tokens in browser storage.
- [ ] Add shell tests proving unauthorized scopes are absent, deep links persist,
  and keyboard focus follows scope changes.
- [ ] Implement platform overview, tenant wizard, trusted issuers, global
  settings/profiles, audit, and replica status beside the existing map workspace.
  Build settings forms from the server schema and approved UI hints rather than
  duplicating field rules in TypeScript.
- [ ] Implement draft -> preview -> diff/impact -> apply; on conflict preserve the
  draft and reload the new server state.
- [ ] Run `npm test`, `npm run build`, UI embed tests, and clippy; commit as
  `Add the platform control panel`.

## Task 10: Tenant, catalog, and collection UI

**Depends on:** Task 9.

**Files:**

- Create: `ui/src/elements/tenant-dashboard.ts`, `catalog-admin.ts`,
  `collection-admin.ts`, `access-admin.ts`, `policy-simulator.ts`
- Create: `ui/src/lib/effective-settings.ts`, `effective-settings.test.ts`
- Modify: `ui/src/elements/control-shell.ts`, `control-workspace.css`

- [ ] Add projection tests for provenance, overrides, `final`, reset inheritance,
  and missing parent values.
- [ ] Implement tenant dashboard, catalog wizard, settings/profiles, users,
  bindings, policies, visibility, audit, and jobs using the current scope path.
- [ ] Implement collection metadata, assets, representations, styles, routing,
  publication, and staged deletion. Keep reference and ingest/copy distinct.
- [ ] Show inherited and direct bindings separately and explain rejected
  delegation without exposing hidden principals or scopes.
- [ ] Implement read-only policy simulation with visible principal, method, path,
  allow/deny result, bindings, statements, and conditions.
- [ ] Add desktop/mobile keyboard, focus, error, loading, empty, and forbidden
  browser tests.
- [ ] Run UI tests/build and commit as
  `Add tenant catalog and collection administration`.

## Task 11: Operational, security, and migration acceptance

**Depends on:** Tasks 1–10.

**Files:**

- Create: `crates/tellurion-server/tests/control_plane.rs`
- Create: `crates/tellurion-server/tests/control_plane_pgpool.rs`
- Create: `docs/operations/control-plane.md`
- Create: `docs/operations/control-plane-migration.md`
- Modify: `deploy/compose.yaml`, `deploy/k8s/base/deployment.yaml`
- Modify: `config/example.yaml`, `README.md`

- [ ] Add end-to-end role/isolation tests across platform, two tenants, catalogs,
  collections, OGC lanes, control routes, service account, and publishers.
- [ ] Add encoded-path, normalization, prefix, ownership-chain, and root-path
  security tests that assert rejection before handler/store execution.
- [ ] Run two contexts through pooled PostgreSQL connections, drop all optional
  wake-ups, and prove polling/outbox convergence and restart catch-up.
- [ ] Cover unavailable store, failed candidate, retained snapshot, rollback as a
  new revision, break-glass disabled/enabled, and audit redaction.
- [ ] Document store locator, secret references, backups, migration, Pgpool
  defaults, lag metrics, failed revisions, break-glass, and import/export.
- [ ] Run `cargo fmt --all --check`, workspace clippy with warnings denied,
  `cargo test --workspace --locked`, UI tests/build, and `git diff --check`.
- [ ] Scan the diff and fixtures for secrets and personal information; commit as
  `Complete control-plane operational acceptance`.

## Merge and cleanup protocol

For every task:

1. create or reuse its linked issue and record blockers;
2. run the worktree collision preflight;
3. create an issue-named worktree from current `origin/main`;
4. implement only that issue and run focused gates;
5. open a draft pull request linked to the issue;
6. review for secrets, personal information, and unrelated changes;
7. merge only after dependencies are present on `main`;
8. verify merged state from a clean checkout;
9. remove the issue worktree and branch;
10. record disk use before starting the next slice.
