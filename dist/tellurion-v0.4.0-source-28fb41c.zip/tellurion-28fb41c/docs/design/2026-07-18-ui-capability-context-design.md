# Capability-driven operator workspace

## Goal

Make the browser workspace render large and heterogeneous collections from the
capabilities that Tellurion advertises, while letting an operator address a
specific tenant and catalog without introducing a second configuration model.

The workspace remains a transient map composition. Selecting a tenant, catalog,
collection, or representation does not copy data and does not mutate server
configuration.

## Scope

This slice completes the UI half of issue #49 and the first remaining navigation
slice of issue #48:

- make tenant and catalog context URL-addressable;
- discover a tenant's catalogs through its directory resource;
- follow collection and TileSet links instead of constructing capability guesses;
- render vector tiles using every advertised source-layer name;
- choose a representation through an explicit, deterministic fallback policy;
- retain bounded GeoJSON preview as an inspection tool;
- expose loading, failure, and fallback decisions to keyboard and screen-reader
  users.

Creating tenants, catalogs, collections, assets, styles, ingest jobs, or analysis
jobs is outside this slice. Authentication configuration and token entry are also
outside it: requests use the browser's existing same-origin credentials and the
server's configured trust boundary.

## Context model

The workspace context is the pair `(tenantId, catalogId)`.

The tenant is supplied through `?tenant=...`; absent or blank values use the
existing `public` default. Tellurion deliberately does not enumerate tenants at
the service root, so the UI does not add a global tenant browser.

After resolving the tenant value, the UI requests `/{tenant}/`. Its advertised
Features-root links are reduced to unique catalog choices while retaining each
root URL. The catalog supplied through `?catalog=...` is selected when it belongs
to the tenant; otherwise the UI selects the first advertised catalog and reports
the fallback. The UI follows the selected Features root's `data` link to the
collection list rather than reconstructing a route. Changing either context value
updates the query string and reloads the catalog workspace.

All initial data requests receive the active tenant explicitly, and subsequent
requests follow validated advertised links. Default identifiers stay available
only as initial values; they are no longer embedded inside fetch helpers.

The collection list is cursor-paginated. The workspace loads one server page and
exposes a `Load more collections` action whenever the response advertises a `next`
link. A short page does not imply completion, and the UI never walks every page
automatically.

## Capability discovery

Collection links remain the entry point. For each collection added to the map, the
workspace lazily resolves and caches a rendering plan:

1. Follow a `tilesets-vector` link when present.
2. Follow a TileSet-list entry's `self` link to a WebMercatorQuad TileSet resource.
3. Read the TileSet's typed MVT and PNG templates, `mediaTypes`, `layers`, and
   matrix limits.
4. Validate every programmatic URL relative to its source document and require the
   current origin before fetching it or handing it to MapLibre. Display-only links
   retain the broader HTTP(S) navigation policy.
5. Fall back to other advertised collection capabilities when discovery fails or a
   usable representation is absent.

The cache is browser-local and scoped by tenant, catalog, and collection. Context
changes discard it, preventing metadata from one catalog being reused for another.

## Representation policy

The selection order is:

1. **Vector tiles:** use the advertised typed MVT template and every non-empty
   `layers[].id`. Each source layer receives simple geometry-aware default paint so
   aliases and multi-layer PMTiles archives render without a guessed name.
2. **Raster tiles:** use the separately advertised typed PNG template when vector
   metadata is unavailable or unusable.
3. **Bounded GeoJSON preview:** fetch only the first advertised `items` page when
   no tile representation can be used.
4. **Unavailable:** keep the collection in the layer list but show a named error
   when none of these capabilities is usable.

The chosen mode and any fallback reason appear in the collection details and live
status. A feature-capable collection no longer defaults to downloading GeoJSON
when a scalable tile representation is available. The existing preview action
remains available independently for inspection.

## Module boundaries

- `ui/src/lib/api.ts` owns typed HTTP reads for the tenant directory, collection
  page, TileSet list, TileSet metadata, and feature page. Its functions accept the
  active context or a validated advertised link.
- `ui/src/lib/tile-url.ts` owns conversion of a server-advertised row-first tile
  template into MapLibre's `{z}/{x}/{y}` tokens while preserving its explicit
  output format and query string.
- `ui/src/lib/map.ts` owns pure capability selection, context parsing, layer-state
  helpers, and MapLibre-independent rendering-plan types.
- `ui/src/elements/operator-workspace.ts` owns orchestration, accessible controls,
  lazy discovery, MapLibre source/layer lifecycle, and user-visible status.

The TileSet handler adds a second `item` link for PNG because `mediaTypes` alone
does not provide a client with a PNG URL template. No server route changes: the
new link names the format-negotiated tile endpoint that already exists. No other
Rust crate, OpenAPI document, workspace manifest, lockfile, or generated `ui/dist`
artifact changes in this slice.

## Errors and accessibility

Tenant-directory, collection, TileSet, tile, and feature failures name the failed
resource without exposing credentials. A failed preferred representation triggers
the next advertised option and reports the reason; exhaustion produces an error
instead of an apparently empty map.

Context controls have explicit labels. Status and fallback messages use the
existing live regions. Collection selection retains focus, and layer visibility,
removal, and zoom actions remain keyboard-operable. Source-layer names and the
active representation are readable text rather than color-only state.

## Verification

Pure unit tests cover:

- URL context parsing and serialization;
- catalog extraction and de-duplication from a tenant directory;
- MVT, PNG, GeoJSON, and unavailable selection;
- invalid or unsafe advertised links;
- external collection aliases;
- multi-layer TileSet metadata;
- row-before-column tile-template conversion;
- explicit MVT and PNG TileSet links plus WebMercatorQuad zoom limits;
- bounded collection-list pagination through the advertised `next` link;
- cache/state reset across context changes.

The final gates are `npm run build` and `npx vitest run` in `ui/`, followed by a
live browser pass for desktop, narrow layout, keyboard navigation, loading,
fallback, and error states. The known Vite warnings for the MapLibre and lazy 3D
chunks are not expanded by importing another mapping runtime.
