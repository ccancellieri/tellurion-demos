# Tenant auth: static bearer tokens + OIDC

Status: shipped — design for issue #17 (static bearer tokens, the
tenant-authorization seam) and its OIDC half, issue #34. Supersedes the v0.1
design doc's "Out (deliberately): ... built-in authentication (reverse
proxy's job)" line: `#17` added an in-process seam ahead of that call, and
`#34` extends it to real identity providers without walking it back —
running behind a reverse proxy that handles auth upstream is still fully
supported (it's what an absent `auth:` section is), but it's no longer the
only option.

## 1. Shape

`auth:` is a struct, not a backend-selecting enum: `bearer_tokens` (a list)
and `oidc` (optional) are independently present or absent and compose. An
operator can run:

- Neither — the permissive default, byte-for-byte the pre-`#17` behavior.
  `ContextState::authorizer` is `None` and the enforcement middleware skips
  straight past every tenant route with no extra work at all.
- `bearer_tokens` only — `#17`'s original slice: dev/test tokens, or
  long-lived service credentials, each authorizing a fixed set of tenant
  *internal* ids.
- `oidc` only — every request authenticates against a real identity
  provider.
- Both at once — the case `#34` was written for: a few static tokens for
  service accounts sit alongside an OIDC issuer for human users, checked by
  the same authorizer against the same per-request tenant.

```yaml
auth:
  bearer_tokens:
    - token: dev-token-change-me
      tenants: [public]
  oidc:
    issuer: "https://accounts.example.com"
    audience: "tellurion"
    claims:
      tenants: tenants   # claim name; accepts an array or a space-separated string
    clock_skew_s: 60
    jwks_ttl_s: 300
```

See `config/example.yaml` for the full commented-out block with every field's
default noted inline.

## 2. Decision flow

A presented `Authorization: Bearer <value>` is resolved in this order:

1. **Static map lookup, first.** `value` is looked up in `bearer_tokens`
   directly — a string comparison, no parsing. A match wins outright: allow
   if the token's tenant set contains the target tenant, deny (403,
   `NotAuthorized`) otherwise. This is deliberate and cheap: a service
   account's opaque static token is never run through JWT decoding, and
   there's no ambiguity about which credential source "owns" a given value.
2. **OIDC, only on a static miss.** If `value` didn't match any static
   entry and `oidc` is configured, it's parsed and verified as a JWT:
   signature against the issuer's JWKS (RS256, or ES256 for a P-256 key),
   then `iss`/`aud`/`exp`/`nbf` with `clock_skew_s` leeway. On success,
   tenant memberships are read from the claim named by `claims.tenants` and
   checked the same way a static token's `tenants` list is: allow if it
   contains the target tenant, deny (403, `NotAuthorized`) otherwise.
3. **Neither.** A static miss with no `oidc` configured (or a JWT that
   fails verification for any reason — bad signature, expired, wrong
   issuer/audience, unknown `kid`, unsupported algorithm, not even
   well-formed) is denied as 401 (`NoCredential`). An invalid token is
   *not* a 403: 403 means "this credential is valid but doesn't cover this
   tenant," which was never established. This mirrors RFC 6750's own
   `invalid_token` -> 401 (not 403) for a bearer token that doesn't
   validate.

Both paths land in the exact same `AuthDecision`/`DenyReason` the server
layer already turns into an RFC 9457 problem+json body — an OIDC-driven 401
or 403 looks identical to a static-token-driven one, and neither the
response body nor any log line the request path emits ever contains the raw
token value (a fixed rule since `#17`; `#34` extends the same discipline to
every OIDC-specific error case).

## 3. JWKS discovery, caching, and the bounded-refresh property

`jwks_uri` isn't configured directly — it's discovered from
`{issuer}/.well-known/openid-configuration` the first time a JWKS lookup is
needed, then cached alongside the keys themselves under one TTL
(`jwks_ttl_s`). The cache is either *fresh* (a fetch attempt — successful or
not — happened within the last `jwks_ttl_s`) or *stale*:

- A **fresh** cache answers every lookup, hit or miss, from memory with no
  network call. An unknown `kid` against a fresh cache is rejected
  immediately.
- A **stale** cache triggers exactly one refresh attempt, gated by an
  internal single-flight lock: every request that also observes a stale
  cache queues behind that lock instead of firing its own fetch, then
  re-checks freshness once it's through (by construction, always resolved
  by then — the refresh, success or failure, always marks the cache fresh
  again before releasing the lock).

The load-bearing consequence: a flood of unknown/random `kid`s — an
attacker probing, or a misbehaving client — costs the identity provider at
most one JWKS request per TTL window, never one per request. A refresh that
fails (issuer unreachable, non-2xx, malformed JSON) still counts as
"attempted" and still marks the cache fresh, so a persistently-down issuer
degrades to "every OIDC token rejected as unknown `kid`, at most one
upstream request per `jwks_ttl_s`" — not a retry storm against a struggling
provider. Operators who want faster recovery from a transient IdP blip
should lower `jwks_ttl_s`, understanding that it also raises steady-state
JWKS request volume.

## 4. Reload safety: no network at config-validate time

`AppConfig::validate()` (run on every load and every reload attempt, before
anything is swapped in) checks the `oidc:` block's *shape* only — `issuer`
parses as an absolute `http`/`https` URL, `audience` and `claims.tenants`
are non-empty, `jwks_ttl_s` is nonzero. It never resolves DNS, never
connects to the issuer, never fetches the discovery document. This is a
deliberate choice, not an oversight:

- A config reload with an unreachable, misspelled, or entirely nonexistent
  `issuer` still passes validation and swaps in cleanly — validate-then-swap
  semantics are preserved exactly as they are for every other config
  section (a bad edit degrades to "the reload didn't happen," not to a dead
  server; see `reload.rs`'s own doc), and this section adds no way for the
  identity provider's reachability to become a new reason a reload can
  block or fail.
- The OIDC validator's JWKS cache is built cold (see §3) and lives inside
  the same reload-swapped state as the rest of the authorizer (`ContextState
  ::authorizer`, `context.rs`) — a config reload builds a brand new
  validator with a brand new, empty cache, never mutates one in place, so
  an in-flight request always sees a JWKS cache state that belongs to a
  single, consistent config snapshot.

The honest failure mode this trades for: an operator who fat-fingers
`issuer` finds out at the first OIDC-authenticated request (every token
rejected as unknown `kid`, since discovery itself fails), not at reload
time. Config-level typos in `bearer_tokens` (empty token, duplicate token,
an unknown tenant reference) are still caught eagerly, because those are
pure shape/referential checks against the rest of the document already
loaded in memory — the same category of check `validate()` always ran; only
the OIDC issuer's *reachability* is deferred, since checking that means a
network call.

## 5. Algorithm support

Only RS256 (any RSA JWK) and ES256 (an EC JWK on the P-256 curve) are
accepted. A JWK's algorithm is inferred from its key type (`kty`, and for EC
keys `crv`) rather than trusted from the JWK's own optional `alg` field,
since some identity providers omit it. Every other key type or curve in a
published JWKS — HMAC octet keys, Ed25519, P-384, P-521 — is simply skipped
when the key set is parsed, not treated as an error; an IdP publishing a mix
of key types degrades to "the ones this server can't use are ignored," not
"the whole JWKS fetch fails."

## 6. Where a static token's value lives (`#144`)

`bearer_tokens` says what a principal may do; it need not say what its
secret is. Each entry declares exactly one of:

```yaml
auth:
  bearer_tokens:
    - token_env: TELLURION_SERVICE_TOKEN   # the value lives in the environment
      tenants: [public]
    - token: dev-token-change-me           # the value lives in this document
      tenants: [public]
```

**Why per-principal `token_env`, and not one variable for the whole set.**
The list is behavior: which principals exist, which tenants each authorizes,
which roles it holds, whether it is a platform admin. That belongs in the
document, where it is reviewable and diffable. Only each principal's single
token value is a secret, and a single scalar per entry is exactly the shape
`StorageDecl::url_env`, `ControlStoreLocator::Postgres::url_env` and
`L2CacheConfig::Valkey::url_env` already established. Packing the list into
one variable would move the behavior into the environment too — the
opposite trade.

**What an existing deployment sees.** Nothing breaks. `token` remains a
valid declaration with unchanged semantics, because every config written
before `#144` uses one and a required field would stop all of them booting —
the same reasoning that makes `ControlStoreLocator::LegacyFile` the
`Default` rather than making the block required. What it gains is a line in
the log at every boot and every reload naming the affected principals (by
their declared `principal:`, or by the short non-reversible fingerprint the
audit trail already uses — never by value) and pointing at `token_env`. Loud
and repeated, never silent, and never a refusal.

**What it buys.** The value cannot reach a place it should not, because the
document never holds it: not a control-store snapshot, not the raw document
`GET /config` returns, not a config file committed by mistake. Rotation
becomes changing a variable and restarting rather than editing and
redistributing the document to every instance.

**Refusals.** A `token_env` naming an unset or empty variable fails boot by
name, and fails an in-flight reload by name with the previous configuration
still serving — never a principal that silently stops authorizing, which an
operator would diagnose as a revoked credential. Two entries resolving to
the same value are refused for the same reason two inline duplicates always
were: the authorizer is a map keyed by token value, so the second entry
could never be reached. No message on this path ever contains a token value;
the variable *name* is not a secret and is the only thing that fixes the
problem.

**The seam.** `auth::resolve_bearer_credentials_from` takes the lookup as a
parameter — the process environment today, and the one thing a future
relational credential store substitutes. Hash-at-rest and a service-account
lifecycle API (`#144`'s remaining proposals) sit behind that same parameter
and are not part of this slice.

## 7. Out of scope

ABAC/RBAC policy — turning tenant memberships (or any other claim) into
fine-grained, sub-tenant authorization rules — is not part of this slice.
`claims.tenants` maps directly onto the same tenant-membership check a
static token's `tenants` list already does; that's the full extent of claim
interpretation here.
