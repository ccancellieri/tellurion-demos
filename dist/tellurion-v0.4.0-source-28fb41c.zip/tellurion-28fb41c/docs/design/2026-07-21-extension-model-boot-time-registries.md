# Extension model: boot-time registries, ordered chains, and why plugins stay out

Status: adopted — normative stance for issue #112. This is a standing rule for
how every seam in this codebase composes multiple implementations of one
capability, not a one-time feature design; the audit and adoption sections
below describe the codebase as it stands after this change, not an aspiration.

## Why this needed writing down

Tellurion is already modular where it matters: capability traits in
`tellurion-core`, driver crates behind cargo features, per-lane ordered
routing (`#21`), the L1/L2 cache composition seam (`#16`), a freshness-ordered
search chain, `ConfigStore`/`StyleStore` as swappable stores. Each of those
seams got its own composition rule at the time it was built, and every one of
them independently arrived at roughly the same shape — which is the signal
that the shape belongs in one place, not re-derived per seam. Writing it down
once means a future seam adopts a contract instead of re-litigating it, and
"can this ship as a `.so` a deployment drops into a plugins directory?" has a
durable, citable answer instead of a recurring debate.

## The contract

Six rules, applied uniformly to every seam where more than one implementation
can serve the same trait:

1. **The unit of extension is a crate behind a cargo feature**, implementing
   capability traits declared in `tellurion-core`. Compiled-out means absent.
   A config that names an absent implementation fails boot by name — already
   the rule storage drivers followed before this issue; the change is that
   every other multi-implementation seam now owes the same treatment.

2. **Registration is explicit and happens in one place.** `main` assembles a
   registry of named factories at boot. There is no self-registration at
   link time via `inventory`/`linkme`/`ctor`-style static constructors: that
   trades one visible line of wiring for invisible registration order,
   dead-registration debugging, and initialization side effects — the class
   of load-order bug that plagues every plugin system built on import/link
   side effects. One function listing what a binary contains is a feature of
   this codebase, not boilerplate to eliminate.

3. **Selection is configured order, never discovery order.** Where several
   implementations can serve one seam, config names an ordered chain — the
   search lane's `routing.search: [index, main]` is the existing example —
   and the chain's fallback semantics are defined per seam, explicitly.
   Priority integers baked into an implementation are rejected outright: a
   rank distributed across crates is action at a distance, and ordering is a
   deployment decision (config), never a code decision.

4. **Dependencies are constructor arguments, not ordering hints.** If
   component B needs component A, B's constructor takes A, and the compiler —
   not a comment saying "must init after" — enforces boot order. An order
   number must never stand in for an undeclared dependency; "priority 10
   boots before priority 20 because it secretly needs to" describes a
   dependency graph nobody wrote down.

5. **Availability is a probe, not a silent filter.** An implementation that
   cannot serve right now (an unreachable backend, a missing file) reports
   that through the existing readiness machinery. It is never silently
   skipped in favor of a fallback picking up unnoticed — a silent fallback
   turns a misconfiguration into a performance mystery discovered weeks
   later, not a boot-time or readiness-time signal discovered immediately.

6. **Lifecycle is symmetric.** A component with startup work shuts down in
   reverse boot order, on the existing drain path — the same shutdown edge
   every background task in this server already reacts to.

Rules 4 and 6 are documented contract for this codebase, not new machinery
introduced by this issue: no seam adopted here currently needs constructor-
injected cross-component dependencies or its own startup/shutdown pair beyond
what the drain path already provides. They are recorded so a future seam that
does need them has a rule to follow instead of inventing one.

## Decision record: runtime plugin loading is out

Two shapes of "load an extension without recompiling the binary" were
considered and rejected for the current state of this project:

- **`dlopen`/`cdylib` plugins.** Rust has no stable ABI across compiler
  versions or even across compilations of the same compiler with different
  flags. Every plugin would have to be built by the exact same compiler
  against the exact same crate graph as the host binary — which is a strictly
  worse way to spell "workspace member": all the coupling of a monorepo
  dependency, none of the compile-time checking. Loading it is `unsafe` by
  construction, and a version-skewed plugin is undefined behavior, not a
  caught error. Rejected outright; there is no version of this that is safe
  without also being pointless.

- **A wasm component-model seam, or a subprocess behind a versioned IPC
  contract.** If out-of-tree extensibility ever earns its place — a
  deployment that genuinely cannot fork this repository to add a driver —
  these are the honest options: a sandboxed, crash-isolated boundary with an
  explicit versioned interface, unlike `dlopen`'s implicit one. Neither is
  built today because no current requirement justifies the engineering cost
  of either. Recording this keeps the door neither open by accident (nobody
  should assume a `.so` drop-in is coming) nor shut by folklore (a future
  maintainer facing a real out-of-tree case has two named, considered options
  to start from, not a blank page).

The test that keeps this honest: a plugin author who cannot recompile this
binary has no supported path today. That is a deliberate, load-bearing
absence, not an oversight.

## What "kept small on purpose" means here

The registry type this issue introduces (`tellurion_core::extension::
NamedRegistry<T>`) is a name -> `Arc<T>` map with three properties: lookup by
name, deterministic (alphabetical) iteration for a boot log, and last-
registration-wins on a duplicate name — matching the map it replaced inside
the storage-driver registry exactly, so adopting it changed no observable
behavior there. It has no lifecycle hooks, no async factory construction, no
priority field, and no discovery mechanism. A future seam that genuinely needs
one of those is a new, separately-justified addition to that seam — not a
speculative feature bolted onto this type because it might be useful
someday.

## Adoption: the storage-driver registry

The storage-driver seam (`router::Registry` / `router::DriverFactory`) is the
first adopter, and stays the reference shape every future registry-backed
seam should follow. `Registry` is unchanged from the outside: `register`,
and the config-driven `build` a `StorageDecl` resolves through, keep their
exact prior signatures and error text. Internally, its name -> factory map is
now a `NamedRegistry<dyn DriverFactory>`, which gives it two things it did
not have before: a deterministic (rather than hash-order) iteration for
`Registry::names()`, and that same lookup/iteration behavior shared with
every future seam that adopts `NamedRegistry` rather than re-implementing it.

Refuse-by-name at boot was already this seam's behavior before this issue —
a `StorageDecl` naming a driver with no registered factory failed
`Router::build` with a named `Error::Config`, whether that name was a typo or
belonged to a driver crate compiled out via its cargo feature. What this
issue adds is the regression test pinning that behavior (`router.rs`,
`a_storage_naming_a_driver_absent_from_this_registry_fails_boot_by_name`) —
before now nothing in the test suite would have caught a change that turned
"unknown driver" into a silent no-op or a panic — and the boot log line
(`main.rs`) enumerating, at process start, exactly which driver names this
binary's `Registry` actually contains.

## Seam audit, condensed

Every seam in `tellurion-core` where more than one implementation can serve
one trait, checked against the six rules above. The full write-up (with the
evidence behind each verdict) is in the pull request that introduced this
document; this table is the durable summary.

| Seam | Verdict | Note |
|---|---|---|
| Storage drivers (`router::Registry`) | Conforms | The reference adoption above; already had rules 1–3 before this issue, now backed by `NamedRegistry` and boot-logged. |
| Search routing chain (`routing.search`) | Conforms | The contract's own worked example for rule 3 — an explicit, config-ordered chain with a freshness-gated (not blind) fallback, satisfying rule 5's "probe, not silent filter" for this lane specifically. |
| Config store (`ConfigStore`) | Conforms (trivially) | Exactly one implementation exists (`FileConfigStore`), constructed directly in `main` — nothing to name or select yet, which is itself rule 2's "explicit, one place." Not registry-backed because there is currently nothing to register a second entry against. |
| Style store (`StyleStore`) | Conforms (trivially) | Same shape as `ConfigStore`: one implementation, direct construction, nothing to select between yet. |
| Cache tier composition (L1/L2) | Deviates | L2 availability is not surfaced through readiness; tracked in #161. |
| Catalog/collection registry backend (`RegistryReader` / `RelationalRegistryFactory`) | Conforms | Adopted in #162: named factories in a `NamedRegistry`, config selection by name, refuse-by-name, boot-logged. |

**Cache tier composition.** `build_cache` (`tellurion-server/src/main.rs`)
already satisfies rule 1: a `cache.l2` selecting the valkey backend when this
binary was built without the `valkey` feature fails boot with a named error,
not a silent no-op. Two things fall short of the full contract:

- Selection is a hand-written `match` on `L2CacheConfig` plus a cargo-feature
  `cfg` gate, not a `NamedRegistry` lookup — rule 2's letter, not its intent
  (there is exactly one swappable tier today, so nothing is silently
  reordered or mis-registered; this is a shape mismatch, not a live bug).
- More significantly, rule 5 is not met once the process is already running:
  `build_cache`'s own doc comment states that a *later* L2 outage "degrades
  silently per-request" — there is no readiness signal or metric
  distinguishing "L2 reachable" from "L2 down, serving L1-only," so an
  operator can only infer degradation from cache hit-rate math after the
  fact, not observe it directly. Follow-up #161 owns an explicit readiness
  probe and operational signal while preserving L1 service.

**Catalog/collection registry backend.** `RegistryReader` has two
implementations today: `FileRegistryReader` (always available, no I/O) and a
relational one supplied by a driver crate through `RelationalRegistryFactory`
(currently `tellurion-postgis`). `build_registry_reader` already satisfied
rule 1 (a `relational` backend with no compiled factory fails boot by name)
and rule 5 (`connect` is attempted eagerly; an unreachable database is a hard
boot error, never a reader that fails its first real query instead).

What #162 added is the rest of rules 2 and 3. `RelationalRegistryFactory` —
and its sibling `RelationalTenantFactory`, which `#143` dispatches off the
same knob — now declare a stable `name()`; `main` registers every compiled-in
factory into a `RelationalRegistryFactories`/`RelationalTenantFactories`
(both `NamedRegistry`-backed) instead of holding one `Option<Arc<dyn …>>`
slot each; and `config.registry.implementation` names the concrete factory.
One name selects both halves, so a deployment can never read its catalogs
through one driver crate and its tenants through another.

Two properties are worth stating because they are what keeps the change
additive. `file` stays the *direct built-in* backend rather than becoming a
registry entry: there is no driver crate it could be compiled out with, so
there is nothing to name and nothing that could refuse it. And
`implementation` is `Option`, defaulting to `None`, which resolves to the
sole registered implementation — exactly what `backend: relational` already
meant when only one could ever be compiled in. Every config written before
#162 therefore behaves byte-for-byte as it did, including the unchanged
"built with no driver providing a relational registry factory" sentence a
driverless binary prints. Leaving it unset only becomes an error once a
second relational implementation exists, and then it is a named refusal
listing the candidates, never a silent pick by registration or alphabetical
order.
