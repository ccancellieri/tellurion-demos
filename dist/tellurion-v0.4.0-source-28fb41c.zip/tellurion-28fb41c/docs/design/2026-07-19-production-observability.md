# Production observability and graceful drain

Status: Approved

Issue: #62

## Purpose

Tellurion already exports a matched-route request histogram, tile-cache
counters, and process RSS, and it already asks Axum to drain requests after
SIGINT or SIGTERM. Production operation still lacks four connected pieces:

1. request latency split into stable serving lanes without unbounded labels;
2. one structured diagnostic event for a slow request, with useful phase
   timing;
3. separate liveness and readiness signals; and
4. a configurable, tested shutdown deadline that makes readiness false before
   traffic stops.

This design adds those pieces through shared server and core seams. It does
not change protocol responses, authorization decisions, filter semantics,
driver capability contracts, resource-budget derivation, or admission-control
policy.

## Configuration

Behavior remains in the YAML configuration tree. Infrastructure environment
variables continue to carry only secrets, bind-port overrides, and log-filter
selection.

The server configuration gains these fields:

```yaml
server:
  drain_timeout_s: 10
  readiness_probe_interval_s: 5
  readiness_probe_timeout_s: 2
  metrics_tenant_allowlist: [public]
  metrics_collection_allowlist:
    - tenant: public
      catalog: default
      collection: demo
```

The defaults above preserve the current ten-second drain window and keep the
readiness probe cheap enough for ordinary orchestration. All three duration
values must be greater than zero. Duplicate metric-label references are a
configuration error.

Allowlist entries contain public external identifiers, not Tellurion internal
ids. They are deliberately fully qualified because a collection external id
is unique only within its catalog. A relational registry may contain entries
that are not present in the YAML snapshot, so validation checks each segment
is non-empty and each triple is unique; runtime matching decides whether a
request is allowlisted.

The inherited settings tree gains a slow-request threshold:

```yaml
settings:
  slow_request_ms: 1000

tenants:
  - id: public
    settings:
      slow_request_ms: 2500
```

`slow_request_ms` follows the existing collection, catalog, tenant, platform
precedence. The nearest value wins. If every level omits it, the default is
1000 milliseconds. It must be greater than zero. A route without a resolved
collection uses the nearest resolvable tenant setting, then the platform
setting, then the default.

Configuration reload changes thresholds and label policy on the next request
because observation reads the current atomic context snapshot. Drain timing
is fixed for the lifetime of the listening server; changing it takes effect
after restart.

## Bounded request metrics

The existing `http_request_duration_seconds` histogram remains the single
request-latency series. It retains `method`, matched `path`, and `status`, and
adds `lane`, `tenant`, and `collection`.

The finite lane vocabulary is:

- `features` for Features metadata and feature-item routes;
- `tiles` for Tiles metadata routes;
- `mvt` for Mapbox Vector Tile responses;
- `png` for unstyled raster tile responses;
- `styled_png` for style-rendered raster tile responses;
- `places3d` for 3D Tiles metadata and content;
- `styles` for style resources;
- `stac` for STAC resources and search;
- `control` for the service root, metrics, liveness, and readiness; and
- `unmatched` when no route template matched.

Lane selection uses the matched route template and, for the shared tile route,
the response content type. It never uses an arbitrary request path or query
value.

The `path` label remains Axum's `MatchedPath` template. An unmatched request
uses the fixed value `unmatched`.

The `tenant` label is the resolved external tenant id only when it appears in
`server.metrics_tenant_allowlist`; a resolved tenant outside that allowlist
uses `other`. An absent tenant uses `none`; an unresolvable path value uses
`unknown`. The maximum number of tenant label values is therefore the
allowlist size plus three. An attacker-controlled raw tenant segment is never
copied into a metric.

The `collection` label is the fully qualified external
`tenant/catalog/collection` string only when that exact triple appears in
`server.metrics_collection_allowlist`. A non-allowlisted collection uses
`other`; a route with no collection uses `none`. Thus the maximum number of
collection label values is the configured allowlist size plus two.

No authorization header, credential, query string, feature id, style id,
tile coordinate, internal id, physical table, storage id, or error message is
ever a metric label.

## Request phases and the slow-request event

One request-scoped timing collector is established by the outer request
observation middleware. Core instrumentation is a no-op when code runs outside
an observed HTTP request, including boot validation, reload, tests that call a
driver directly, and background tasks.

The collector records exclusive time in four phases:

- `routing`: external-id resolution, capability routing, and descriptor
  resolution;
- `query`: registry, style-store, feature, tile, and volume-source calls;
- `cache`: lookup, coalescing, and cache write bookkeeping, excluding the
  population future's query and response-production work;
- `encode`: total request time remaining after the three measured exclusive
  phases, including rendering, serialization, response construction, and the
  small amount of handler/middleware work that cannot be assigned safely to
  another phase.

`encode` is intentionally an operational response-production residual, not a
claim that a codec alone consumed the whole value. The four values do not
overlap and never sum above total request time. This definition avoids false
precision and avoids duplicating timers across protocol handlers.

Shared wrappers instrument the existing resolver/router, registry reader,
style store, capability sources, and cache seams. Protocol handlers keep
calling the same interfaces, so filtering, policy enforcement, 3D geometry,
write/outbox, and protocol response code remain untouched.

When total elapsed time is strictly greater than the effective
`slow_request_ms`, the middleware emits exactly one warning event with these
stable fields:

```text
event=slow_request method route lane status tenant catalog collection
elapsed_ms routing_ms query_ms cache_ms encode_ms
```

Tenant, catalog, and collection fields are public external path values and
exist only in logs. Logs may name a non-allowlisted collection because their
purpose is diagnosis rather than aggregation. The event never includes the
raw URI, query string, headers, credentials, feature ids, physical names, or
internal ids. Requests at or below the threshold produce no slow-request
event.

## Liveness and readiness

Both probes are top-level, unauthenticated control routes.

`GET /healthz` is trivial liveness. If the event loop can serve it, it returns
200. It performs no configuration, registry, storage, cache, or network work.

`GET /readyz` reflects a shared readiness state:

- 200 while the latest bounded *mandatory* dependency probe succeeded and the
  server is not draining;
- 503 with the shared problem+json shape while boot probing is incomplete, a
  mandatory dependency probe failed, timed out, or the server is draining.

The response body never reveals a storage name, database address, table,
registry identifier, or internal error. Detailed failures are logged once on
state transition, not on every orchestration poll.

The 200 is empty — no body, no `Content-Type` — with exactly one exception
(`#161`): a process that is ready but whose *configured* optional tier is
unavailable returns

```json
{"status":"degraded","degradations":[{"component":"cache.l2","backend":"valkey","reason":"unreachable"}]}
```

`reason` is a closed set of codes (`unreachable`, `probe-timeout`,
`never-connected-at-boot`), never the backend's own error text, which stays in
the log where credential redaction applies. A deployment that configured no
optional tier, and one whose configured tier is healthy, both get the same
empty 200 they always got — an optimization nobody asked for is not a
degradation, and one that is working is not news.

Readiness starts false. After the application context exists, a background
task immediately probes the current atomic context and repeats every
`readiness_probe_interval_s`:

1. exercise the current `RegistryReader` with a bounded one-entry listing for
   each configured tenant; and
2. exercise every routed storage through its existing `CatalogSource` under
   one `readiness_probe_timeout_s` deadline.

For the file registry and memory/file drivers these operations are local. For
PostGIS they require a usable pool checkout and query. Reusing these existing
seams avoids adding a second driver-health contract beside the capability
contract.

### Optional tiers (`#161`)

Alongside — never inside — that mandatory probe, the same cadence probes the
optional L2 tile-cache tier, when one is configured, by reading a reserved key
through the existing `L2Cache::get` seam. The tier is discovered through
`TileCache::l2_tier()`, an `Option` capability accessor defaulting to `None` in
the same shape as `StorageDriver`'s: `None` means "no `cache.l2` configured",
and a configured tier that never connected at boot is `Some` carrying a
`NeverConnected` state rather than being erased into that same `None`.

**An unavailable optional tier does not make the process unready.** A cache is a
latency optimization; with it down every request is still answered, and
answered correctly, from L1 plus the origin storage. Turning that into
unreadiness would evict the replica from the load balancer exactly when the
cache stopped absorbing load — and would do so on every replica at once, since
they share the tier — converting a slower service into an unavailable one. The
tier is therefore reported as a named degradation on a still-200 readiness
response, plus a `tile_cache_l2_available{backend}` gauge (emitted only when a
tier is configured) and one log line per transition.

The two probes carry independent deadlines and independent result types, so a
wedged cache backend can neither consume the mandatory probe's
`readiness_probe_timeout_s` nor reach the code that sets readiness false.

A successful reload replaces the context snapshot; the next probe evaluates
the replacement. A failed reload leaves the last valid context serving and
does not make readiness false by itself.

`healthz` and `readyz` join the reserved tenant-segment set so no configured
tenant can be shadowed by a control route.

## Graceful drain

Signal detection and draining are separated so drain semantics can be tested
without sending an operating-system signal in every unit test.

On SIGINT or SIGTERM the server:

1. atomically marks readiness as draining;
2. wakes Axum's graceful-shutdown future, which stops accepting new
   connections;
3. waits for in-flight requests to complete; and
4. returns normally when they finish, or drops the serving future after
   `server.drain_timeout_s` and logs one warning.

The drain function returns serving errors rather than swallowing them. A
Unix-only binary integration test sends a real SIGTERM; deterministic listener
tests inject a shutdown future to prove both in-flight completion and deadline
expiry without platform timing assumptions.

Kubernetes uses `/healthz` for liveness and `/readyz` for readiness. Its
termination grace period is the default drain deadline plus a five-second
process margin. Docker's health check uses `/healthz`; container health does
not claim that downstream dependencies are ready.

## Components and boundaries

The implementation is divided by responsibility:

- `tellurion-core::observability` owns request-local phase collection and
  small timing wrappers that core consumers can call without depending on
  the server crate.
- Core router/context wrappers account for routing, query, and cache time and
  expose a bounded storage-readiness probe.
- `tellurion-server::metrics` owns label extraction, lane classification,
  histogram emission, effective-threshold lookup, and the slow event.
- `tellurion-server::readiness` owns readiness state, dependency polling, and
  probe handlers.
- `tellurion-server::shutdown` owns signal adaptation and bounded drain.
- `app.rs` and `main.rs` only assemble these components.

No protocol handler, filter AST/compiler, policy evaluator, driver write or
outbox capability, 3D driver implementation, benchmark scenario, or UI file
is modified. Resource-budget derivation (#63) and per-tenant admission control
(#66) remain separate: this work measures their future effects but does not
preempt their policy.

## Failure behavior

- Invalid duration or duplicate allowlist configuration fails config
  validation with a named `Error::Config`.
- Metrics and slow logging never change an HTTP response if observation
  fails; fixed fallback labels are used instead.
- A readiness probe error or timeout changes only readiness, not liveness and
  not the serving context.
- A dependency recovery makes the next successful probe ready without a
  restart.
- Starting drain is irreversible for that process.
- A slow-request log failure cannot fail the request.

## Verification

Tests pin every claimed behavior:

1. config defaults, validation, reload-visible label policy, and four-level
   slow-threshold inheritance;
2. phase accounting, nesting, no-op behavior outside a request scope, and
   total-minus-exclusive encode calculation;
3. histogram lane classification and a rendered Prometheus output scan that
   proves attacker-controlled tenant/collection values never become labels;
4. exactly one slow event above threshold, none at or below it, correct phase
   fields, and absence of URI/query/header/internal-id leakage;
5. trivial liveness and readiness transitions through initial, ready, failed,
   recovered, and draining states;
6. registry/storage probe success, failure, and timeout with fake seams;
7. an injected-signal listener test proving an in-flight request finishes;
8. a deadline test proving a stuck request cannot keep the process alive;
9. a Unix binary test sending SIGTERM while a request is in flight; and
10. reference configuration plus Docker/Kubernetes probe and grace-period
    assertions.

The final gates are workspace formatting, warnings-denied clippy, the full
workspace test suite, every existing server feature-matrix build, diff/leak
scans, and GitHub CI on the issue-linked pull request.
