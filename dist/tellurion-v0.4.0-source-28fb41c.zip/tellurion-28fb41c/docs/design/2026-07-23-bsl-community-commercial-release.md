# BSL Community and commercial production licensing

Status: approved product direction, pending legal review and implementation.

This document defines the licensing and distribution boundary for Tellurion
starting with version 0.3.0. It is an engineering and product record, not legal
advice. The exact licence parameters and commercial agreement must be reviewed
by qualified counsel before the first public 0.3.0 release.

## Product outcome

Tellurion 0.3.0 is source-available under Business Source License 1.1
(`BUSL-1.1`):

- anyone may download the source and binaries;
- non-production use is free, including evaluation, development, testing,
  training, and proof-of-concept work;
- a natural person may make personal, non-commercial production use for free;
- production use by or for a business, government, or other organisation
  requires a separate paid commercial licence;
- each version converts automatically to AGPL-3.0-only no later than four years
  after its first public distribution.

Tellurion must not be described as open source before its Change Date. The
correct descriptions are “source-available”, “free for non-production use”, and
“commercial licence required for company production use”.

## Version boundary

The version boundary is explicit:

- 0.1.0 remains the legacy AGPL-3.0-only release. Its recipients keep the rights
  already granted to them.
- 0.2.0 remains a private, withdrawn release candidate. Its tag and release
  number are not reused for different terms.
- 0.3.0 is the first BUSL-1.1 release.

The existing codebase continues forward; it is not rewritten. Repository history
shows one first-party copyright holder and the contributor agreement assigns
outside contributions to that holder. This must be reconfirmed before release.
No code received under incompatible third-party copyleft terms may enter the
BUSL release.

## BSL 1.1 parameters

The canonical Business Source License 1.1 text is used without modification.
The project-specific parameter block for 0.3.0 is:

```text
Licensor: Carlo Cancellieri

Licensed Work: Tellurion 0.3.0, including its source code, compiled binaries,
build tooling, and bundled documentation.

Additional Use Grant: You may make Production Use of the Licensed Work if You
are a natural person using it solely for Your personal, non-commercial purposes
and not on behalf of any business, government, or other organisation.

Change Date: 2030-07-23

Change License: GNU Affero General Public License Version 3 only
(AGPL-3.0-only).
```

The Additional Use Grant only adds personal, non-commercial production use to
the BSL baseline. The canonical licence already requires any other production
user to obtain a commercial licence or refrain from that use. The grant does not
restrict the non-production rights already provided by the canonical licence.

Future versions receive their own parameter block and Change Date. No Change
Date may be later than the fourth anniversary of that version’s first public
distribution.

## Meaning of production use

The licence summary and commercial FAQ use this operational definition:

> Production Use means use in normal business operations, internal operational
> services, processing operational data, or providing functionality to
> customers or other third parties. It excludes evaluation, development,
> testing, training, and time-bounded proof-of-concept work that is not relied
> on for normal operations.

This wording is explanatory and does not replace the canonical BSL terms. Legal
review must decide whether it belongs inside the Additional Use Grant or only in
the commercial FAQ.

## Commercial licence

BUSL-1.1 is one offer. A paying customer receives a separate commercial
licence, executed by the copyright holder, that grants the production rights
their deployment needs without the BSL production limitation.

The current `COMMERCIAL-LICENSE.md` is only a notice and is not sufficient as a
sales contract. The commercial agreement must define:

- customer and permitted affiliates;
- deployment, node, instance, or capacity metric;
- subscription or perpetual term;
- permitted installation and backup copies;
- restrictions on redistribution, sublicensing, transfer, and third-party
  hosted services;
- updates, maintenance, and support;
- termination and post-termination handling;
- warranty, liability, governing law, and mandatory statutory exceptions.

The public repository links to a commercial licensing page through the
licensor’s GitHub profile until a dedicated company contact exists. No private
email address is committed.

## Source and binary distribution

BSL requires the source to be publicly available from the start. The private
development repository remains the source of truth, while each public release
provides:

- a complete source archive for the released commit;
- macOS Apple Silicon binaries;
- a static Linux x86-64 musl build;
- Windows x86-64 MSVC binaries;
- SHA-256 checksums, build information, and provenance;
- the BUSL licence and its exact parameter block;
- third-party notices and a commercial-licensing link.

Release archives are GitHub Release assets and are not committed to Git
history. The public site links to immutable versioned assets.

The source archive must include every script required to rebuild the binaries
and exclude local memory, credentials, untracked files, build output, private
URLs, and editor context.

## Cargo and publication controls

Workspace packages for 0.3.0 declare:

```toml
version = "0.3.0"
license = "BUSL-1.1"
publish = false
```

Every first-party crate inherits the same version and licence. The package audit
must verify that the canonical `LICENSE` file is present in each package
listing. CI rejects:

- an AGPL package declaration in the 0.3.0 workspace;
- a publishable first-party package;
- a missing BUSL licence or parameter block;
- an inconsistent workspace dependency version;
- language describing pre-Change-Date Tellurion as open source.

AGPL remains valid in historical 0.1.0 documentation and as the 0.3.0 Change
License. Automated checks must distinguish those legitimate references from a
current-package licence claim.

## Public messaging

Every download surface presents the same short matrix:

| Use | Cost before Change Date |
|---|---|
| Personal, non-commercial use | Free |
| Evaluation, development, test, training, proof of concept | Free |
| Production use by or for a business, government, or organisation | Commercial licence required |
| Any use after the version’s Change Date | AGPL-3.0-only |

The site must also state that BUSL-1.1 permits copying, modification, derivative
works, redistribution, and non-production use under its terms. It must not say
that copying is categorically prohibited.

## Migration and release gates

Relicensing is performed in a dedicated branch based on the current remote
`main`, never in the diverged local checkout.

Before any public 0.3.0 source or binary is published:

1. qualified counsel approves the parameter block and commercial agreement;
2. the copyright and dependency audit is clean;
3. the complete workspace passes formatting, linting, and tests;
4. macOS, Linux, and Windows native smoke tests pass;
5. package and release scans find no credentials, personal contact details, or
   private repository URLs;
6. public documentation consistently distinguishes BUSL from open source.

Yanking 0.1.0 crates and withdrawing the private 0.2.0 release are separate
destructive actions. They require an explicit inventory and approval and do not
revoke rights in copies already obtained.

## Acceptance criteria

The transition is complete only when:

- all first-party 0.3.0 manifests declare `BUSL-1.1` and `publish = false`;
- the canonical unmodified BSL 1.1 text and approved parameter block ship in
  source and binary archives;
- the legacy 0.1.0 AGPL boundary is documented without implying revocation;
- commercial and free-use cases are explained consistently;
- public downloads expose source, licence, checksum, signing status, and Change
  Date next to every binary;
- no new source or binary is published before legal approval;
- the original local checkout and its unpublished commits remain untouched.
