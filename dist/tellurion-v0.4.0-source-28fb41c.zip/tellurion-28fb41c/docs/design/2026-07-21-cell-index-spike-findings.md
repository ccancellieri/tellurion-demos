# Cell index spike findings: H3 vs S2, and whether either beats GiST

Status: answers #103's own Q1 and Q4 with measurements against a real
dataset, and gives a directional (unmeasured) read on Q2, Q3, and Q5, per
the scope the issue itself asked for.

## What the spike set out to answer

Issue #103 proposed a storage-agnostic cell index as a common spatial
acceleration layer across every driver, on the observation that "does
spatial search use an index" has a different answer per driver today —
GiST for PostGIS, GeoPackage's R\*Tree, FlatGeobuf's packed R-tree,
GeoParquet's row-group bbox statistics, Iceberg's manifest-level statistics,
and a full linear scan for the memory driver — three of which are
effectively "no index at all." Before committing to building one, the issue
asked for two questions to be settled with real measurements:

1. **H3 versus S2.** The issue author's stated instinct was S2, because its
   quadtree cells nest cleanly onto range queries over a sorted key — a
   property this project leans on everywhere via keyset paging — with H3
   as a later addition for density aggregation. The issue explicitly asked
   for the Rust ecosystem reality to be checked, not just the two indexing
   schemes in the abstract, and named "S2 is theoretically right but the
   Rust port is unmaintained" as a legitimate, decision-changing answer.
2. **Is a cell index a real win for PostGIS at all**, given that PostGIS
   already builds a GiST index over the geometry column? The issue's own
   suspicion was no — that this is strictly a capability for the
   index-less drivers.

Three further questions (where cells live, one resolution vs. a ladder,
write-maintenance cost) were explicitly scoped as directional-only: worth a
read, not worth a second measurement pass in the same spike.

## Methodology

### Dataset

Real, unmodified OpenStreetMap data for Sicily and Sardinia — Geofabrik's
`italy/isole-latest.osm.pbf` regional sub-extract, the same source and
version this repository's own `docs/quickstart/real-data-osm-geopackage.md`
already documents and verifies (resolved at download time to
`italy/isole-260719.osm.pbf`, 213,054,753 bytes, MD5
`580b377311b38fe4ef4910ff06dfcf2a`, matched against Geofabrik's own `.md5`
sidecar). The `multipolygons` GDAL OSM layer was converted with `ogr2ogr`
(`-t_srs EPSG:3857 -nlt PROMOTE_TO_MULTI`) and loaded directly into a live
PostGIS 16.4 / PostGIS 3.4.3 instance (`postgis/postgis:16-3.4` in Docker),
which builds a GiST index on the geometry column automatically:

- **2,125,493 features**, all `MultiPolygon`, EPSG:3857.
- **Geometry mix**: 1,844,294 (86.8%) carry an OSM `building` tag —
  overwhelmingly small building footprints. The remaining 281,199 (13.2%)
  are `natural`/`landuse`/`boundary`/`leisure`/etc. polygons. Feature area
  (`ST_Area`) ranges from 0.002 m² to roughly 82,275 km² (a single extreme
  outlier — almost certainly a coastal or administrative polygon), median
  180 m², mean 218,016 m² — five orders of magnitude between the median
  and the tail, entirely from real data, not constructed.
- Base table storage: 705 MB total (526 MB table + ~179 MB GiST index),
  `osm_multipolygons_geom_geom_idx`.

### Machine and contention caveat

This ran on a shared development machine with other agents building and
running concurrently — `cargo` repeatedly printed `Blocking waiting for
file lock on package cache` during harness compilation, and load average
was observed between 5.9 and 7.7 on a 12-core host during parts of the
measurement window. PostGIS ran in Docker under x86_64 emulation on an
arm64 host (`WARNING: the requested image's platform (linux/amd64) does
not match the detected host platform (linux/arm64/v8)`), which inflates
every absolute number by some constant emulation tax but should not bias
the *relative* comparison between approaches, since every query path pays
it identically.

The three full benchmark runs behind the Q4 numbers below were not all
collected under the same contention regime — a session interruption
separated the first run from the second and third. Rather than silently
averaging across that gap, the two regimes are reported side by side:
**run 1** (busier machine, `gist` medians 14–22 ms) and **runs 2+3
combined** (quieter machine, `gist` medians 6–7 ms). Absolute latencies
differ by roughly 2–3x between the two regimes; the *relative* ordering
between approaches — which is what Q4 actually turns on — is the same in
both, which is reported as corroboration rather than papered over.

All numbers are medians of 7 in-process repeated timings per query, per
approach; each run samples 8 random query locations per size bucket. Spike
level directional confidence is the bar, not benchmark-paper rigor.

### Toolchain

`rustc`/`cargo` 1.97.1, `h3o` 0.10.0, `s2` 0.1.0 — both pulled only into a
disposable scratch crate (`spike-scratch/harness/`, excluded from git via
`.git/info/exclude`, never touching the tracked workspace `Cargo.toml`).
The full harness is reproduced verbatim in the appendix.

## Q1 verdict: H3 vs S2 in the Rust ecosystem

**The issue author's encoding instinct is correct and confirmed from
source — but the available Rust S2 crate cannot do the one thing this
project would need it for, and h3o can. Build on H3.**

### What was checked, and how

Crate maturity, pulled from the crates.io API and each crate's own
published source (not secondhand summaries):

| | `h3o` | `s2` (`yjh0502/rust-s2`) |
|---|---|---|
| Crate created | 2023-01-09 | 2017-05-31 |
| Reached first stable-ish release | 0.10.0, 2026-05-24 | **0.1.0, 2026-07-07** (nine years after creation) |
| Published versions | 27 | 14, with gaps — 0.0.10 (Feb 2020) to 0.0.11 (Dec 2022) |
| crates.io downloads (total / 90d) | 1,458,979 / 416,343 | 560,020 / 162,796 |
| Reverse dependencies on crates.io | 20 | 6 |
| Implementation | Pure Rust, no C FFI/bindgen | Pure Rust, no C FFI/bindgen |
| Polygon-to-cells support | Yes — `geom::Tiler` | **No — see below** |

Both crates are pure-Rust ports with no C dependency, so that's not a
differentiator. What is: `s2` only reached its first `0.1.0` two weeks
before this spike, after nine years in `0.0.x`, and its own `README.md`
status table is explicit about what that version does and does not cover:

```
## S² - Spherical Geometry

**complete**
 - Cell, CellID, CellUnion, LatLng, Metric, Point, Region, stuv

**in progress**
 - edgeutil, predicates, Rect

**pending**
 - loop, paddedcell, polygon, polyline, shapeindex
```

That "pending" line is the load-bearing fact for this issue. Verified
directly against the published `s2-0.1.0` source rather than trusted from
the README: `region.rs` does implement a real, complete `RegionCoverer`
(`covering`, `interior_covering`, `fast_covering` — a faithful, tested port
of the Go library's covering algorithm). But `RegionCoverer` only covers
types that implement the `Region` trait, and grepping the crate for `impl
Region for` turns up exactly five implementations:

```
src/s2/rect.rs:488:impl Region for Rect {
src/s2/cell.rs:410:impl Region for Cell {
src/s2/cellunion.rs:413:impl Region for CellUnion {
src/s2/cap.rs:259:impl Region for Cap {
src/s2/point.rs:419:impl Region for Point {
```

There is no `Loop` type and no `Polygon` type in this crate — matching the
README's "pending" list exactly. **The available Rust S2 port cannot cover
an arbitrary real-world polygon.** It can cover a bounding rectangle, a
spherical cap, a single cell, or a point — never a feature's actual shape.
For the exact operation issue #103 proposes ("index each feature by the
cell(s) covering it"), that means every feature gets approximated by its
bounding box, not indexed by its true geometry — an approximation forced
by an incomplete port, not a considered design choice.

`h3o`, by contrast, has a complete `geom::Tiler`/`TilerBuilder` (behind the
`geo` feature) that covers real `geo_types::Polygon`/`MultiPolygon`
geometry directly, with four selectable containment modes
(`ContainsCentroid`, `ContainsBoundary`, `IntersectsBoundary`, `Covers`),
exercised by this project's own harness against 2.1 million real OSM
polygons without incident, and validated upstream by differential testing
against the reference H3 C library.

### The encoding argument itself — verified, and correctly in S2's favor

The issue's instinct about *why* S2 should suit a keyset-paged store is
right, and it is worth stating precisely, because it survives the
ecosystem verdict above even though it doesn't overturn it.

`s2::cellid::CellID` exposes `range_min()`/`range_max()`: for any cell at
any level, these return the leaf-cell range spanned by that cell's entire
descendant subtree, computed purely from the cell's own raw 64-bit integer
value. That means a stored covering built at one resolution and a query
covering built at a *different* resolution can be tested for overlap with
a plain numeric range predicate (`BETWEEN`/comparison) on a single sorted
column — no ancestor-chain walking, no resolution bookkeeping. This is
exactly the "range query over a sorted key" property the issue calls out,
and it is a real, structural characteristic of how S2 packs face, Hilbert
position, and a trailing level-marker bit into one 64-bit integer.

`h3o`'s own bit-layout constants (`src/index/bits.rs`) show H3 does not
share that property: `MODE_OFFSET = 59`, with a resolution field and a
7-bit base-cell field sitting *above* the fixed-width 45-bit digit sequence
(`DIRECTIONS_MASK = 0x0000_1fff_ffff_ffff`). Because the resolution field
occupies a fixed bit position regardless of a cell's actual resolution, two
cells at different resolutions do not fall into a single contiguous
numeric range purely by comparing raw `u64` values the way S2's cells do.
Matching a query cell against a stored cell at a different resolution
needs either an exact resolution match, or explicit ancestor/descendant
traversal — this spike's own harness works around it by re-querying at
every resolution the build step actually used (see `h3_query_cells` in the
appendix), which is a real, if modest, extra cost H3 pays and S2's
encoding would not.

This did not translate into a second isolated benchmark in this spike — it
would need a global (not regional) dataset to be meaningful, since a
compact area like Sicily/Sardinia never crosses an S2 face boundary and so
never exercises the interesting edge of the encoding. It is reported as a
verified structural fact, in the issue author's favor, that simply does
not overcome the polygon-coverage gap above for this project's stated use
case.

One further, source-verified gotcha worth flagging for whoever revisits
this: `CellID`'s raw value is unsigned 64-bit with the face number (0–5)
in the top 3 bits; faces 4 and 5 push the value above `i64::MAX`, so a
naive `bigint` column would silently reinterpret those cells as negative
under Postgres's signed comparison, corrupting exactly the range-scan
property argued above. This spike's schema sidesteps it entirely by
storing every cell id (H3 and S2 alike) as a fixed-width 16-hex-character
string, which preserves correct unsigned lexicographic order in a plain
`char(16)`/`btree` column with no `numeric`/unsigned tricks needed — but
because this dataset stays within a single S2 face, the overflow itself
was never empirically triggered here. Flagged as verified-in-principle
from the encoding, not verified-in-this-run.

### Verdict

Build on H3 via `h3o` if a cell index gets built at all. `s2`
(`yjh0502/rust-s2`) is a real, actively-worked-on, correctly-licensed
(Apache-2.0) port with a genuinely good `RegionCoverer` implementation —
but it cannot cover a polygon today, which rules it out for indexing real
feature geometry regardless of how well-suited its encoding is to this
project's keyset-paging habit. Revisit if/when `Loop`/`Polygon` `Region`
support lands upstream; track it, do not build it in-house as part of this
project.

## Q4 verdict: is a cell index a real win over GiST?

**No. GiST already wins for PostGIS, and its margin grows — not
shrinks — as queries get denser, which is the opposite of what would be
needed to justify the extra index.**

### Setup

Both coverings were built for all 2,125,493 features in one pass: H3 at
resolution 9 (~0.737 km²/hexagon, sized for building-scale features) with
an estimator-triggered fallback to resolution 6 for oversized polygons;
S2's bounding-rect covering at level 15 (~0.037 km²/cell) with a fallback
to level 9, using the same estimator and the same cap (see "Q3" below for
why the fallback exists at all). Build cost for both coverings together:
**258.1 s wall-clock for the full table** (≈121 µs/feature), producing
2,606,999 H3 rows and 3,052,372 S2 rows in side tables, each with a plain
`btree` index on the cell-id hex string:

| table | rows | total size |
|---|---|---|
| `osm_multipolygons` (base, GiST-indexed) | 2,125,493 | 705 MB (526 MB table + ~179 MB index) |
| `feature_cells_h3` | 2,606,999 | 155 MB (130 MB table + 25 MB index) |
| `feature_cells_s2` | 3,052,372 | 186 MB (152 MB table + 34 MB index) |

825 features (0.039%) were demoted to the fallback resolution/level for
*both* systems — the estimator uses the same bbox-area threshold for both,
so "which features are outliers" is a single, shared decision.

### Query protocol

Three query-box sizes (0.01° / 0.05° / 0.2°, roughly 1 km / 5 km / 20 km at
this latitude), 8 random locations per size per run, 7 in-process repeats
per location, median-of-7 recorded per sample. For each sample, five
queries were timed against the same bbox:

- **GiST**: `geom && envelope AND ST_Intersects(geom, envelope)` — the
  exact predicate shape `tellurion-postgis` compiles for a bbox/intersects
  CQL2 filter, in the collection's native storage SRID.
- **H3 prefilter-only**: `cell_hex = ANY(query_covering)` against
  `feature_cells_h3` — the ceiling of what an index-less driver could do
  with nothing but cell membership and no geometry engine.
- **H3 prefilter + exact**: the prefilter's candidates joined back to the
  geometry table with the same `ST_Intersects` check — the same *exact*
  answer GiST already gives, computed the "cell prefilter in front of a
  driver that does have a geometry engine anyway" way.
- **S2 prefilter-only** and **S2 prefilter + exact**: the same two shapes
  against `feature_cells_s2`.

Correctness was checked, not assumed: across all 72 samples (3 runs × 24
size/location combinations), **zero** samples had `h3_count` or `s2_count`
below the exact GiST count — both prefilters are true supersets, as their
coverage guarantees (`ContainmentMode::Covers` for H3, a bounding-rect
covering for S2) promise. No false negatives were observed.

### Numbers

All times in milliseconds, median of 7 repeats, median across the samples
in each bucket.

**Run 1 (busier machine, n=8 samples/bucket):**

| query size | GiST | H3 prefilter | H3 prefilter+exact | S2 prefilter | S2 prefilter+exact |
|---|---|---|---|---|---|
| 0.01° (~1 km) | 17.98 | 6.20 | 16.09 | 4.45 | 15.97 |
| 0.05° (~5 km) | 21.80 | 12.26 | 23.41 | 14.87 | 24.41 |
| 0.2° (~20 km) | **13.61** | 85.39 | 75.19 | 105.73 | 94.46 |

**Runs 2+3 combined (quieter machine, n=16 samples/bucket):**

| query size | GiST | H3 prefilter | H3 prefilter+exact | S2 prefilter | S2 prefilter+exact |
|---|---|---|---|---|---|
| 0.01° (~1 km) | 5.88 | 0.90 | 6.79 | 0.77 | 5.94 |
| 0.05° (~5 km) | 6.42 | 3.42 | 8.08 | 4.46 | 9.12 |
| 0.2° (~20 km) | **7.23** | 42.93 | 34.29 | 59.94 | 48.09 |

The same pattern holds in both contention regimes: at the smallest,
sparsest query size, the *prefilter-only* numbers (no exact check, no
correctness guarantee) beat GiST by roughly 3–8x (3–4x under heavier contention, 6–8x under lighter) — but adding the exact
`ST_Intersects` check that's required to match GiST's actual answer erases
essentially all of that advantage (H3 prefilter+exact roughly ties GiST at
0.01°, loses at 0.05°, and loses badly — 3.7–4.7x slower — at 0.2°). At the
largest, densest bucket, GiST doesn't just win the apples-to-apples
comparison, it beats even the unverified prefilter-only numbers outright.
There is no query-size regime in this dataset where cell-set membership is
a real win against an existing GiST index once correctness is held
constant.

### Why: an EXPLAIN, not just a timing

For a bbox covering roughly the 0.2° bucket, the H3 prefilter's candidate
array had 1,507 distinct cell hexes. At that size, PostgreSQL's planner
abandoned the `feature_cells_h3_cell_idx` btree entirely and ran a
sequential scan over the full 2.6M-row side table with a per-row array
membership filter:

```
Aggregate (actual time=740.567..740.601 rows=1 loops=1)
  -> Sort (actual time=738.135..738.669 rows=1507 loops=1)
       -> Seq Scan on feature_cells_h3 (actual time=0.613..117.186 rows=869000 loops=3)
            Filter: (cell_hex = ANY ('{...1507 hexes...}'::text[]))
            Rows Removed by Filter: 2595008
 JIT: ... Emission 163.241 ms, Total 191.203 ms
 Execution Time: 904.240 ms
```

A cell-membership "index" degrades to a full table scan — plus real JIT
compilation overhead for evaluating a thousand-plus-element `= ANY(...)`
expression — exactly where a query gets large enough to need index help
the most. GiST's R-tree scales with the actual result cardinality; a
`btree` on a candidate cell list does not, once the candidate list itself
gets large. This is the mechanism behind the 0.2° numbers above, not an
artifact of one slow run.

### Verdict

Matches the issue author's own suspicion. For PostGIS specifically: a cell
index is not a performance win. It costs real, non-trivial storage (a
single side table added 22–26% on top of the base table's size — before
counting its own index), and it never beats GiST once the same exact
answer is required — the gap gets *worse*, not better, as queries grow
denser, which is backwards from what would justify shipping it.

## Directional reads: Q2, Q3, Q5

Not separately measured — argued from what this spike's own build and
query mechanics surfaced.

**Q2 (where cells live — a derived column vs. the outbox-maintained
derived index).** This spike used side tables for both systems, not a
column on the feature table, because a covering isn't a scalar: even at a
resolution tuned for building-scale features, the mean was 1.2–1.4
cells/feature and the tail (the 0.039% demoted to the fallback resolution)
needed many more. That shape — a separate table keyed by cell id, kept in
sync with a source table — is structurally much closer to the project's
existing outbox-maintained derived-index lane (see
`docs/design/2026-07-18-transactional-outbox-and-derived-index-contract.md`)
than to a new per-driver column convention. Extending that existing lane
with a spatial dimension is the lower-novel-surface-area option; this
spike did not build or benchmark that integration, only the cell-set
mechanic in isolation.

**Q3 (one resolution vs. a ladder).** Not theoretical — forced directly by
this dataset. A single fixed H3 resolution sized for the 86.8% of features
that are OSM buildings would have produced coverings in the tens of
thousands of cells for the 825 outlier features (one of which spans an
estimated ~82,275 km²) with no fallback. A resolution ladder — or, at an
absolute minimum, the single coarser fallback with a cheap estimator this
spike's harness implements (`bbox_cell_estimate`) — is required
cost-bounding machinery, not an optional refinement, the moment real
geometry-size skew (five orders of magnitude between median and max, in
one regional extract) is in scope. A single fixed resolution is not viable
against a real feature table.

**Q5 (write-maintenance cost, and a collection never written through
us).** The measured backfill cost (~121 µs/feature, computing both
coverings together) is cheap in aggregate but recurring on every write if
maintained incrementally rather than backfilled once — the same per-feature
cost, paid on the write path instead of up front. Storage cost (22–26% per
side table, recurring, not one-time) stacks on top of whatever the outbox
lane already costs to run. For a collection populated outside this
project entirely — the same posture the Iceberg driver spike's own
findings flagged as open for #103 — a cell index cannot be
write-maintained at all; it would need an out-of-band backfill/reconcile
pass with no delivery guarantee against concurrent external writes, a
materially heavier commitment than anything the outbox lane promises for
data it does maintain.

## Recommendation

- **Do not build a PostGIS-facing cell index.** Q4's numbers are
  unambiguous and get more unambiguous as queries get denser — exactly the
  regime a spatial index exists to help with.
- **If a cell index gets built at all, scope it to the drivers #103 itself
  named as index-less**: FlatGeobuf (bbox-only, packed R-tree, no CQL2),
  GeoParquet (row-group bbox pruning, then a linear scan inside the
  surviving group), Iceberg (manifest-level pruning, then an explicit
  refusal of `S_INTERSECTS` — see this project's own Iceberg driver spike
  findings), and the memory driver (full scan, no CQL2 at all). GeoPackage
  already has its own spec-mandated R\*Tree bbox pre-filter and is not a
  target.
- **Build on H3 via `h3o`, not S2.** Real polygon coverage today, against
  a bounding-rect approximation forced by an incomplete Rust S2 port.
- **A resolution ladder is required, not optional** — at minimum, a
  primary resolution plus an estimator-triggered coarser fallback, which
  is what this spike's own harness already implements and measured as
  cheap to run.
- **Prefer extending the existing outbox-maintained derived-index lane**
  with a spatial dimension over inventing a new per-driver column — pending
  its own design pass; this spike did not build or benchmark that
  integration.
- **Suggested follow-up**: this spike proved the negative (no win over an
  existing GiST index) but never measured the positive case an H3 index
  would actually need to justify itself — a real win over *no index at
  all* on one of the index-less drivers named above. FlatGeobuf is the
  smallest surface to try first: it already does bbox-only pruning via a
  real R-tree, so the comparison would be cell-set membership vs. that
  R-tree specifically, not vs. a naive linear scan.

## Appendix: harness (reproducible from this document alone)

The harness lives at `spike-scratch/harness/` inside the worktree this
spike ran in — excluded from git, never committed, and depends directly on
`h3o` and `s2`, which must never land in this project's real workspace
`Cargo.toml`. It is reproduced here in full so the measurements above can
be regenerated independently of that worktree.

### Dataset acquisition and load

```sh
mkdir -p demo-data/italy-isole-osm && cd demo-data/italy-isole-osm
curl --fail --location --retry 3 --retry-delay 2 --continue-at - \
  --output italy-isole-latest.osm.pbf \
  "https://download.geofabrik.de/europe/italy/isole-latest.osm.pbf"

ogr2ogr -f GPKG italy-isole.gpkg italy-isole-latest.osm.pbf multipolygons \
  -t_srs EPSG:3857 -lco GEOMETRY_NAME=geom -nlt PROMOTE_TO_MULTI \
  -nln italy_isole_multipolygons -progress

docker run -d --name tellurion-spike-pg -p 5435:5432 \
  -e POSTGRES_PASSWORD=test postgis/postgis:16-3.4

ogr2ogr -f PostgreSQL "PG:host=127.0.0.1 port=5435 dbname=postgres user=postgres password=test" \
  italy-isole.gpkg italy_isole_multipolygons \
  -nln osm_multipolygons -lco GEOMETRY_NAME=geom -lco FID=id \
  -nlt PROMOTE_TO_MULTI -progress
```

### `spike-scratch/harness/Cargo.toml`

```toml
[package]
name = "cell-index-harness"
version = "0.1.0"
edition = "2021"

[dependencies]
postgres = "0.19"
h3o = { version = "0.10", features = ["geo"] }
s2 = "0.1"
geo = "0.33"
geo-types = "0.7"
geojson = { version = "0.24", features = ["geo-types"] }
rand = "0.8"

[workspace]
```

### `spike-scratch/harness/src/main.rs`

```rust
// Spike harness for issue #103 (H3 vs S2 cell indexing).
//
// Not part of the tracked workspace: this crate lives under spike-scratch/,
// excluded from git via .git/info/exclude, and exists only to produce the
// measurements embedded in the findings doc. It depends directly on `s2`
// and `h3o` -- dependencies that must never land in the real workspace
// Cargo.toml per the spike's own ground rules.
//
// Subcommands:
//   build   -- polyfill every feature in osm_multipolygons with both H3 and
//              S2 cell coverings, load them into side tables with a btree
//              index on the cell hex string.
//   bench   -- run repeated bbox queries at several sizes, comparing the
//              GiST-indexed geometry column against the cell-membership
//              side tables, with and without an exact ST_Intersects check
//              on the surviving candidates.

use std::collections::HashSet;
use std::io::Write;
use std::env;
use std::time::Instant;

use geo::BoundingRect;
use geo_types::{Geometry, Polygon, Rect as GeoRect};
use h3o::geom::{ContainmentMode, TilerBuilder};
use h3o::{LatLng as H3LatLng, Resolution};
use postgres::{Client, NoTls};
use rand::Rng;
use s2::rect::Rect as S2Rect;
use s2::region::RegionCoverer;

const PG_CONN: &str = "host=127.0.0.1 port=5435 user=postgres password=test dbname=postgres";

// H3 primary resolution for building-scale features, and the coarser
// fallback used for the long tail of oversized polygons (natural areas,
// admin boundaries) so a single outlier can't explode the covering size.
const H3_RES_PRIMARY: Resolution = Resolution::Nine;
const H3_RES_FALLBACK: Resolution = Resolution::Six;
const H3_CELL_CAP: usize = 300;

// S2 levels chosen to land in roughly the same area range as the H3
// resolutions above (level 15 cells average ~0.037 km^2, level 9 hexagons
// ~0.737 km^2 -- not identical, deliberately not tuned tighter for a spike).
const S2_LEVEL_PRIMARY: u8 = 15;
const S2_LEVEL_FALLBACK: u8 = 9;

fn main() {
    let args: Vec<String> = env::args().collect();
    match args.get(1).map(String::as_str) {
        Some("build") => build(),
        Some("bench") => bench(),
        _ => eprintln!("usage: cell-index-harness <build|bench>"),
    }
}

fn parse_geometry(geojson_str: &str) -> Option<Geometry<f64>> {
    let gj = geojson_str.parse::<geojson::GeoJson>().ok()?;
    let geom = match gj {
        geojson::GeoJson::Geometry(g) => g,
        _ => return None,
    };
    Geometry::<f64>::try_from(geom).ok()
}

fn polygons_of(geom: &Geometry<f64>) -> Vec<Polygon<f64>> {
    match geom {
        Geometry::Polygon(p) => vec![p.clone()],
        Geometry::MultiPolygon(mp) => mp.0.clone(),
        _ => vec![],
    }
}

fn bounding_union(a: GeoRect<f64>, b: GeoRect<f64>) -> GeoRect<f64> {
    let min_x = a.min().x.min(b.min().x);
    let min_y = a.min().y.min(b.min().y);
    let max_x = a.max().x.max(b.max().x);
    let max_y = a.max().y.max(b.max().y);
    GeoRect::new((min_x, min_y), (max_x, max_y))
}

/// Rough cell-count estimate for a bbox at a given H3 resolution: flat-earth
/// bbox area (using a hexagon near the bbox center to gauge local cell area,
/// since H3 cell area varies with latitude) divided by one cell's area.
/// Only used to decide the primary/fallback-resolution cutoff, so a rough
/// estimate is enough.
fn bbox_cell_estimate(bbox: &GeoRect<f64>, resolution: Resolution) -> usize {
    let center_lat = (bbox.min().y + bbox.max().y) / 2.0;
    let center_lng = (bbox.min().x + bbox.max().x) / 2.0;
    let Ok(center) = H3LatLng::new(center_lat, center_lng) else {
        return usize::MAX;
    };
    let hex_area_km2 = center.to_cell(resolution).area_km2();
    if hex_area_km2 <= 0.0 {
        return usize::MAX;
    }

    const KM_PER_DEG: f64 = 111.32;
    let width_km = (bbox.max().x - bbox.min().x) * KM_PER_DEG * center_lat.to_radians().cos().abs().max(0.01);
    let height_km = (bbox.max().y - bbox.min().y) * KM_PER_DEG;
    let bbox_area_km2 = (width_km * height_km).abs();

    (bbox_area_km2 / hex_area_km2).ceil().max(1.0) as usize
}

/// H3 covering for one feature (possibly multi-part), with a fallback to a
/// coarser resolution when the primary-resolution estimate is too large.
fn h3_cover_feature(polys: &[Polygon<f64>]) -> (Vec<u64>, Resolution) {
    let bbox = polys
        .iter()
        .filter_map(|p| p.bounding_rect())
        .reduce(bounding_union);

    let resolution = match bbox {
        Some(bbox) => {
            let estimate = bbox_cell_estimate(&bbox, H3_RES_PRIMARY);
            if estimate > H3_CELL_CAP {
                H3_RES_FALLBACK
            } else {
                H3_RES_PRIMARY
            }
        }
        None => H3_RES_PRIMARY,
    };

    let mut tiler = TilerBuilder::new(resolution)
        .containment_mode(ContainmentMode::Covers)
        .build();
    for p in polys {
        // A handful of OSM rings are degenerate (self-intersecting,
        // duplicated points); skip rather than aborting the whole feature.
        let _ = tiler.add(p.clone());
    }
    let cells: HashSet<u64> = tiler.into_coverage().map(u64::from).collect();
    (cells.into_iter().collect(), resolution)
}

/// S2 covering for one feature. `RegionCoverer` only has `Region` impls for
/// `Rect`/`Cap`/`Cell`/`CellUnion`/`Point` in the available crate (`Loop`
/// and `Polygon` are listed "pending" upstream) -- so this covers the
/// feature's bounding rectangle, not its true polygon shape. That
/// approximation, forced by the ecosystem gap, is itself part of the
/// spike's Q1 finding.
fn s2_cover_feature(polys: &[Polygon<f64>]) -> (Vec<u64>, u8) {
    let bbox = polys
        .iter()
        .filter_map(|p| p.bounding_rect())
        .reduce(bounding_union);

    let Some(bbox) = bbox else {
        return (vec![], S2_LEVEL_PRIMARY);
    };

    // geo::Rect is (x=lng, y=lat) in degrees.
    let estimate = bbox_cell_estimate(&bbox, H3_RES_PRIMARY);
    let level = if estimate > H3_CELL_CAP {
        S2_LEVEL_FALLBACK
    } else {
        S2_LEVEL_PRIMARY
    };

    let rect = S2Rect::from_degrees(bbox.min().y, bbox.min().x, bbox.max().y, bbox.max().x);
    let coverer = RegionCoverer {
        min_level: level,
        max_level: level,
        level_mod: 1,
        max_cells: H3_CELL_CAP,
    };
    let union = coverer.covering(&rect);
    (union.0.iter().map(|c| c.0).collect(), level)
}

fn copy_in_rows(client: &mut Client, table: &str, rows: &[(i32, String, i16)]) {
    if rows.is_empty() {
        return;
    }
    let sql = format!("COPY {table} FROM STDIN WITH (FORMAT csv)");
    let mut writer = client.copy_in(&sql).expect("copy_in");
    for (id, hex, res) in rows {
        writeln!(writer, "{id},{hex},{res}").expect("write copy row");
    }
    writer.finish().expect("finish copy_in");
}

fn build() {
    let mut client = Client::connect(PG_CONN, NoTls).expect("connect");

    client
        .batch_execute(
            "DROP TABLE IF EXISTS feature_cells_h3;
             DROP TABLE IF EXISTS feature_cells_s2;
             CREATE TABLE feature_cells_h3 (feature_id integer NOT NULL, cell_hex char(16) NOT NULL, res smallint NOT NULL);
             CREATE TABLE feature_cells_s2 (feature_id integer NOT NULL, cell_hex char(16) NOT NULL, lvl smallint NOT NULL);",
        )
        .expect("create tables");

    let total: i64 = client
        .query_one("SELECT count(*) FROM osm_multipolygons", &[])
        .unwrap()
        .get(0);
    eprintln!("building cell indexes for {total} features");

    let mut last_id: i32 = 0;
    let batch_size = 2000i64;
    let mut processed = 0i64;
    let mut h3_outliers = 0i64;
    let mut s2_outliers = 0i64;
    let mut h3_rows = 0i64;
    let mut s2_rows = 0i64;
    let start = Instant::now();

    loop {
        let rows = client
            .query(
                "SELECT id, ST_AsGeoJSON(ST_Transform(geom, 4326)) \
                 FROM osm_multipolygons WHERE id > $1 ORDER BY id LIMIT $2",
                &[&last_id, &batch_size],
            )
            .expect("fetch batch");
        if rows.is_empty() {
            break;
        }

        let mut h3_values: Vec<(i32, String, i16)> = Vec::new();
        let mut s2_values: Vec<(i32, String, i16)> = Vec::new();

        for row in &rows {
            let id: i32 = row.get(0);
            let gj: String = row.get(1);
            last_id = id;

            let Some(geom) = parse_geometry(&gj) else {
                continue;
            };
            let polys = polygons_of(&geom);
            if polys.is_empty() {
                continue;
            }

            let (h3_cells, h3_res) = h3_cover_feature(&polys);
            if h3_res == H3_RES_FALLBACK {
                h3_outliers += 1;
            }
            for c in &h3_cells {
                h3_values.push((id, format!("{c:016x}"), u8::from(h3_res) as i16));
            }

            let (s2_cells, s2_lvl) = s2_cover_feature(&polys);
            if s2_lvl == S2_LEVEL_FALLBACK {
                s2_outliers += 1;
            }
            for c in &s2_cells {
                s2_values.push((id, format!("{c:016x}"), s2_lvl as i16));
            }
        }

        copy_in_rows(&mut client, "feature_cells_h3", &h3_values);
        copy_in_rows(&mut client, "feature_cells_s2", &s2_values);

        h3_rows += h3_values.len() as i64;
        s2_rows += s2_values.len() as i64;
        processed += rows.len() as i64;
        if processed % 20000 < batch_size {
            eprintln!(
                "{processed}/{total} features, {:.1}s elapsed, h3_rows={h3_rows} s2_rows={s2_rows}",
                start.elapsed().as_secs_f64()
            );
        }
    }

    eprintln!(
        "done: {processed} features in {:.1}s, h3_outliers(fallback-res)={h3_outliers}, s2_outliers(fallback-level)={s2_outliers}, h3_rows={h3_rows}, s2_rows={s2_rows}",
        start.elapsed().as_secs_f64()
    );

    client
        .batch_execute(
            "CREATE INDEX feature_cells_h3_cell_idx ON feature_cells_h3 USING btree (cell_hex);
             CREATE INDEX feature_cells_s2_cell_idx ON feature_cells_s2 USING btree (cell_hex);
             ANALYZE feature_cells_h3;
             ANALYZE feature_cells_s2;
             ANALYZE osm_multipolygons;",
        )
        .expect("index + analyze");
    eprintln!("indexes built");
}

struct BBoxDeg {
    min_lat: f64,
    min_lng: f64,
    max_lat: f64,
    max_lng: f64,
}

/// Cover a query bbox at both the primary and fallback resolution/level, so
/// features that were demoted to the coarser fallback during `build` are
/// still found by an equality match on cell_hex.
fn h3_query_cells(bbox: &BBoxDeg) -> Vec<String> {
    let rect = GeoRect::new((bbox.min_lng, bbox.min_lat), (bbox.max_lng, bbox.max_lat));
    let poly = rect.to_polygon();
    let mut out = HashSet::new();
    for res in [H3_RES_PRIMARY, H3_RES_FALLBACK] {
        let mut tiler = TilerBuilder::new(res)
            .containment_mode(ContainmentMode::Covers)
            .build();
        if tiler.add(poly.clone()).is_ok() {
            for c in tiler.into_coverage() {
                out.insert(format!("{:016x}", u64::from(c)));
            }
        }
    }
    out.into_iter().collect()
}

fn s2_query_cells(bbox: &BBoxDeg) -> Vec<String> {
    let rect = S2Rect::from_degrees(bbox.min_lat, bbox.min_lng, bbox.max_lat, bbox.max_lng);
    let mut out = HashSet::new();
    for level in [S2_LEVEL_PRIMARY, S2_LEVEL_FALLBACK] {
        let coverer = RegionCoverer {
            min_level: level,
            max_level: level,
            level_mod: 1,
            max_cells: H3_CELL_CAP,
        };
        for c in coverer.covering(&rect).0 {
            out.insert(format!("{:016x}", c.0));
        }
    }
    out.into_iter().collect()
}

fn median(mut xs: Vec<f64>) -> f64 {
    xs.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let n = xs.len();
    if n == 0 {
        return f64::NAN;
    }
    if n % 2 == 1 {
        xs[n / 2]
    } else {
        (xs[n / 2 - 1] + xs[n / 2]) / 2.0
    }
}

fn time_it<T>(mut f: impl FnMut() -> T, repeats: usize) -> (Vec<f64>, T) {
    let mut times = Vec::with_capacity(repeats);
    let mut last = None;
    for _ in 0..repeats {
        let start = Instant::now();
        let r = f();
        times.push(start.elapsed().as_secs_f64() * 1000.0);
        last = Some(r);
    }
    (times, last.unwrap())
}

fn bench() {
    let mut client = Client::connect(PG_CONN, NoTls).expect("connect");

    // Dataset extent in EPSG:3857, converted to WGS84 degrees for the
    // random-bbox sampler (matches the extent reported by ST_Extent earlier).
    let (min_lng, min_lat) = webmerc_to_lonlat(904970.197403, 4230214.600588);
    let (max_lng, max_lat) = webmerc_to_lonlat(1742492.850419, 5059881.865287);

    let sizes_deg = [0.01_f64, 0.05, 0.2]; // small / medium / large query boxes
    let samples_per_size = 8;
    let repeats = 7;

    let mut rng = rand::thread_rng();

    println!("size_deg,sample,gist_ms,h3_prefilter_ms,h3_prefilter_exact_ms,s2_prefilter_ms,s2_prefilter_exact_ms,gist_count,h3_count,s2_count");

    for &size in &sizes_deg {
        for sample in 0..samples_per_size {
            let lat0 = rng.gen_range(min_lat..(max_lat - size).max(min_lat + 0.001));
            let lng0 = rng.gen_range(min_lng..(max_lng - size).max(min_lng + 0.001));
            let bbox = BBoxDeg {
                min_lat: lat0,
                min_lng: lng0,
                max_lat: lat0 + size,
                max_lng: lng0 + size,
            };

            // GiST: bbox && then exact ST_Intersects, in the collection's
            // native storage SRID (3857), the way tellurion-postgis itself
            // would compile a bbox/intersects CQL2 predicate.
            let (gx0, gy0) = lonlat_to_webmerc(bbox.min_lng, bbox.min_lat);
            let (gx1, gy1) = lonlat_to_webmerc(bbox.max_lng, bbox.max_lat);
            let gist_sql = "SELECT count(*) FROM osm_multipolygons \
                 WHERE geom && ST_MakeEnvelope($1,$2,$3,$4,3857) \
                 AND ST_Intersects(geom, ST_MakeEnvelope($1,$2,$3,$4,3857))";
            let (gist_times, gist_count) = time_it(
                || {
                    let row = client
                        .query_one(gist_sql, &[&gx0, &gy0, &gx1, &gy1])
                        .unwrap();
                    row.get::<_, i64>(0)
                },
                repeats,
            );

            let h3_cells = h3_query_cells(&bbox);
            let s2_cells = s2_query_cells(&bbox);

            let h3_pref_sql =
                "SELECT count(DISTINCT feature_id) FROM feature_cells_h3 WHERE cell_hex = ANY($1)";
            let (h3_pref_times, h3_count) = time_it(
                || {
                    let row = client.query_one(h3_pref_sql, &[&h3_cells]).unwrap();
                    row.get::<_, i64>(0)
                },
                repeats,
            );

            let h3_exact_sql = "SELECT count(*) FROM (\
                 SELECT DISTINCT feature_id FROM feature_cells_h3 WHERE cell_hex = ANY($1)\
                 ) c JOIN osm_multipolygons m ON m.id = c.feature_id \
                 WHERE ST_Intersects(m.geom, ST_MakeEnvelope($2,$3,$4,$5,3857))";
            let (h3_exact_times, _) = time_it(
                || {
                    let row = client
                        .query_one(h3_exact_sql, &[&h3_cells, &gx0, &gy0, &gx1, &gy1])
                        .unwrap();
                    row.get::<_, i64>(0)
                },
                repeats,
            );

            let s2_pref_sql =
                "SELECT count(DISTINCT feature_id) FROM feature_cells_s2 WHERE cell_hex = ANY($1)";
            let (s2_pref_times, s2_count) = time_it(
                || {
                    let row = client.query_one(s2_pref_sql, &[&s2_cells]).unwrap();
                    row.get::<_, i64>(0)
                },
                repeats,
            );

            let s2_exact_sql = "SELECT count(*) FROM (\
                 SELECT DISTINCT feature_id FROM feature_cells_s2 WHERE cell_hex = ANY($1)\
                 ) c JOIN osm_multipolygons m ON m.id = c.feature_id \
                 WHERE ST_Intersects(m.geom, ST_MakeEnvelope($2,$3,$4,$5,3857))";
            let (s2_exact_times, _) = time_it(
                || {
                    let row = client
                        .query_one(s2_exact_sql, &[&s2_cells, &gx0, &gy0, &gx1, &gy1])
                        .unwrap();
                    row.get::<_, i64>(0)
                },
                repeats,
            );

            println!(
                "{size},{sample},{:.3},{:.3},{:.3},{:.3},{:.3},{gist_count},{h3_count},{s2_count}",
                median(gist_times),
                median(h3_pref_times),
                median(h3_exact_times),
                median(s2_pref_times),
                median(s2_exact_times),
            );
        }
    }
}

// Spherical Web Mercator, matching what ogr2ogr used for -t_srs EPSG:3857
// (good enough for indexing/query-box purposes, not a geodesy claim).
fn lonlat_to_webmerc(lon: f64, lat: f64) -> (f64, f64) {
    const R: f64 = 6378137.0;
    let x = lon.to_radians() * R;
    let y = ((lat.to_radians() / 2.0 + std::f64::consts::FRAC_PI_4).tan()).ln() * R;
    (x, y)
}

fn webmerc_to_lonlat(x: f64, y: f64) -> (f64, f64) {
    const R: f64 = 6378137.0;
    let lon = (x / R).to_degrees();
    let lat = (2.0 * (y / R).exp().atan() - std::f64::consts::FRAC_PI_2).to_degrees();
    (lon, lat)
}
```

### Commands used to produce the numbers above

```sh
cargo build --release
./target/release/cell-index-harness build   # ~258s, prints outlier/row counts
./target/release/cell-index-harness bench > run1.csv   # repeat 3x for spread
```
