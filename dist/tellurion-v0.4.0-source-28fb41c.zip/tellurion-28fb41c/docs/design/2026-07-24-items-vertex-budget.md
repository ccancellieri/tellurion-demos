# Items Vertex Budget Design

**Status:** Approved for implementation

**Issues:** #148, followed by #1 remeasurement

## Goal

Bound the geometry-encoding cost of OGC API Features and STAC item
responses without silently simplifying, truncating, or omitting geometry.
An ordinary request continues to receive byte-for-byte exact coordinates.
A request whose selected page exceeds the configured vertex budget receives
a fast, named refusal before PostGIS performs the expensive GeoJSON encode.

The bound applies to collection item pages and single-item lookups. It is a
serving safety limit, not a replacement for keyset pagination, the existing
HTTP concurrency limit, or the request timeout.

## Non-goals

- Do not simplify exact Features or STAC item geometry.
- Do not return a partial page that silently skips an oversized feature.
- Do not change the tile lane's separate simplification and vertex-budget
  behavior.
- Do not add offset pagination, whole-table counts, or a second settings
  precedence system.
- Do not claim that a bounded refusal is a successful `200` response in the
  #1 benchmark. Successful and refused request measurements remain separate.

## Configuration contract

Add `settings.items_vertex_budget` to the existing platform → tenant →
catalog → collection settings chain.

- The value is a positive integer.
- Nearest level wins, including named profile expansion and `final` key
  governance.
- The built-in default is **50,000 vertices per returned page**.
- A single-item response is a one-feature page and is governed by the same
  value.
- The budget counts source geometry vertices. CRS transformation and axis
  flipping do not change that count.

Fifty thousand is below the 83,495-vertex regional boundary that exposed
#148, while remaining above the 5,000–25,000-vertex provincial boundaries
recorded in the same investigation. It therefore stops the known
single-feature outlier and also prevents a page from multiplying several
large-but-individually-valid geometries without bound. Operators serving
larger exact features can raise the value deliberately at the narrowest
appropriate settings level.

The effective-config view exposes the concrete value and its provenance.
`config/example.yaml` documents the default and the consequence of raising
it.

## Core contract

Add a distinct core error carrying:

- collection id;
- first feature id whose inclusion crosses the budget;
- cumulative vertex count at that point; and
- configured limit.

The shared RFC 9457 mapper returns:

- HTTP `422 Unprocessable Entity`;
- code `ItemsVertexBudgetExceeded`; and
- a detail explaining that exact geometry was refused, not simplified.

The response tells the caller to narrow the request with a bounding box or
smaller page when that can avoid the crossing feature, or asks the operator
to raise the collection budget intentionally. A single feature larger than
the limit cannot be made valid by lowering `limit`.

Add a driver-neutral GeoJSON vertex counter in `tellurion-core`. It supports
Point, MultiPoint, LineString, MultiLineString, Polygon, MultiPolygon, and
recursive GeometryCollection values using saturating `u64` arithmetic.
Malformed or absent geometry contributes zero here; validation remains the
owning driver's responsibility.

All resolved feature sources are wrapped by one budget-enforcement
decorator. The decorator checks pages and single items returned by every
driver, so DuckDB, FlatGeobuf, GeoPackage, GeoParquet, Iceberg, memory, and
future drivers cannot accidentally bypass the contract. Drivers may enforce
the same contract earlier to avoid expensive work. A budget error is
deterministic and must not trigger a fallback-driver retry.

## PostGIS fast path

PostGIS enforces the budget before `ST_AsGeoJSON`.

For a page query:

1. The existing filters and keyset order select at most `limit + 1`
   candidate rows in a CTE.
2. A second CTE computes each candidate's `ST_NPoints` value and a cumulative
   sum in the same primary-key order.
3. `ST_AsGeoJSON` runs only for rows within the requested page whose
   cumulative sum is within the budget.
4. The `limit + 1` look-ahead row is never GeoJSON-encoded; it exists only
   to decide whether a next link is required.
5. If a requested-page row crosses the budget, the driver returns the named
   core error using that row's id, cumulative count, and configured limit.

The cumulative window operates only on the bounded candidate CTE, never the
entire matching collection.

For a single-item query, PostGIS obtains `ST_NPoints` and conditionally
performs `ST_AsGeoJSON` only when the count is within the same budget.

Both paths count the raw stored geometry before any requested output-CRS
transformation. This avoids paying transformation cost merely to decide
whether the request must be refused, while preserving equivalent counts for
accepted geometry.

## Other drivers

The core decorator is the mandatory correctness backstop. A non-PostGIS
driver may initially build its GeoJSON before the decorator counts it; the
wire response remains bounded at the protocol boundary, but that driver's
encode-time CPU and memory are not yet bounded by this generic check. Such a
driver does not claim the PostGIS pre-encode optimization.

Drivers with an existing decoded-geometry loop may add an earlier check only
when it is surgical and uses the same cumulative semantics. Early-driver
optimizations outside PostGIS are not required to close #148.

## Pagination and authorization

The budget is evaluated after all request and authorization filters have
selected candidate rows. It therefore never reveals the id or complexity of
a feature the caller is not authorized to see.

The look-ahead row does not consume the returned page budget and does not
require GeoJSON serialization. On an accepted page, next-token behavior is
unchanged. On refusal, no partial page or next token is returned.

## Observability

Increment `items_vertex_budget_exceeded_total` with a bounded `backend`
label:

- `postgis` for the pre-encode fast path;
- `generic` for the core decorator backstop.

Log one warning with collection id, feature id, cumulative vertices, limit,
and backend. Do not put collection or feature ids into metric labels.

## API documentation

The Features and STAC OpenAPI documents describe the `422` response on item
list/search and single-item operations. The description states that exact
geometry is refused when the configured page budget is exceeded.

## Verification

Implementation follows red-green-refactor:

1. Settings tests fail until parsing, non-zero validation, inheritance,
   profile expansion, final-key governance, provenance, and router overlay
   all carry `items_vertex_budget`.
2. Core unit tests fail until all GeoJSON geometry forms and saturating
   cumulative counting work.
3. Router/decorator tests fail until an over-budget page and single item
   return the named error, an under-budget response is unchanged, and a
   deterministic budget error does not advance to a fallback driver.
4. PostGIS SQL tests fail until the bounded candidate CTE, cumulative count,
   conditional encode, and unencoded look-ahead row are present for integer,
   UUID, text, filtered, paged, and requested-CRS query shapes.
5. PostGIS driver tests fail until the first crossing feature returns the
   exact error fields and accepted geometry remains byte-identical.
6. Features and STAC HTTP tests fail until the `422` RFC 9457 response has
   the expected code and contains no partial FeatureCollection.
7. Formatting, strict clippy, the affected crate tests, the full locked
   workspace test suite, and the artifact audit must pass.

After implementation, repeat #1's quiet-host `limit=100`, representative
page, and single-item measurements when the Italy dataset is available.
Report successful `200` and bounded `422` rows separately. Close #148 when
the contract and tests land. Close #1 only if its documented acceptance
criteria are met or the issue explicitly accepts a revised bounded-service
criterion.
