# Reference in-memory driver implementation plan

Status: superseded by `2026-07-18-driver-authoring-reference-driver.md` and
the shipped `tellurion-memory` crate; see `docs/driver-authoring.md` for the
current guide. Kept for history only.

**Goal:** Add a readable GeoJSON-backed driver and an executable authoring
checklist that pin Tellurion's public storage capability contract.

**Architecture:** `tellurion-memory` is an ordinary workspace crate depending
only on `tellurion-core` and common serialization/error crates. Construction
validates and indexes immutable datasets; thin trait implementations expose the
derived catalog and feature-query behavior through the existing registry and
router without adding production server wiring.

**Technology:** Rust 2021, `serde_json`, `async-trait`, `thiserror`, Tokio tests.

## Global constraints

- Work only on issue #64.
- Do not edit CQL2, authorization, volume, write/outbox, benchmark, server-route,
  or protocol-response code.
- Advertise only `CatalogSource` and `FeatureSource`; filtering remains false,
  and tiles and volumes remain absent.
- Store features by stringified id in deterministic `BTreeMap` order.
- Tokens are `v1.` followed by lowercase hexadecimal UTF-8 bytes of the last id.
- The crate is a test/documentation fixture and is not registered by the server.
- Every behavioral change begins with a failing test and ends with the scoped
  test passing before the next behavior is added.

---

### Task 1: Validate GeoJSON and derive catalog metadata

**Files:**

- Modify: `Cargo.toml`
- Create: `crates/tellurion-memory/Cargo.toml`
- Create: `crates/tellurion-memory/src/lib.rs`
- Create: `crates/tellurion-memory/src/error.rs`
- Create: `crates/tellurion-memory/src/dataset.rs`
- Create: `crates/tellurion-memory/tests/features.rs`

**Interfaces:**

- Produce `MemoryDataset::from_feature_collection(name: impl Into<String>,
  document: serde_json::Value) -> Result<MemoryDataset, MemoryDriverError>`.
- Produce crate-private dataset accessors for name, physical metadata, extent,
  row count, schema, item lookup, and page selection.
- `MemoryDriverError` has `Configuration(String)` and `InvalidQuery(String)`;
  its conversion to `tellurion_core::Error` preserves those categories.

- [ ] Add `crates/tellurion-memory` to the root workspace and create its
  manifest with `tellurion-core`, `async-trait`, `serde_json`, and `thiserror`
  dependencies plus Tokio as a dev dependency.
- [ ] Write tests that construct a valid FeatureCollection containing numeric
  and string ids, every geometry family, null geometry, mixed property values,
  and unsorted input. Assert the derived name, `geometry` column, `id` primary
  key, SRID 4326, exact extent/count, homogeneous geometry-type behavior, and
  conservative property types.
- [ ] Run `cargo test -p tellurion-memory --test features dataset_` and confirm
  it fails because `MemoryDataset` does not exist.
- [ ] Implement the minimum immutable dataset representation: validate the
  top-level type, each Feature object, string/numeric ids, object properties,
  and geometry structure; recursively walk coordinates and GeometryCollections
  to compute per-feature and collection envelopes.
- [ ] Add tests rejecting non-FeatureCollections, missing/invalid/duplicate ids,
  non-object properties, unknown geometry types, malformed coordinate nesting,
  non-finite coordinates, and empty geometry coordinate arrays.
- [ ] Run those tests and confirm the new rejection tests fail for the intended
  validation gaps.
- [ ] Complete geometry validation and property-type unioning with these exact
  mappings: boolean, bigint, double precision, text, and json for structured,
  conflicting, or all-null values.
- [ ] Run `cargo test -p tellurion-memory --test features dataset_` and confirm
  all dataset tests pass.
- [ ] Commit as `I add validated in-memory GeoJSON datasets`.

### Task 2: Implement deterministic feature query semantics

**Files:**

- Modify: `crates/tellurion-memory/src/dataset.rs`
- Modify: `crates/tellurion-memory/src/error.rs`
- Modify: `crates/tellurion-memory/tests/features.rs`

**Interfaces:**

- Produce crate-private
  `MemoryDataset::items(&ItemsQuery) -> tellurion_core::Result<FeaturePage>`.
- Produce crate-private
  `MemoryDataset::item(id: &str) -> Option<serde_json::Value>`.
- The token encoder returns `v1.<hex>`; the decoder accepts only canonical
  lowercase even-length hex that decodes to a present UTF-8 feature id.

- [ ] Write a paging test with deliberately unsorted ids, limit two, and a
  loop that follows `next_token`; assert stable id order, no duplicates, exact
  `number_matched`, and a token only when another match remains.
- [ ] Run the paging test and confirm it fails because query methods are absent.
- [ ] Implement keyset paging using `BTreeMap::range` after the decoded cursor,
  selecting `limit + 1` matching entries so `next_token` is emitted only when
  another match exists.
- [ ] Run the paging test and confirm it passes.
- [ ] Write bbox tests covering boundary-touch inclusion, excluded and null
  geometries, exact match count before paging, and invalid bbox shapes
  (non-finite values or min greater than max).
- [ ] Run the bbox tests and confirm the invalid and spatial cases fail.
- [ ] Implement bbox intersection using the envelopes derived at construction;
  null geometry never matches a bbox but remains in unfiltered results.
- [ ] Add tests for exact item lookup, missing item as `None`, zero limit,
  malformed prefix/hex/UTF-8 tokens, a token for an absent id, non-canonical
  uppercase hex, datetime input, filter input, and `filter_capable() == false`.
- [ ] Run these tests and confirm each new unsupported-input test fails before
  its check is implemented.
- [ ] Implement defensive `Error::Invalid` refusals for limit zero, invalid or
  stale tokens, datetime, and filter without adding a filtering capability.
- [ ] Run `cargo test -p tellurion-memory --test features` and confirm it passes.
- [ ] Commit as `I implement stable in-memory feature queries`.

### Task 3: Pin the public driver, factory, and router contract

**Files:**

- Create: `crates/tellurion-memory/src/driver.rs`
- Modify: `crates/tellurion-memory/src/lib.rs`
- Create: `crates/tellurion-memory/tests/contract.rs`

**Interfaces:**

- Produce `MemoryDriver::new(datasets: impl IntoIterator<Item = MemoryDataset>)
  -> Result<MemoryDriver, MemoryDriverError>`.
- Produce `MemoryDriverFactory::new() -> MemoryDriverFactory` and
  `insert(storage_id: impl Into<String>, driver: MemoryDriver)
  -> Result<(), MemoryDriverError>`.
- `MemoryDriverFactory` implements `DriverFactory` with name `memory`; build
  looks up `StorageDecl.id` and returns `Error::Config` if it is absent.

- [ ] Write contract tests that create ordinary YAML `AppConfig`, `Registry`,
  and `Router` values and assert a matching reference collection passes
  `validate_catalog`, resolves features, and exposes catalog-derived table,
  geometry, primary key, extent, row count, and schema through its effective
  declaration/descriptor path.
- [ ] Run `cargo test -p tellurion-memory --test contract` and confirm it fails
  because the driver and factory do not exist.
- [ ] Implement `CatalogSource` for an `Arc`-shared backend over the datasets,
  delegating collections, extent, row estimate, schema, and no temporal column.
- [ ] Implement `FeatureSource` by resolving `CollectionDecl::table` (falling
  back to its id) to a dataset and delegating `items`/`item`; leave
  `filter_capable` at its default false.
- [ ] Implement `StorageDriver` with mandatory catalog and optional features
  accessors only, plus the preload factory keyed by storage id.
- [ ] Run the happy-path contract tests and confirm they pass.
- [ ] Add contract tests that assert duplicate dataset names and duplicate
  storage registrations fail, missing storage registration is a config error,
  absent physical collection fails boot validation, and an explicit tiles lane
  produces the router's existing precise missing-capability config error.
- [ ] Run each new test once red, implement only the missing duplicate and
  lookup checks, then rerun `cargo test -p tellurion-memory --test contract`.
- [ ] Commit as `I add the reference memory driver contract`.

### Task 4: Publish the authoring guide and verify the branch

**Files:**

- Create: `docs/driver-authoring.md`
- Modify only if generated by Cargo: `Cargo.lock`

**Interfaces:**

- The guide links each mandatory/optional obligation to a concrete reference
  type and named test, and clearly separates driver behavior from assembled
  OGC API conformance.

- [ ] Write the guide in implementation order: capability selection,
  `CatalogSource`, optional sources, deterministic paging, shared error mapping,
  honest filtering refusal, factory registration, router boot validation, and
  default-build isolation.
- [ ] Add a copyable checklist naming the tests for catalog accuracy, feature
  paging, token rejection, capability honesty, boot validation, and error
  categories. Include normative links for OGC API Features Part 1 paging and
  Part 3 filtering without claiming the trait alone establishes conformance.
- [ ] Run `cargo fmt --all --check`.
- [ ] Run `cargo clippy -p tellurion-memory --all-targets -- -D warnings`.
- [ ] Run `cargo test -p tellurion-memory`.
- [ ] Run `cargo test -p tellurion-core`.
- [ ] Run `cargo test --workspace`.
- [ ] Inspect `git diff --check`, the branch diff, and staged content for private
  paths, personal data, attribution, or edits outside the issue fence.
- [ ] Commit as `I document the storage driver authoring path`.
- [ ] Refresh `origin/main`, rebase if it advanced, rerun affected gates, push
  the branch, open one issue-linked PR, and record the verification summary on
  issue #64. Keep the issue open until the PR is merged.
