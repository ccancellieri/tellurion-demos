# Items Vertex Budget Implementation Plan

**Goal:** Bound exact OGC API Features and STAC item responses by cumulative
geometry vertices, with an early PostGIS refusal before GeoJSON encoding and a
driver-neutral correctness backstop.

**Success criteria:**

- `settings.items_vertex_budget` resolves through the existing four-level
  settings chain, profiles, `final` governance, effective-config views, and
  router overlays, with a built-in default of 50,000.
- Every feature source refuses a page or single item whose cumulative source
  geometry exceeds the effective budget, without returning partial or
  simplified geometry.
- PostGIS counts bounded candidates before `ST_AsGeoJSON`, never encodes the
  look-ahead row, and returns the first crossing feature and cumulative count.
- Features and STAC expose the refusal as an RFC 9457 `422` problem with code
  `ItemsVertexBudgetExceeded`.
- The affected crate suites, strict linting, full locked workspace suite, and
  tracked-artifact audits pass.

## Task 1: Add the inheritable setting

**Files:**

- Modify `crates/tellurion-core/src/config.rs`
- Modify `crates/tellurion-core/src/settings.rs`
- Modify `crates/tellurion-core/src/router.rs`
- Modify `crates/tellurion-core/src/lib.rs`
- Modify `crates/tellurion-server/src/config_view.rs`
- Modify `config/example.yaml`

1. Add failing config tests for rejecting zero at every settings level and for
   accepting the key in profile and `final` declarations.
2. Add failing settings tests for the 50,000 default, nearest-level precedence,
   profile provenance, and field-for-field provenance completeness.
3. Add a failing router test proving an inherited value is overlaid onto the
   resolved collection declaration.
4. Run the focused core tests and confirm the new tests fail because the field
   is absent.
5. Add the field to `SettingsDecl`, its fixed key vocabulary, validation, and
   `setting_is_declared`.
6. Add the default, effective value, provenance, and resolver wiring.
7. Carry the resolved value through router materialization and collection
   overlay; add it to the effective-config wire view and example config.
8. Rerun the focused tests and commit the passing settings slice.

## Task 2: Add driver-neutral counting and refusal

**Files:**

- Create `crates/tellurion-core/src/items_budget.rs`
- Modify `crates/tellurion-core/src/error.rs`
- Modify `crates/tellurion-core/src/problem.rs`
- Modify `crates/tellurion-core/src/lib.rs`

1. Add failing unit tests for Point, MultiPoint, LineString,
   MultiLineString, Polygon, MultiPolygon, recursive GeometryCollection,
   null/absent/malformed geometry, exact-budget acceptance, first-crossing
   refusal, and saturating cumulative arithmetic.
2. Add a failing problem-mapping test for status `422`, code
   `ItemsVertexBudgetExceeded`, and detail text that says exact geometry was
   refused rather than simplified.
3. Implement a recursive GeoJSON coordinate counter with saturating `u64`
   arithmetic.
4. Add `Error::ItemsVertexBudgetExceeded` with collection id, feature id,
   cumulative vertices, and configured limit.
5. Implement page and single-item budget checks and the shared problem mapping.
6. Run the focused core tests and commit the passing contract slice.

## Task 3: Enforce the generic backstop and fallback semantics

**Files:**

- Modify `crates/tellurion-core/src/items_budget.rs`
- Modify `crates/tellurion-core/src/router.rs`
- Modify `crates/tellurion-core/src/observability.rs`

1. Add a failing decorator test proving an under-budget page is byte-identical,
   an over-budget page yields no partial result, and single-item lookups use the
   same budget.
2. Add a failing fallback test proving the deterministic budget error does not
   call a tail source.
3. Wrap each resolved features lane with one budget-enforcing source while
   preserving filtering, CQL2, and CRS capabilities and forwarding
   `item_with_crs`.
4. Stop fallback iteration when the primary returns the budget error.
5. Increment `items_vertex_budget_exceeded_total{backend="generic"}` and log
   the bounded diagnostic only when the generic backstop is the first
   enforcer.
6. Run the router and core budget tests and commit the passing backstop slice.

## Task 4: Add the PostGIS pre-encode fast path

**Files:**

- Modify `crates/tellurion-postgis/src/sql.rs`
- Modify `crates/tellurion-postgis/src/driver.rs`

1. Add failing SQL-shape tests for integer, UUID, and text ids; filters;
   keyset tokens; requested CRS; and a bounded `limit + 1` candidate CTE.
2. Pin that the running vertex total uses raw stored geometry, the look-ahead
   row is excluded from both budget and encode, and `ST_AsGeoJSON` is
   conditional on the requested row fitting the budget.
3. Add failing driver row-decoding tests for exact-budget acceptance and the
   first crossing row's id, cumulative count, and configured limit.
4. Extend the item-page plan with the budget parameter and build the bounded
   candidate, counted, and conditional-encode projections.
5. Extend the single-item plan to return vertex count and conditionally encode.
6. Decode the count metadata before feature JSON; return the core budget error
   without starting the count query or building a partial result.
7. Increment `items_vertex_budget_exceeded_total{backend="postgis"}` and log
   the bounded diagnostic on the early refusal.
8. Run all PostGIS tests and commit the passing fast-path slice.

## Task 5: Prove both HTTP surfaces and document the contract

**Files:**

- Modify `crates/tellurion-features/tests/handlers.rs`
- Modify the matching STAC handler test file under `crates/tellurion-stac/tests`
- Modify `crates/tellurion-server/openapi_features.json`
- Modify `crates/tellurion-server/openapi_stac.json`

1. Add failing Features tests for list and single-item `422` responses,
   including the named code and absence of a partial FeatureCollection.
2. Add matching failing STAC tests for collection items, search, and
   single-item lookup through the shared source contract.
3. Make only the minimal protocol fixture/config changes needed to exercise
   the core error mapping.
4. Add `422` response documentation to the affected list/search and
   single-item operations in both OpenAPI documents.
5. Run both protocol suites and JSON parsing checks; commit the passing API
   slice.

## Task 6: Verify, publish, and report without duplicating the launch article

1. Run formatting checks and strict clippy for the workspace.
2. Run affected crate tests, then `cargo test --workspace --locked`.
3. Review the complete diff for scope, accidental secrets/PII, AI-context
   paths, generated artifacts, and public-release suitability.
4. Push the branch and open a draft pull request linked to issue #148.
5. Add evidence to #148. Update #1 only with measured facts; do not claim a
   bounded `422` as a successful `200`.
6. Preserve the already-published launch article and scheduled follow-up
   rather than duplicating them. Publish a separate concise achievement update
   only if the merged or review-ready result adds a materially new public
   milestone.
