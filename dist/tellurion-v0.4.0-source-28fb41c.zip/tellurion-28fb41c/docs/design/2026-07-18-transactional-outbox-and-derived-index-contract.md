# Transactional outbox and derived-index contract

Status: the write lane (`WriteSink`/`OutboxSource`, `#25`), the derived-index
lane (`IndexSink`, the applier, `#67`), and freshness-gated search routing
(§4's `search: [index, main]`, also `#67`) are all wired against the PostGIS
driver, with their own tests. §10 items 4/5 record the calls this last piece
settled on: sequence-lag freshness units, and `FeatureSource` (never a new
capability requirement) as the fallback tail's degraded-primary read. This
settles the contract before Tellurion grows its write/index/search lanes, so
the three stay one coherent design instead of three local ones bolted on
later. Builds on the per-lane routing and capability model of #21/#18 — see
the driver-contract design doc, whose section 4 summarizes these rules as
constraints.

## 1. Why this is designed now, empty

Writing to an external, derived read index asynchronously is one of the
genuinely hard problems in a multi-driver catalog. The async fan-out is the
easy part; keeping the derived view honest is the nightmare — stale documents,
drain failures, a race between the primary write and the index apply, and
search silently answering from a lagging view. Every rule below is a lesson
from operating prior art at scale, restated as an invariant we adopt before
there is any code to retrofit.

The one non-negotiable that shapes everything else: **no dual writes.** The
serving path must never write the primary and the index in two separate
round-trips and hope both land. The moment a write path exists that can leave
the two stores disagreeing with no bounded recovery, we have lost. So we fix
the write shape first, while the write lane is still empty.

## 2. The invariants (the contract)

1. **The index is a derived view, never a second source of truth.** It is
   rebuildable from the primary at any time (§7). There is no repair path that
   *merges* two divergent states — divergence is resolved by re-deriving from
   the primary, full stop. A rebuild is the recovery story, not a backup.

2. **Transactional outbox, per collection.** The index obligation is committed
   in the *same* transaction as the primary data mutation, inside the
   source-of-truth storage. One transaction, two rows (the data row and the
   outbox row) — never two transactions. Per collection, not one global
   cross-tenant obligation table: local ordering, boring locks, no shared
   write hotspot.

3. **Consumers are at-least-once and idempotent.** The applier that drains the
   outbox into the index may see the same obligation more than once (crash
   between apply and cursor advance, a replayed gap, a retried batch).
   Applying an obligation twice must be a no-op. We get idempotency from
   *versioned* documents keyed by a dedup key, never blind upserts (§4).

4. **Idempotent, ordered apply.** Each mutation carries a monotonic per-
   collection sequence. The applier is a *single ordered consumer per
   collection*: it applies obligations in ascending sequence and never skips
   (skipping is silent divergence, and divergence has no repair but a
   rebuild). One process makes this trivial — one task per collection; across
   replicas an optional lease elects the one that drains (§9).

5. **Search routing is freshness-aware.** The search lane routes to the index
   driver only when the index's *applied high-water mark* is close enough to
   the primary's; otherwise it falls back to the primary. Staleness is an
   explicit, observable contract — metrics for outbox depth and apply lag —
   never a silent property of a lagging view.

6. **Reconcile by sequence comparison, not rescan.** Drift detection compares
   high-water marks and replays the gap. Never a scheduled full-table diff.

7. **Per-lane routing (#21) is the substrate.** `read`/`tiles`/`search`/
   `write`/`index` are lanes; a collection binds each lane to a driver via
   `RoutingDecl`; capability validation at config load rejects a lane pointing
   at a driver that lacks the lane's capability, exactly as `features`/`tiles`
   are validated today.

## 3. Mapping onto the existing routing and capability model

Nothing new in kind: the write/index/search capabilities are advertised the
same Option-shaped way `StorageDriver::feature_source()` and `tile_source()`
already are (`router.rs`), and resolved the same way through the `Router`. A
driver that does not implement a capability returns `None`; a lane that names
it is refused — at config load when the lane is explicitly routed
(`validate_lane_capability`), or at resolve time with
`Error::CapabilityUnsupported` otherwise.

### 3.1 New capability accessors on `StorageDriver`

Proposed additions, each defaulting to `None` so existing and fake drivers are
untouched (mirrors how `feature_source`/`tile_source` default today):

```rust
pub trait StorageDriver: Send + Sync {
    fn catalog_source(&self) -> Arc<dyn CatalogSource>;
    fn feature_source(&self) -> Option<Arc<dyn FeatureSource>> { None }
    fn tile_source(&self) -> Option<Arc<dyn TileSource>> { None }

    // --- proposed (#25), same "does this driver advertise it?" shape ---

    /// A storage that can accept writes AND commit the outbox obligation in
    /// the same transaction. Advertising this is the machine-checkable
    /// meaning of "supports the outbox invariant" (§2.2).
    fn write_sink(&self) -> Option<Arc<dyn WriteSink>> { None }

    /// The read side of that storage's outbox. A driver that advertises
    /// `write_sink` MUST also advertise this — the applier drains it.
    fn outbox_source(&self) -> Option<Arc<dyn OutboxSource>> { None }

    /// A derived index this driver can apply obligations into.
    fn index_sink(&self) -> Option<Arc<dyn IndexSink>> { None }

    /// Freshness-aware search reads over a derived index.
    fn search_source(&self) -> Option<Arc<dyn SearchSource>> { None }
}
```

`RoutingDecl` gains the reserved `write` / `index` / `search` lanes it already
documents as "reserved for when the write/index work lands":

```rust
pub struct RoutingDecl {
    pub features: Option<LaneRouting>,
    pub tiles:    Option<LaneRouting>,
    // proposed (#25):
    pub write:    Option<LaneRouting>, // exactly one driver, no fallback tail
    pub index:    Option<LaneRouting>, // the derived-view apply target(s)
    pub search:   Option<LaneRouting>, // freshness-gated, with a fallback tail
}
```

### 3.2 The trait surface

Everything is backend-neutral: no SQL, no engine names, no assumption the
outbox is a table (it is a *log* the driver owns however it likes). A
`Sequence` is a total order *within one collection*; no cross-collection
ordering is promised or needed.

```rust
/// A monotonic, per-collection commit order. Gaps are allowed (it is an
/// order, not a dense counter); what matters is that later commits compare
/// greater and the applier reads every obligation in ascending order.
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct Sequence(pub u64);

pub enum MutationKind {
    Upsert(serde_json::Value), // the item payload to derive from
    Delete,
}

pub struct Mutation {
    /// Stable item identity within the collection (the same id space the
    /// `FeatureSource` item lane already uses).
    pub feature_id: String,
    pub kind: MutationKind,
}

/// The write side. `apply` performs the data mutation AND appends the outbox
/// obligation in ONE backend transaction, returning the sequence it committed
/// at. There is deliberately no "write without outbox" method — the atomicity
/// is the capability.
#[async_trait]
pub trait WriteSink: Send + Sync {
    async fn apply(&self, collection: &CollectionDecl, mutation: Mutation)
        -> Result<Sequence>;
}

/// One committed change, as the applier reads it back out of the outbox.
pub struct Obligation {
    pub sequence: Sequence,
    pub feature_id: String,
    pub kind: MutationKind,
    /// Dedup/version stamp carried into the index so apply is idempotent:
    /// the index stores it per document and treats an obligation whose
    /// version is <= the stored one as a no-op. In the first slice this is
    /// simply the committing `sequence` (§4).
    pub version: Sequence,
}

/// The read side of a source-of-truth storage's outbox.
#[async_trait]
pub trait OutboxSource: Send + Sync {
    /// Obligations with sequence strictly greater than `after`, ascending, at
    /// most `limit`. MUST NOT skip or reorder. `Ok(vec![])` means "caught up".
    async fn read_after(&self, collection: &CollectionDecl, after: Sequence, limit: u32)
        -> Result<Vec<Obligation>>;

    /// Highest sequence committed to the source of truth — the primary
    /// high-water mark the freshness gate (§5) compares against.
    async fn primary_high_water(&self, collection: &CollectionDecl) -> Result<Sequence>;
}

/// A derived index. Never a source of truth; rebuildable (§7).
#[async_trait]
pub trait IndexSink: Send + Sync {
    /// Idempotently apply one obligation. MUST be a no-op when a document for
    /// `feature_id` at a version >= `obligation.version` was already applied.
    /// A Delete is likewise versioned (a tombstone at `version`), so an
    /// out-of-order or replayed Delete cannot resurrect or drop a newer write.
    async fn apply(&self, collection: &CollectionDecl, obligation: &Obligation) -> Result<()>;

    /// Highest primary sequence this index has durably applied — advanced
    /// only after `apply` is durable. The freshness gate reads this.
    async fn applied_high_water(&self, collection: &CollectionDecl) -> Result<Sequence>;
}

/// Freshness-aware search reads. The applied high-water mark travels with the
/// search capability so the search lane can decide, per request, whether the
/// index is fresh enough to answer.
#[async_trait]
pub trait SearchSource: Send + Sync {
    async fn search(&self, collection: &CollectionDecl, query: &SearchQuery)
        -> Result<SearchPage>;

    async fn applied_high_water(&self, collection: &CollectionDecl) -> Result<Sequence>;
}
```

### 3.3 The applier

A driver-agnostic loop in `tellurion-core`, one per (collection, index lane):
read `outbox_source().read_after(cursor, batch)`, apply each `Obligation`
through `index_sink().apply`, advance the cursor only after the batch is
durably applied. Because `apply` is idempotent, a crash between apply and
cursor-advance replays a few obligations harmlessly. The applier owns no
business logic — it is a pump between two advertised capabilities the `Router`
resolved.

## 4. Ordering, dedup, and the freshness gate

**Ordering** is per collection and total: the `Sequence` the `WriteSink`
stamps at commit. The applier consumes in that order; there is no global
order across collections and we never need one.

**Dedup key** is `(feature_id, version)`. Idempotency is a version compare,
not an upsert: `IndexSink::apply` writes the derived document only when the
incoming `version` exceeds the stored one. In the first slice `version` *is*
the committing `Sequence`, which is monotonic per `feature_id` because writes
to one item are serialized through the same outbox order. This makes a
double-delivered obligation, a replayed gap, and an out-of-order retry all
converge to the same state.

**Freshness gate.** The search lane is routed with a fallback tail, e.g.
`search: [index, main]` — reusing the existing `LaneRouting` fallback-tail
semantics with one added refusal trigger. Today the tail is consulted only
when the primary entry's driver *errors*; for search we add: it is also
consulted when the freshness gate refuses. Per request:

```
lag = primary.primary_high_water(c) - index.applied_high_water(c)
if lag <= freshness_bound(c):  serve from the index (search_source)
else:                          fall back to the tail (the primary, degraded)
```

`freshness_bound` is a per-collection config knob (sequence lag or wall-clock
lag — see open questions). The primary "degraded search" is whatever the
primary can honestly serve: attribute filtering via `FeatureSource` +
`filter_capable` (#33), or a `SearchSource` the primary also advertises. A
primary that can serve nothing useful for the query declares no such
capability, and the lane surfaces the staleness rather than faking freshness.

## 5. Observability is part of the contract

The gate above only works if lag is measurable, so these are contract
surface, not nice-to-haves, exported through the existing `/metrics`
Prometheus recorder (`tellurion-server::metrics`):

- **outbox depth** per collection: `primary_high_water - applied_high_water`.
- **apply lag** per collection: wall-clock age of the oldest un-applied
  obligation.
- **applier position / throughput** and **fallback rate** (share of search
  requests the freshness gate sent to the primary).

Staleness that no one can see is the failure mode we are designing out.

## 6. Failure modes and how the contract absorbs them

- **Consumer lag (applier falls behind).** Outbox depth grows; the freshness
  gate routes search to the primary; the metric alarms. Correctness holds —
  search is stale-aware, never stale-silent. Recovery is "the applier catches
  up," no intervention.

- **Poison obligation (one the index cannot apply).** The applier does *not*
  skip it — skipping is silent divergence. It halts the lane at that sequence,
  stops advancing `applied_high_water`, and surfaces it loudly (log + a stalled
  metric). Search stays correct because the freshness gate has already routed
  it to the primary. An operator fixes the mapping and the applier resumes from
  the stalled cursor. A stalled index is a *degradation*, not an outage or a
  corruption — that is the whole point of the gate.

- **Partial / interrupted rebuild.** A rebuild (§7) targets a fresh index
  *generation*; the live generation keeps serving until the rebuild's applied
  high-water catches the primary, then the search lane cuts over
  (blue/green). A crash mid-rebuild restarts from the last durable applied
  high-water; idempotency makes the re-apply safe. A half-built index is never
  in the search lane.

- **Lost/duplicated delivery.** At-least-once + versioned apply (§4) makes
  duplicates no-ops. Loss is impossible for committed obligations because they
  live in the source-of-truth transaction, not in a separate queue that could
  drop them before the primary commit.

## 7. Rebuild: what "rebuildable from the source of truth" actually means

The source of truth is the **primary's current data**, not the outbox log. Two
distinct operations, and it matters not to conflate them:

- **Incremental reconcile (#25 principle 5):** compare high-water marks,
  `read_after(applied_high_water, ...)`, replay the gap. Cheap, routine, needs
  only the *retained* tail of the outbox.

- **Full rebuild (the recovery story):** snapshot the primary's current rows
  (a `CatalogSource` + `FeatureSource` scan) into a fresh index generation,
  then tail the outbox from the snapshot boundary for writes that landed during
  the rebuild, then cut over. This does **not** require the outbox to be
  retained back to `Sequence(0)` — a design point that frees us to compact old
  outbox rows.

This is why the outbox is a *change log for incremental apply*, not the
exclusive rebuild source. Conflating the two would force infinite outbox
retention; separating them lets retention be a policy (open question).

### 7.1 The rebuild tool, in practice: harvest from self (`#191`)

The rebuild above needs no bespoke reindexer. `tellurion-ingest harvest stac`
walks a STAC API and re-applies every item through the canonical write lane
(`WriteSink::apply_batch`), and **this deployment's own STAC surface is a
valid source**. Pointing a harvest at the catalog it is rebuilding replays the
primary's current rows through the same path a live `PUT` takes, so the index
lane rebuilds against the *current* DDL and the *current* mapping without any
component learning a second way to write.

What makes that a rebuild rather than a duplication is idempotency: every
harvested item is a caller-supplied-id upsert, so re-running a page — after an
interrupt, after raising a cap, or on purpose — converges. The command keeps a
resume bookmark per collection, advanced only after a page has fully applied,
so an interrupted rebuild restarts at a page boundary rather than at the
beginning.

Scope, stated plainly: this covers the *snapshot* half of "full rebuild"
above. The "tail the outbox from the snapshot boundary, then cut over" half —
and with it the index-*generation*/blue-green cutover of §6 — is not part of
that slice, so a harvest-driven rebuild currently runs against the live
generation. Open question 1's "no such tool exists yet" is therefore only
half-answered: a rebuild path exists, an automated retention trigger built on
top of it still does not.

## 8. Minimal first implementation slice

Deliberately one process, one collection, no external search engine:

- **Primary = the existing PostGIS driver**, extended to advertise
  `WriteSink` + `OutboxSource`: an `outbox` table in the same schema, the
  data mutation and the outbox insert in one transaction, the sequence from a
  per-collection bigint sequence.
- **Index = a second `IndexSink`**, simplest honest choice a `tsvector`/GIN
  column (or a second PostGIS storage) — proves the contract with no new
  external dependency, consistent with the "external search is optional, never
  core" stance (#32).
- **Applier = one tokio task per collection**, the §3.3 pump. No lease in
  that first slice; a lease was added later, and is still optional — see
  §9's entry, now closed.
- **Search lane `search: [index, main]`** with the §4 freshness gate; the
  primary's degraded fallback is attribute filtering via `filter_capable`
  (#33).
- **Metrics** from §5 wired to `/metrics`.

Acceptance: a write goes through `WriteSink`; the index converges; killing the
applier mid-drain and restarting converges to the identical state; forcing lag
past `freshness_bound` demonstrably routes search to the primary and the
fallback metric moves.

## 9. Explicitly deferred, and why

- **Global / cross-tenant outbox** — deferred indefinitely. Per-collection
  keeps ordering local and locks boring; a global obligation table is a shared
  write hotspot we have no reason to take on.
- **Clustered applier lease** — ~~deferred until we run more than one
  process~~ **landed (#193)**, and it was indeed pure addition: the pump,
  the obligation contract, and the freshness gate are all unchanged.
  `core::lease::Lease` hands out a `LeaseGuard` whose *lifetime is the
  leadership*, `run_applier` takes an `Option<LeaseBinding>`, and the
  PostGIS driver implements it with `pg_try_advisory_lock` on a session it
  holds for as long as it leads — no lease table, no DDL, no heartbeat, no
  expiry, and therefore no cleanup path that can fail: a killed process
  releases by having its session end. Two properties made this cheap and
  are worth restating as invariants rather than implementation notes:

  - **Takeover is free** because this pump owns no cursor — `IndexSink::
    applied_high_water` IS the cursor (§3.3), so a promoted follower resumes
    from what the sink last durably landed, exactly as a restart does.
  - **The lease is not a fencing token.** It buys ordering stability and
    avoids duplicated work; it does not buy correctness, because
    idempotent versioned apply (§2, rule 3) already owns that. A brief
    two-leader overlap converges.

  Still optional, and off unless `server.index_applier.lease` is declared:
  the single-binary-plus-PostgreSQL deployment contacts no coordinator and
  behaves exactly as before.
- **External search-engine driver** (an inverted-index engine such as
  OpenSearch) — deferred. It arrives, if ever, as *another optional driver*
  advertising `SearchSource`/`IndexSink`, never as a boot requirement (#32).
- **Exactly-once delivery** — explicitly rejected as a goal. At-least-once +
  idempotent versioned apply is the contract; exactly-once is a more expensive
  way to buy what idempotency already gives us.
- **Multi-index fan-out** (one collection feeding several derived indexes at
  once) — the trait surface already allows N `index` lanes; the first slice
  wires one.
- **Outbox retention / compaction policy** — deferred to a decision (open
  questions), because §7 shows full rebuild does not depend on it.

## 10. Open questions for the maintainer — resolved for the `#67` slice

The derived-index half (`IndexSink`, the applier, the PostGIS index sink)
landed in `#67`; the answers below are the narrowest defensible call this
slice made for each question, not a promise that a later slice can't revisit
one.

1. **Outbox retention.** No automatic pruning in this slice — the outbox
   stays unbounded. §7's stance stands (a full rebuild only needs the tail
   from its own snapshot boundary forward, never full history back to
   `Sequence(0)`), so compaction below the minimum `applied_high_water`
   across index consumers is safe *whenever a rebuild tool exists to make
   that safe to automate* — but no such tool exists yet, so there is nothing
   to compact against. Leaving retention unbounded rather than guessing a
   window trades disk for zero data-loss risk; a real trigger/window is an
   operational decision for whoever builds the rebuild tool.
2. **Sequence source.** Confirmed, unchanged from the write lane: a
   per-collection Postgres `bigserial` — a commit-order guarantee from the
   backend is sufficient; no stricter logical clock is needed anywhere the
   applier or the index sink touch.
3. **Version semantics.** Confirmed, unchanged: `version` IS the committing
   `Sequence` in this slice, and `IndexSink::apply`'s dedup only ever
   compares within one collection's own outbox order — decoupling `version`
   from `Sequence` for independent per-item versioning (e.g. external
   writers) stays a reserved-but-unexercised future extension, not something
   this slice needed.
4. **Freshness bound units — implemented as recommended.** Sequence-lag, not
   wall-clock: both `OutboxSource::primary_high_water` and `SearchSource::
   applied_high_water` return `Sequence`, so a lag comparison needs no
   synchronized clock across driver instances and reuses a value both sides
   already expose. A wall-clock alternative would have needed `Obligation` to
   also carry a commit timestamp, which nothing here does. `Router::
   resolve_search` (`tellurion-core`) is the freshness gate itself; the
   per-collection bound is `CollectionDecl.search.freshness_bound`.
5. **Degraded-primary search contract — implemented as recommended.**
   `FeatureSource` is the sanctioned degraded path (the search lane's
   fallback tail), not a new `SearchSource` requirement on every primary —
   forcing every driver to implement a second search-shaped capability
   before search routing can exist at all would have gated the whole
   feature on every driver catching up. `Router::resolve_search` only ever
   asks the search lane's *primary* entry for `SearchSource`; every tail
   entry is a plain `FeatureSource` read, unconditionally.
