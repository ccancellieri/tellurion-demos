#!/usr/bin/env bash
# Proves a loose first-party dependency version cannot pass the license policy.

set -euo pipefail

# shellcheck source=scripts/rg-compat.sh
. "$(dirname "$0")/rg-compat.sh"
# shellcheck source=scripts/workspace-version.sh
. "$(dirname "$0")/workspace-version.sh"

version="$(workspace_version)" || exit 1

if ! rg -q 'cargo metadata --locked --no-deps --format-version 1' scripts/audit-license-policy.sh; then
    echo "FAIL: license policy metadata command is not locked" >&2
    exit 1
fi

manifest="Cargo.toml"
backup="$(mktemp)"
cp "$manifest" "$backup"
trap 'cp "$backup" "$manifest"; rm -f "$backup"' EXIT

# The mutation is built from the declared version, so this test keeps proving
# the same thing after a release bump instead of silently mutating nothing.
perl -0pi -e 's/(tellurion-core = \{ path = "crates\/tellurion-core", version = )"\Q'"$version"'\E"/${1}">='"$version"'"/' "$manifest"

if ! grep -Fq "version = \">=$version\"" "$manifest"; then
    echo "FAIL: the loose-version mutation did not apply to $manifest" >&2
    exit 1
fi

if bash scripts/audit-license-policy.sh >/dev/null 2>&1; then
    echo "FAIL: loose first-party dependency version was accepted" >&2
    exit 1
fi

echo "license policy rejects a loose first-party dependency version"
