#!/usr/bin/env bash
# Mutation tests for the workflow contract. Each fixture represents a release
# boundary regression that must be rejected before CI can accept the workflow.
#
# Two families live here. The `*-publication` family proves the guard still
# refuses any way to publish an asset, image, crate, tag or GitHub Release --
# that prohibition is the point of the contract and predates the versioning
# mechanism. The version family proves the guard enforces the *invariant* that
# archive identities derive from `[workspace.package] version`, now that it no
# longer pins one frozen literal.

set -euo pipefail

fixture_root="$(mktemp -d)"
trap 'rm -rf "$fixture_root"' EXIT

failures=0

expect_rejected() {
    local name="$1"
    local fixture="$fixture_root/$name"
    mkdir -p "$fixture"
    cp -R .github/workflows "$fixture/workflows"

    case "$name" in
        windows-shell)
            perl -0pi -e 's#(- name: Build default-feature binaries\n)#$1        shell: pwsh\n        run: |\n          target=windows-target\n#' "$fixture/workflows/release-artifacts.yml"
            ;;
        smoke-directory)
            perl -0pi -e 's#\n          New-Item -ItemType Directory -Force -Path \$smoke_dir \| Out-Null##' "$fixture/workflows/release-artifacts.yml"
            ;;
        unsafe-ref-name)
            printf '%s\n' '      - name: unsafe-${{ github.ref_name }}' >> "$fixture/workflows/release-artifacts.yml"
            ;;
        # A ref name may contain `/`. Naming an identity `version=` used to be
        # enough to slip past the guard's exclusion; it must not be.
        ref-name-as-version)
            perl -0pi -e 's#\$package_name = "tellurion-v\$version-\$target"#$package_name = "tellurion-version=$env:GITHUB_REF_NAME-$target"#' "$fixture/workflows/release-artifacts.yml"
            ;;
        release-api)
            printf '\n      - run: gh api repos/example/project/releases\n' >> "$fixture/workflows/ci.yml"
            ;;
        gh-release-publication)
            printf '\n      - run: gh release create v9.9.9 dist/tellurion.tar.gz\n' >> "$fixture/workflows/ci.yml"
            ;;
        gh-release-action-publication)
            printf '\n      - uses: softprops/action-gh-release@v2\n' >> "$fixture/workflows/ci.yml"
            ;;
        contents-write-publication)
            printf '\npermissions:\n  contents: write\n' >> "$fixture/workflows/release-artifacts.yml"
            ;;
        cargo-publish-publication)
            printf '\n      - run: cargo +1.97.1 publish -p tellurion-core\n' >> "$fixture/workflows/release-artifacts.yml"
            ;;
        image-push)
            printf '\n      - run: podman push registry.example/tellurion\n' >> "$fixture/workflows/ci.yml"
            ;;
        git-push)
            printf '\n      - run: git push origin v0.3.0\n' >> "$fixture/workflows/ci.yml"
            ;;
        unknown-action)
            printf '\n      - uses: example/release-action@v1\n' >> "$fixture/workflows/ci.yml"
            ;;
        unqualified-cargo)
            printf '\n      - run: cargo build --release\n' >> "$fixture/workflows/release-artifacts.yml"
            ;;
        unqualified-rustc)
            printf '\n      - run: rustc --version --verbose\n' >> "$fixture/workflows/release-artifacts.yml"
            ;;
        missing-license-audit-ci)
            perl -0pi -e 's#\n          \./scripts/audit-license-policy\.sh##' "$fixture/workflows/ci.yml"
            ;;
        missing-license-audit-release)
            perl -0pi -e 's#run: \./scripts/audit-license-policy\.sh#run: true#' "$fixture/workflows/release-artifacts.yml"
            ;;
        missing-license-docs)
            perl -0pi -e 's#^.*Copy-Item docs/licensing\.md.*\n##m' "$fixture/workflows/release-artifacts.yml"
            ;;
        wrong-archive-name)
            perl -0pi -e 's#tellurion-v\$version-\$target#tellurion-$build_id-$target#' "$fixture/workflows/release-artifacts.yml"
            ;;
        # The invariant that replaced the old literal pin: an archive name may
        # not carry a version of its own, because that version could drift from
        # the one the workspace declares.
        hardcoded-archive-version)
            perl -0pi -e 's#\$package_name = "tellurion-v\$version-\$target"#$package_name = "tellurion-v0.3.0-$target"#' "$fixture/workflows/release-artifacts.yml"
            ;;
        hardcoded-artifact-version)
            perl -0pi -e 's#name: tellurion-v\$\{\{ steps\.version\.outputs\.version \}\}-#name: tellurion-v0.3.0-#' "$fixture/workflows/release-artifacts.yml"
            ;;
        missing-version-resolver)
            perl -0pi -e 's#\n      - name: Resolve workspace version\n.*?(?=\n      - uses:)##s' "$fixture/workflows/release-artifacts.yml"
            ;;
        # Reading *a* version is not enough; it has to be the workspace one.
        unanchored-version-resolver)
            perl -0pi -e 's#\^\\\[workspace\\\.package\\\]#^\\[package\\]#' "$fixture/workflows/release-artifacts.yml"
            ;;
        # The resolver must reject anything that is not MAJOR.MINOR.PATCH, or a
        # version containing `/` could reach a path again.
        unconstrained-version-resolver)
            perl -0pi -e 's#\(\\d\+\\\.\\d\+\\\.\\d\+\)#(.+)#' "$fixture/workflows/release-artifacts.yml"
            ;;
        missing-policy-gate)
            perl -0pi -e 's#\n    needs: \[policy-audit\]##' "$fixture/workflows/release-artifacts.yml"
            ;;
        policy-audit-not-bash)
            perl -0pi -e 's#shell: bash#shell: pwsh#' "$fixture/workflows/release-artifacts.yml"
            ;;
        broad-release-tag)
            perl -0pi -e 's#tags: \["v\[0-9\]\+\.\[0-9\]\+\.\[0-9\]\+"\]#tags: ["v*"]#' "$fixture/workflows/release-artifacts.yml"
            ;;
        # Still a pattern, but pointed at a different tag namespace: the
        # release script's `vMAJOR.MINOR.PATCH` tag would never fire it.
        unmatchable-release-tag)
            perl -0pi -e 's#tags: \["v\[0-9\]\+\.\[0-9\]\+\.\[0-9\]\+"\]#tags: ["release-[0-9]+.[0-9]+.[0-9]+"]#' "$fixture/workflows/release-artifacts.yml"
            ;;
        manual-dispatch-blocked)
            perl -0pi -e "s#(policy-audit:\\n    name: license policy audit\\n)#\$1    if: github.ref == 'refs/tags/v0.3.0'\\n#; s#(native-artifacts:\\n    name: \\\$\\{\\{ matrix.target \\\}}\\n)#\$1    if: github.ref == 'refs/tags/v0.3.0'\\n#" "$fixture/workflows/release-artifacts.yml"
            ;;
        *)
            echo "unknown mutation: $name" >&2
            exit 2
            ;;
    esac

    # A substitution that silently matched nothing would make its case vacuous:
    # the guard would "reject" a workflow it had never been asked to judge.
    if diff -r -q .github/workflows "$fixture/workflows" >/dev/null 2>&1; then
        echo "FAIL: $name mutation left the workflows unchanged" >&2
        failures=$((failures + 1))
        return
    fi

    if WORKFLOW_DIR="$fixture/workflows" bash scripts/check-release-workflow.sh >/dev/null 2>&1; then
        echo "FAIL: $name mutation was accepted" >&2
        failures=$((failures + 1))
    else
        echo "ok: $name mutation rejected"
    fi
}

for mutation in windows-shell smoke-directory unsafe-ref-name ref-name-as-version \
    release-api gh-release-publication gh-release-action-publication \
    contents-write-publication cargo-publish-publication image-push git-push \
    unknown-action unqualified-cargo unqualified-rustc missing-license-audit-ci \
    missing-license-audit-release missing-license-docs wrong-archive-name \
    hardcoded-archive-version hardcoded-artifact-version missing-version-resolver \
    unanchored-version-resolver unconstrained-version-resolver missing-policy-gate \
    policy-audit-not-bash broad-release-tag unmatchable-release-tag \
    manual-dispatch-blocked; do
    expect_rejected "$mutation"
done

# The install guide is the derived mention outside the workflows that the guard
# checks, and it is what the archive-name literal used to be pinned against.
# Prove a guide that disagrees with the workspace version is still refused.
expect_guide_rejected() {
    local name="$1"
    local sed_script="$2"
    local guide="$fixture_root/$name.md"

    sed "$sed_script" docs/quickstart/install.md >"$guide"
    if cmp -s docs/quickstart/install.md "$guide"; then
        echo "FAIL: $name mutation left the install guide unchanged" >&2
        failures=$((failures + 1))
        return
    fi

    if INSTALL_GUIDE="$guide" bash scripts/check-release-workflow.sh >/dev/null 2>&1; then
        echo "FAIL: $name mutation was accepted" >&2
        failures=$((failures + 1))
    else
        echo "ok: $name mutation rejected"
    fi
}

expect_guide_rejected stale-install-guide \
    's/tellurion-v[0-9.]*-aarch64/tellurion-v9.9.9-aarch64/'
expect_guide_rejected undocumented-target \
    '/x86_64-pc-windows-msvc/d'

# The unmutated workflows must still pass, or every "rejected" above could be
# an artefact of the guard failing for an unrelated reason.
if ! bash scripts/check-release-workflow.sh >/dev/null; then
    echo "FAIL: the repository's own workflows do not satisfy the contract" >&2
    failures=$((failures + 1))
else
    echo "ok: unmutated workflows accepted"
fi

if [ "$failures" -ne 0 ]; then
    exit 1
fi

echo "release workflow mutation tests passed"
