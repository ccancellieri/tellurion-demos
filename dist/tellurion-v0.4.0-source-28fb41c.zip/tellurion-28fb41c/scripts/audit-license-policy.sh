#!/usr/bin/env bash
# Verifies the repository-wide license, publication, and first-party version
# policy for the BUSL 1.1 release line.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR/.."

# shellcheck source=scripts/workspace-version.sh
. "$SCRIPT_DIR/workspace-version.sh"

fail=0

# Everything below compares against the one declared version instead of a
# literal, so a `scripts/release.sh` bump moves the policy with the release
# rather than turning every audit red.
version="$(workspace_version)" || exit 1

for tool in cargo jq; do
    command -v "$tool" >/dev/null 2>&1 || {
        echo "ERROR: required tool '$tool' not found on PATH" >&2
        exit 1
    }
done

check_workspace_package_value() {
    local expected="$1"

    awk -v expected="$expected" '
        $0 == "[workspace.package]" { in_workspace_package = 1; next }
        in_workspace_package && /^\[/ { exit }
        in_workspace_package && $0 == expected { found = 1 }
        END { exit(found ? 0 : 1) }
    ' Cargo.toml
}

require_workspace_package_value() {
    local expected="$1"

    if ! check_workspace_package_value "$expected"; then
        echo "FAIL workspace.package: missing $expected"
        fail=1
    fi
}

require_workspace_package_value "version = \"$version\""
require_workspace_package_value 'license = "BUSL-1.1"'
require_workspace_package_value 'publish = false'

metadata="$(cargo metadata --locked --no-deps --format-version 1)"

while IFS=$'\t' read -r name manifest resolved_version license publish; do
    if [ "$resolved_version" != "$version" ]; then
        echo "FAIL $name: resolved version is $resolved_version, expected $version"
        fail=1
    fi

    if [ "$license" != 'BUSL-1.1' ]; then
        echo "FAIL $name: resolved license is $license, expected BUSL-1.1"
        fail=1
    fi

    if [ "$publish" != 'true' ]; then
        echo "FAIL $name: resolved publish setting is not false"
        fail=1
    fi

    if ! grep -qx 'publish\.workspace = true' "$manifest"; then
        echo "FAIL $manifest: missing publish.workspace = true"
        fail=1
    fi
done < <(printf '%s\n' "$metadata" | jq -r '
    .workspace_members as $members
    | .packages[]
    | select(.id as $id | $members | index($id))
    | [.name, .manifest_path, .version, .license, (.publish == [])]
    | @tsv
')

while IFS=$'\t' read -r name manifest; do
    package_dir="$(dirname "$manifest")"

    if [ "$name" = 'tellurion-duckdb' ]; then
        if ! grep -qx 'license-file = "../../LICENSE"' "$manifest"; then
            echo "FAIL $manifest: missing license-file = \"../../LICENSE\""
            fail=1
        fi
        continue
    fi

    license_copy="$package_dir/LICENSE"
    if [ ! -f "$license_copy" ]; then
        echo "FAIL $manifest: missing crate-local LICENSE"
        fail=1
    elif ! cmp -s LICENSE "$license_copy"; then
        echo "FAIL $license_copy: does not match LICENSE"
        fail=1
    fi
done < <(printf '%s\n' "$metadata" | jq -r '
    .workspace_members as $members
    | .packages[]
    | select(.id as $id | $members | index($id))
    | [.name, .manifest_path]
    | @tsv
')

while IFS= read -r -d '' license_copy; do
    if [ "$license_copy" = './LICENSE' ]; then
        continue
    fi

    if ! cmp -s LICENSE "$license_copy"; then
        echo "FAIL $license_copy: does not match LICENSE"
        fail=1
    fi
# `ui/node_modules` is pruned alongside `.git` and `target` for the same
# reason those two are: it is a build artifact, gitignored (`ui/.gitignore`),
# and never present in the CI job that runs this script (`ci.yml`'s
# `artifact audit` does a fresh checkout and no `npm ci`). It IS present
# locally, because `scripts/ci-local.sh`'s own `ui` feature-matrix leg runs
# `npm ci` before this phase — so without this prune, a full local mirror run
# always ended red on a few dozen third-party npm LICENSE files that are
# supposed to differ from this project's own. The sweep's subject is
# first-party and vendored LICENSE copies inside the repository, never a
# dependency's own license text.
done < <(find . -path ./.git -prune -o -path ./target -prune -o \
    -path ./ui/node_modules -prune -o -type f -name LICENSE -print0)

first_party_names="$(printf '%s\n' "$metadata" | jq -r '
    .workspace_members as $members
    | .packages[]
    | select(.id as $id | $members | index($id))
    | .name
')"

# Workspace membership, not a hand-maintained name list, defines which
# dependency declarations are first-party. Consumers using `workspace = true`
# inherit these exact root declarations.
while IFS= read -r first_party_name; do
    declaration="$(awk -v name="$first_party_name" '
        $0 == "[workspace.dependencies]" { in_workspace_dependencies = 1; next }
        in_workspace_dependencies && /^\[/ { exit }
        in_workspace_dependencies && $0 ~ "^" name "[[:space:]]*=" { print; exit }
    ' Cargo.toml)"

    [ -n "$declaration" ] || continue
    if ! printf '%s\n' "$declaration" | grep -Fq "version = \"$version\""; then
        echo "FAIL first-party dependency $first_party_name: expected version = \"$version\", found: $declaration"
        fail=1
    fi
done <<< "$first_party_names"

require_document_text() {
    local document="$1"
    local expected="$2"

    if ! grep -Fq -- "$expected" "$document"; then
        echo "FAIL $document: missing required licensing text: $expected"
        fail=1
    fi
}

forbidden_document_text() {
    local document="$1"
    local forbidden="$2"

    if grep -Fq -- "$forbidden" "$document"; then
        echo "FAIL $document: contains obsolete licensing text: $forbidden"
        fail=1
    fi
}

require_document_text README.md 'BUSL-1.1'
require_document_text README.md 'source-available'
require_document_text README.md '2030-08-09'
require_document_text README.md 'Personal, non-commercial production use'
require_document_text README.md 'Commercial licence required'
require_document_text README.md 'copy, modify, create derivative works, and redistribute'
forbidden_document_text README.md 'The Community source in this repository'

require_document_text COMMERCIAL-LICENSE.md 'Business Source License 1.1'
require_document_text COMMERCIAL-LICENSE.md 'production use by or for a business, government, or other organisation'
require_document_text COMMERCIAL-LICENSE.md 'https://github.com/ccancellieri'
forbidden_document_text COMMERCIAL-LICENSE.md 'No payment is required'

require_document_text CLA.md 'BUSL-1.1'
require_document_text CLA.md 'commercial terms'
require_document_text docs/licensing.md '2030-08-09'
require_document_text docs/licensing.md 'AGPL-3.0-only'
require_document_text docs/licensing.md 'legal approval'
require_document_text docs/quickstart/install.md 'aarch64-apple-darwin'
require_document_text docs/quickstart/install.md 'x86_64-unknown-linux-musl'
require_document_text docs/quickstart/install.md 'x86_64-pc-windows-msvc'
require_document_text docs/quickstart/install.md "approved v$version public release"
require_document_text docs/design/2026-07-17-tellurion-v01-design.md 'Superseded for current licensing and distribution policy'
require_document_text docs/design/2026-07-19-distribution-editions.md 'Superseded for current licensing and distribution policy'

if [ "$fail" -ne 0 ]; then
    echo "license policy audit FAILED"
    exit 1
fi

echo "license policy audit passed"
