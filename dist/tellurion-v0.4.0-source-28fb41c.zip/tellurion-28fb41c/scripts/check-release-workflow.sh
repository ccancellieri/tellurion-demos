#!/usr/bin/env bash
# Enforces the private native-artifact workflow contract and rejects public
# publication capability anywhere in the repository's GitHub workflows.

set -euo pipefail

# shellcheck source=scripts/rg-compat.sh
. "$(dirname "$0")/rg-compat.sh"
# shellcheck source=scripts/workspace-version.sh
. "$(dirname "$0")/workspace-version.sh"

workflow_dir="${WORKFLOW_DIR:-.github/workflows}"
workflow="$workflow_dir/release-artifacts.yml"
ci_workflow="$workflow_dir/ci.yml"

fail() {
    echo "FAIL: $*" >&2
    exit 1
}

require_match() {
    local pattern="$1"
    local file="$2"
    rg -q -- "$pattern" "$file" || fail "missing required workflow behavior: $pattern"
}

step_block() {
    local step_name="$1"
    awk -v step_name="$step_name" '
        $0 ~ "^[[:space:]]*-[[:space:]]+name: " step_name "$" { capture = 1 }
        capture && $0 ~ "^[[:space:]]*-[[:space:]]+(name:|uses:)" && $0 !~ "name: " step_name "$" { exit }
        capture { print }
    ' "$workflow"
}

job_block() {
    local job_name="$1"
    awk -v job_name="$job_name" '
        $0 ~ "^  " job_name ":$" { capture = 1 }
        capture && $0 ~ "^  [[:alnum:]_-]+:$" && $0 !~ "^  " job_name ":$" { exit }
        capture { print }
    ' "$workflow"
}

[ -d "$workflow_dir" ] || fail "missing workflow directory: $workflow_dir"
[ -f "$workflow" ] || fail "missing $workflow"
[ -f "$ci_workflow" ] || fail "missing $ci_workflow"

require_match 'channel[[:space:]]*=[[:space:]]*"1\.97\.1"' rust-toolchain.toml

# The release trigger is a semver tag pattern, not a frozen version. The exact
# pattern is pinned, so `v*`, `v0.3.*`, `v1.[0-9]+.[0-9]+` or any other
# loosening or narrowing is still rejected -- but the pattern now admits every
# version this repository can ever declare, instead of exactly one.
#
# In GitHub's filter syntax `[0-9]+` is one-or-more digits and `.` is literal,
# so the pinned pattern transcribes to the ERE `^v[0-9]+\.[0-9]+\.[0-9]+$`.
# `workspace_version` refuses anything that is not MAJOR.MINOR.PATCH, which is
# what makes "the tag the release script cuts always fires this workflow" an
# invariant rather than a coincidence -- and what makes the derived archive
# names below filesystem-safe.
require_match 'tags:[[:space:]]*\["v\[0-9\]\+\.\[0-9\]\+\.\[0-9\]\+"\]' "$workflow"
version="$(workspace_version)" || fail "workspace version is unusable as a release tag"

for matrix_entry in \
    'target: aarch64-apple-darwin[[:space:]]*$' \
    'runner: macos-14[[:space:]]*$' \
    'target: x86_64-unknown-linux-musl[[:space:]]*$' \
    'runner: ubuntu-24.04[[:space:]]*$' \
    'target: x86_64-pc-windows-msvc[[:space:]]*$' \
    'runner: windows-2022[[:space:]]*$'; do
    require_match "$matrix_entry" "$workflow"
done

require_match 'dtolnay/rust-toolchain@1\.97\.1' "$workflow"
require_match 'targets:[[:space:]]*\$\{\{ matrix\.target \}\}' "$workflow"
require_match 'workflow_dispatch:' "$workflow"
require_match 'legal_approval:' "$workflow"
require_match 'required:[[:space:]]*true' "$workflow"
require_match 'type:[[:space:]]*boolean' "$workflow"
require_match 'default:[[:space:]]*false' "$workflow"

policy_job="$(job_block 'policy-audit')"
printf '%s\n' "$policy_job" | rg -q 'runs-on:[[:space:]]*ubuntu-24\.04' \
    || fail "license policy audit must run on Ubuntu"
if printf '%s\n' "$policy_job" | sed -n '1,5p' | rg -q '^[[:space:]]+if:'; then
    fail "license policy audit must be executable for workflow_dispatch"
fi
printf '%s\n' "$policy_job" | rg -q 'shell:[[:space:]]*bash' \
    || fail "license policy audit must run under Bash"
printf '%s\n' "$policy_job" | rg -q 'scripts/audit-license-policy\.sh' \
    || fail "license policy audit job must invoke the policy script"

native_job="$(job_block 'native-artifacts')"
printf '%s\n' "$native_job" | rg -q 'needs:[[:space:]]*\[policy-audit\]' \
    || fail "native matrix must depend on the license policy audit"
if printf '%s\n' "$native_job" | sed -n '1,6p' | rg -q '^[[:space:]]+if:'; then
    fail "native matrix must be executable for workflow_dispatch"
fi

build_step="$(step_block 'Build default-feature binaries')"
printf '%s\n' "$build_step" | rg -q \
    'cargo \+1\.97\.1 build.*--release.*--locked.*--target[[:space:]]+\$\{\{ matrix\.target \}\}.*-p[[:space:]]+tellurion.*-p[[:space:]]+tellurion-ingest' \
    || fail "native build must invoke locked Cargo directly for both binaries"
if printf '%s\n' "$build_step" | rg -q '(^|[[:space:]])target='; then
    fail "native build uses shell-specific target assignment"
fi

if rg -n '\b(cargo|rustc)[[:space:]]+' "$workflow" | rg -v '\b(cargo|rustc)[[:space:]]+\+1\.97\.1\b' >/dev/null; then
    fail "release workflow uses an unqualified cargo or rustc command"
fi
require_match 'rustc \+1\.97\.1 --version --verbose' "$workflow"
require_match 'scripts/audit-license-policy\.sh' "$ci_workflow"

package_step="$(step_block 'Package and checksum artifacts')"
for package_requirement in \
    'GITHUB_SHA\.Substring' \
    'Copy-Item LICENSE, README\.md' \
    'Copy-Item COMMERCIAL-LICENSE\.md' \
    'example-geopackage\.yaml' \
    'Copy-Item docs/licensing\.md' \
    'Join-Path \$package_dir "docs"' \
    'BUILD-INFO' \
    'git archive --format=zip' \
    'Get-FileHash -Algorithm SHA256' \
    'Compress-Archive' \
    'tar -C dist -czf'; do
    printf '%s\n' "$package_step" | rg -q -- "$package_requirement" \
        || fail "release package is missing $package_requirement"
done
printf '%s\n' "$package_step" | rg -q '\$package_name = "tellurion-v\$version-\$target"' \
    || fail "platform archive name must be derived from the workspace version"

# The archive name and the workspace version cannot disagree, because the
# workflow reads the version out of the workspace manifest rather than
# repeating it. Pin that derivation: the resolver step must anchor on
# `[workspace.package]` and accept only MAJOR.MINOR.PATCH, and no naming
# expression anywhere in the workflow may hard-code a version literal that
# could then drift from Cargo.toml.
version_step="$(step_block 'Resolve workspace version')"
for version_requirement in \
    'id: version' \
    'Get-Content -Raw -Path Cargo\.toml' \
    '\^\\\[workspace\\\.package\\\]' \
    '\(\\d\+\\\.\\d\+\\\.\\d\+\)' \
    'throw ' \
    '"version=\$version" \| Out-File -FilePath \$env:GITHUB_OUTPUT'; do
    printf '%s\n' "$version_step" | rg -q -- "$version_requirement" \
        || fail "workspace version resolver is missing $version_requirement"
done
if rg -n 'tellurion-v[0-9]' "$workflow"; then
    fail "workflow hard-codes a release version instead of deriving it from Cargo.toml"
fi

# The archive name still has to match the installation guide -- the property
# the old literal pin was really protecting. Now that the workflow computes the
# name, check the guide against the same workspace version the workflow will
# resolve, for every target the matrix actually builds.
install_guide="${INSTALL_GUIDE:-docs/quickstart/install.md}"
[ -f "$install_guide" ] || fail "missing $install_guide"
while IFS= read -r matrix_target; do
    rg -q -- "tellurion-v$version-$matrix_target" "$install_guide" \
        || fail "$install_guide does not document tellurion-v$version-$matrix_target"
done < <(
    rg --no-filename '^[[:space:]]*- target:[[:space:]]' "$workflow" \
        | sed -E 's/^[[:space:]]*- target:[[:space:]]*//'
)

# A ref name can include `/`; it belongs only in BUILD-INFO, never in a path
# or artifact name. Archive identities derive from the workspace version, the
# SHA and the target instead. Only the one BUILD-INFO `ref=` line may name it
# -- pinning that exact line, rather than any line containing `version=`,
# closes the gap where a version-shaped expression could smuggle the ref back
# into an identity.
unsafe_ref_use="$(rg -n 'GITHUB_REF_NAME|github\.ref_name' "$workflow" \
    | rg -v '^[0-9]+:[[:space:]]*"ref=\$env:GITHUB_REF_NAME"$' || true)"
if [ -n "$unsafe_ref_use" ]; then
    echo "$unsafe_ref_use" >&2
    fail "workflow uses a raw ref name outside the BUILD-INFO ref= line"
fi

smoke_step="$(step_block 'Smoke test packaged demo')"
for smoke_requirement in \
    'New-Item -ItemType Directory -Force -Path \$smoke_dir' \
    'tar -xzf.*-C \$smoke_dir' \
    'Start-Process -FilePath \$ingest' \
    '/healthz' \
    '/public/features/catalogs/default/collections/demo/items\?limit=1'; do
    printf '%s\n' "$smoke_step" | rg -q -- "$smoke_requirement" \
        || fail "packaged-demo smoke test is missing $smoke_requirement"
done
mkdir_line="$(printf '%s\n' "$smoke_step" | nl -ba | rg 'New-Item -ItemType Directory -Force -Path \$smoke_dir' | awk '{ print $1 }')"
extract_line="$(printf '%s\n' "$smoke_step" | nl -ba | rg 'tar -xzf.*-C \$smoke_dir' | awk '{ print $1 }')"
if [ -z "$mkdir_line" ] || [ -z "$extract_line" ] || [ "$mkdir_line" -ge "$extract_line" ]; then
    fail "smoke directory must be created before tar extraction"
fi

upload_step="$(step_block 'Upload private workflow artifacts')"
printf '%s\n' "$upload_step" | rg -q 'actions/upload-artifact@v4' \
    || fail "release workflow must upload only private workflow artifacts"
printf '%s\n' "$upload_step" | rg -q 'github\.sha' \
    || fail "artifact name must use a filesystem-safe SHA identifier"
if printf '%s\n' "$upload_step" | rg -q 'github\.ref_name'; then
    fail "artifact name uses an unsafe raw ref name"
fi
printf '%s\n' "$upload_step" | rg -q 'name: tellurion-v\$\{\{ steps\.version\.outputs\.version \}\}-' \
    || fail "artifact name must carry the resolved workspace version"

workflows=()
while IFS= read -r workflow_file; do
    workflows+=("$workflow_file")
done < <(find "$workflow_dir" -type f \( -name '*.yml' -o -name '*.yaml' \) -print | sort)
[ "${#workflows[@]}" -gt 0 ] || fail "no workflow files found"

# No workflow may gain permissions or commands that can publish an asset,
# container, crate, tag, or GitHub Release. Keep this list explicit so new
# publication mechanisms must be consciously reviewed before they can land.
publication_patterns=(
    '(contents|packages|id-token)[[:space:]]*:[[:space:]]*write\b'
    'permissions:[[:space:]]*write-all\b'
    'actions/create-release'
    'softprops/action-gh-release'
    'ncipollo/release-action'
    'gh[[:space:]]+release\b'
    'gh[[:space:]]+api.*(/releases\b|releases\b)'
    'github\.rest\.repos\.(createRelease|uploadReleaseAsset)'
    'curl[^\n]*(api\.github\.com|uploads\.github\.com)[^\n]*(/releases\b|releases\b)'
    # Every cargo invocation in this repository is toolchain-qualified
    # (`cargo +1.97.1 ...`), which the old bare `cargo publish` pattern did not
    # see. The qualifier is optional here so both forms are refused.
    'cargo[[:space:]]+(\+[^[:space:]]+[[:space:]]+)?publish\b'
    '(docker|podman|oras)[[:space:]].*\bpush\b'
    'docker/(login|build-push)-action'
    'git[[:space:]]+push\b'
)
for pattern in "${publication_patterns[@]}"; do
    if rg -n -i -- "$pattern" "${workflows[@]}"; then
        fail "release-publication capability found in workflow files"
    fi
done

# Only the project-approved, major-version-pinned actions may run. This also
# blocks unknown third-party release actions before their names are added to a
# pattern above.
while IFS= read -r action; do
    case "$action" in
        actions/checkout@v4|actions/upload-artifact@v4|dtolnay/rust-toolchain@1.97.1|Swatinem/rust-cache@v2)
            ;;
        *)
            fail "unapproved workflow action: $action"
            ;;
    esac
done < <(
    rg --no-filename '^[[:space:]]*(-[[:space:]]*)?uses:[[:space:]]*' "${workflows[@]}" \
        | sed -E 's/^[[:space:]]*(-[[:space:]]*)?uses:[[:space:]]*([^[:space:]#]+).*$/\2/'
)

echo "release workflow contract passed for v$version"
