# Comparing against the Python reference stack

Tellurion's benchmark claim is only meaningful relative to the Python (FastAPI +
asyncpg) reference stack it's meant to outperform, run on identical data and
hardware. This document covers how to run that comparison; it does not itself
contain scenario/metric definitions — those are in `../README.md`.

## Like-for-like requirements

Run the exact same `../scenarios.sh` protocol against both stacks, changing only
`BASE_URL` (and, if the reference stack uses a different collection id, `COLLECTION`):

- **Same PostgreSQL/PostGIS instance and dataset** for both stacks in a given
  comparison run — swap which server sits in front of it, not the data underneath.
  If that's not possible, use two instances provisioned identically (same PG
  version, same storage, same `shared_buffers`/`work_mem`, same seeded dataset,
  same indexes) and say so in the write-up.
- **Same hardware class** for both server processes — same CPU/RAM allocation, same
  proximity to the database (not "tellurion on the DB host, Python stack over a
  network hop").
- **Same `SEED`, `ZMAX`, `DURATION`, `CONCURRENCY`, `REPS`, `WARMUP`** across both
  runs, so the tile walk and repetition counts line up.
- Record both stacks' `/metrics` RSS the same way; if the reference stack exposes
  process memory differently, note the metric name substitution in the write-up
  rather than silently comparing different things.

## Environments

- **On-prem / local, both stacks colocated:** the primary comparison. Run
  `../scenarios.sh` against tellurion, then again with `BASE_URL` pointed at the
  Python stack, same `DURATION`/`CONCURRENCY` as any other local run. No concurrency
  ceiling beyond what the hardware can sustain — this is the number that goes in the
  benchmark write-up.
- **Shared or remote DEV environments:** these are shared infrastructure, not a
  private benchmark rig. **Only ever run low-concurrency probes here — `CONCURRENCY
  <= 20`, and prefer the low end of that.** Never run a stress/capacity scenario
  (high concurrency, long duration, full z0-14 sweep at full `WALK_COUNT`) against a
  shared DEV target: it competes with whatever else is using that environment and
  can produce misleading numbers (noisy-neighbor contention) even if it doesn't
  cause an outage. A low-concurrency probe against DEV is for sanity-checking that
  the protocol and URL shapes are correct against a real deployment, not for
  headline numbers.

  ```sh
  # DEV sanity probe only -- not a comparison number
  BASE_URL=https://<dev-host> COLLECTION=demo CONCURRENCY=10 DURATION=5s \
      ZMAX=5 REPS=1 WARMUP=0 ../scenarios.sh
  ```

## Reporting

Run `../summarize.sh` against both result directories and present the two tables
side by side (or merge into one table with a "stack" column added by hand) in the
write-up. State the environment (on-prem/local vs DEV probe) alongside every number
— a DEV low-concurrency probe and an on-prem stress run are not comparable to each
other, only within their own kind.
