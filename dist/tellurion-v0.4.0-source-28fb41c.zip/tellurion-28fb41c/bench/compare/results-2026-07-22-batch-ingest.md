# Batch ingest — local GeoPackage characterization, 2026-07-22

## Result in one line

The release-mode GeoPackage loader applied one million OSM-derived point
features at 14,011 features/second while peak RSS stayed at 17.1 MiB. Across
10k, 100k, and 1m inputs, peak RSS varied by less than 0.4 MiB. On localhost,
the HTTP batch route applied 10k features 1.33 times faster than sequential
single-item PUTs over one persistent connection.

These are local characterization results, not cross-host capacity claims.

## Environment

| | |
|---|---|
| Host | Apple M2 Pro, 12 cores, 16 GiB RAM |
| OS | macOS 26.5.1, native arm64 processes |
| Rust | 1.97.1 |
| Tellurion | commit `039980b`, release profile |
| Storage | GeoPackage/SQLite, fresh file per repetition |
| Chunk size | 500 features per transaction |

## Dataset

- Source: GeoFabrik Monaco OpenStreetMap extract, downloaded 2026-07-22 from
  <https://download.geofabrik.de/europe/monaco.html>.
- PBF SHA-256:
  `eee7ee5c9239c5b5ab62774e1804f3a29d8a8734722dcfc3792fb9b39d0b6605`.
- Converted with GDAL to RFC 8142 GeoJSON Text Sequences (`RS=YES`), using
  OSM node IDs as feature IDs.
- Base sequence: 4,184 Point features, 954,287 bytes; SHA-256
  `02e8d26f12d7526b05a967c6d3f1c6ec6ae3054717b608885caf64a91ac575dd`.
- The 10k, 100k, and 1m fixtures repeat the base geographic/property
  distribution with collision-free numeric ID offsets. They measure ingest
  scaling, not the number of geographically distinct OSM objects.
- Fixture SHA-256 values:

  - 10k: `0d1fa9651eb839edd95f30627940864247ab45489017561d5dc50b51938f6cbf`
  - 100k: `f075bc72ee8716fbd4e5764a4bb24ce1d376b0b2f4198bab19f6812584bf946e`
  - 1m: `90727708c6a7ab4a1e95b376e0cfdd7cc84935a688a55683707cbae78fdfaa3d`

## Method

The CLI runs used `tellurion-ingest geopackage load`, release mode, a fresh
GeoPackage per repetition, and `/usr/bin/time -l` for process peak RSS. NDJSON
outcomes were written to `/dev/null`; operational logs and the human summary
used stderr. The database was reconciled after every run:

```text
feature rows = outbox rows = max(outbox.sequence) = requested item count
```

The 10k and 100k rows are medians of three measured repetitions. The 1m row is
one uncontended measured repetition. Inputs were already in the filesystem
page cache from fixture validation; no separate warm-up repetition was
discarded.

For the HTTP comparison, both methods used the same 10k sequence and a fresh
GeoPackage. The batch request was one `POST` with
`Content-Type: application/geo+json-seq`. The single-item baseline issued
10,000 sequential PUTs through one keep-alive connection, avoiding per-request
client process and connection setup. Both responses were fully drained.

## Results

### In-process GeoPackage loader

| Input | Repetitions | Median wall time | Throughput | Peak RSS |
|---:|---:|---:|---:|---:|
| 10,000 | 3 | 0.43 s | 23,256 features/s | 16.72 MiB |
| 100,000 | 3 | 5.43 s | 18,416 features/s | 16.98 MiB |
| 1,000,000 | 1 | 71.37 s | 14,011 features/s | 17.08 MiB |

All runs applied every item with zero refusals and reported complete input,
the batch high-water, and the observed primary high-water.

### HTTP batch versus single-item PUT

| Method | Items | Wall time | Throughput | Server peak RSS |
|---|---:|---:|---:|---:|
| streamed batch POST | 10,000 | 1.427 s | 7,006 features/s | 23.52 MiB |
| sequential keep-alive PUT | 10,000 | 1.896 s | 5,274 features/s | 19.36 MiB |

The batch route was 1.33× faster in this localhost, zero-latency comparison.
That is deliberately a conservative comparison: network latency amplifies the
per-request overhead of the single-item lane, but no simulated latency was
added here.

## Caveats

- This characterizes the embedded GeoPackage writer on one Apple Silicon
  machine. It is not a PostGIS result and should not be generalized to a
  multi-writer deployment.
- The server RSS values include normal boot/runtime state as well as the
  request; CLI RSS isolates the loader process.
- Live PostGIS batch tests compile and are environment-gated, but were not
  executed in this run because no test database was available.
