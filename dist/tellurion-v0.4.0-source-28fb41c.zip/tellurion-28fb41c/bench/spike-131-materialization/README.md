# Issue #131 spike harness: write-time cell materialization vs FlatGeobuf's packed R-tree

Throwaway measurement scaffolding for issue #131. **Not part of the root
cargo workspace, deliberately**: this crate depends on `h3o`, which per the
#103 spike's ground rules must never land in the tracked workspace
`Cargo.toml`/`Cargo.lock`. The empty `[workspace]` table in this crate's
`Cargo.toml` keeps cargo from attaching it to the repository root, so
`cargo build`/`cargo test --workspace` at the root never sees it. Build and
run it from this directory only.

The findings and verdict live on issue #131 and in
`docs/design/2026-08-08-materialization-spike-findings.md`. This directory
exists so the numbers can be regenerated; it is inert otherwise.

## What it measures

Three ways to answer a bbox `items()` query against a FlatGeobuf file:

1. **`rtree`** — what `tellurion-flatgeobuf` does today: in-memory packed
   R-tree search (the driver's cached-header warm-up), then a fresh
   `select_bbox` open to decode the page. The R-tree/decode code paths
   replicate `crates/tellurion-flatgeobuf/src/driver.rs` against the same
   `flatgeobuf`/`geozero` pins.
2. **`cells`** — the write-time materialization #131's decision comment
   asks about: per-feature H3 coverings (res 9 primary, res 6
   estimator-fallback, `Covers` mode — #103's exact parameters) plus a
   res-6 parent ladder and per-feature bboxes, in a sorted sidecar keyed by
   the driver's feature-index identity. Query = cover the window, binary
   search the pair arrays, verify candidates against materialized bboxes —
   returns the exact same match set as the R-tree.
3. **`scan`** — the honest no-index control: stream every feature, decode
   coordinates, test the bbox.

Plus **`bboxscan`**, a degenerate-materialization control: linear scan of
the materialized per-feature bbox array (which is exactly what the packed
R-tree's leaf level already stores).

## Reproducing

```sh
# 1. Real data: Geofabrik italy/isole (same source as the #103 spike), ODbL,
#    © OpenStreetMap contributors. ~213 MB.
mkdir -p ../../demo-data/spike-131 && cd ../../demo-data/spike-131
curl -sS --fail -L -o isole-latest.osm.pbf \
  "https://download.geofabrik.de/europe/italy/isole-latest.osm.pbf"

# 2. Extract areas to NDJSON (pip install osmium). ~300k / ~30k rows.
python3 ../../bench/spike-131-materialization/extract_osm.py \
  isole-latest.osm.pbf large.ndjson small.ndjson

# 3. Build fixtures + sidecars, then bench (run from this directory).
cd ../../bench/spike-131-materialization && cargo build --release
B=target/release/spike-131-materialization
D=../../demo-data/spike-131
$B build $D/large.ndjson $D/large.fgb
$B build $D/small.ndjson $D/small.fgb
$B materialize $D/large.fgb $D/large.sidecar
$B materialize $D/small.fgb $D/small.sidecar
$B bench large-300k $D/large.fgb $D/large.sidecar --scan > run1.csv
$B bench small-30k  $D/small.fgb  $D/small.sidecar --scan > run2.csv
$B cold $D/large.fgb $D/large.sidecar
```

Timing discipline: per query location, 2 warmup + 9 timed repetitions,
median-of-9 recorded; 8 locations per window bucket (3 for the scan
control); the summary reports the median across locations — same shape as
the #103/#278 measurement discipline.
