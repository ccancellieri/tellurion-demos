#!/usr/bin/env python3
"""Extract real OSM polygon features into newline-delimited GeoJSON for the
issue #131 materialization spike.

Reads Geofabrik's italy/isole extract (the same source #103's spike used),
assembles areas (closed ways + multipolygon relations) via pyosmium, keeps
those carrying area-ish tags (approximating GDAL's `multipolygons` OSM
layer), and samples 1-in-N to reach the campaign-fixture scale (~300k rows).

Usage:
    python3 extract_osm.py ISOLE_PBF OUT_LARGE.ndjson OUT_SMALL.ndjson

The large fixture keeps every 7th qualifying area (~300k of ~2.1M); the
small fixture is every 10th feature of the large one (~30k). Sampling by
stride keeps the full spatial extent and the real geometry-size skew.
"""

import json
import sys

import osmium
from osmium.geom import GeoJSONFactory

AREA_TAG_KEYS = (
    "building",
    "natural",
    "landuse",
    "leisure",
    "amenity",
    "man_made",
    "boundary",
    "place",
    "waterway",
    "aeroway",
)

LARGE_STRIDE = 7
SMALL_STRIDE = 70  # relative to qualifying areas; == every 10th large row


class AreaWriter(osmium.SimpleHandler):
    def __init__(self, out_large, out_small):
        super().__init__()
        self.factory = GeoJSONFactory()
        self.out_large = out_large
        self.out_small = out_small
        self.seen = 0
        self.kept = 0
        self.errors = 0

    def area(self, a):
        kind = None
        for key in AREA_TAG_KEYS:
            value = a.tags.get(key)
            if value is not None:
                kind = f"{key}={value}"
                break
        if kind is None:
            return
        idx = self.seen
        self.seen += 1
        if idx % LARGE_STRIDE != 0:
            return
        try:
            geom = self.factory.create_multipolygon(a)
        except Exception:
            self.errors += 1
            return
        feature = {
            "type": "Feature",
            "properties": {"osm_id": a.orig_id(), "kind": kind[:64]},
            "geometry": json.loads(geom),
        }
        line = json.dumps(feature, separators=(",", ":"))
        self.out_large.write(line)
        self.out_large.write("\n")
        if idx % SMALL_STRIDE == 0:
            self.out_small.write(line)
            self.out_small.write("\n")
        self.kept += 1
        if self.kept % 50000 == 0:
            print(f"kept {self.kept} (seen {self.seen})", file=sys.stderr)


def main():
    pbf, out_large_path, out_small_path = sys.argv[1:4]
    with open(out_large_path, "w") as out_large, open(out_small_path, "w") as out_small:
        handler = AreaWriter(out_large, out_small)
        handler.apply_file(pbf, locations=True, idx="flex_mem")
    print(
        f"done: seen={handler.seen} kept={handler.kept} errors={handler.errors}",
        file=sys.stderr,
    )


if __name__ == "__main__":
    main()
