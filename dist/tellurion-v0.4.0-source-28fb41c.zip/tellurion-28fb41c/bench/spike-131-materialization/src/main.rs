//! Throwaway measurement harness for issue #131: does a write-time
//! materialized H3 cell prefilter beat FlatGeobuf's own packed Hilbert
//! R-tree on a file-backed, index-less-style driver?
//!
//! NOT production code. This crate is a standalone workspace (see
//! Cargo.toml) so its `h3o` dependency never touches the tracked root
//! workspace, per the #103 spike's ground rules. The R-tree query path and
//! the GeoJSON decode path below deliberately replicate
//! `crates/tellurion-flatgeobuf/src/driver.rs` (same crate pins, same
//! two-pass in-memory-search-then-`select_bbox` shape) so the baseline is
//! the driver's real behaviour, not a strawman.
//!
//! Subcommands:
//!   build <in.ndjson> <out.fgb>       write a Hilbert-sorted, indexed FGB
//!   materialize <in.fgb> <out.sidecar> write-time cell materialization
//!   bench <label> <fgb> <sidecar> [--scan]  warm-path measurements (CSV)
//!   cold <fgb> <sidecar>              cold-start measurements
//!
//! Cell parameters follow #103's spike exactly: H3 res 9 primary, res 6
//! estimator-triggered fallback, 300-cell cap, `ContainmentMode::Covers`.
//! On top of that this harness materializes the resolution ladder #103's
//! own findings called "required, not optional": a res-6 parent pair set
//! for every feature, so a large query window can match at res 6 instead
//! of exploding a res-9 query covering.

use std::collections::HashSet;
use std::fs::File;
use std::io::{self, BufReader, BufWriter, Read, Write};
use std::time::Instant;

use flatgeobuf::packed_r_tree::{PackedRTree, SearchResultItem};
use flatgeobuf::{
    ColumnType, FallibleStreamingIterator, FgbCrs, FgbReader, FgbWriter, FgbWriterOptions,
    GeometryType,
};
use geo_types::{Polygon, Rect as GeoRect};
use geozero::geojson::GeoJson;
use h3o::geom::{ContainmentMode, TilerBuilder};
use h3o::{CellIndex, LatLng, Resolution};

// #103 parameters, verbatim.
const H3_RES_PRIMARY: Resolution = Resolution::Nine;
const H3_RES_FALLBACK: Resolution = Resolution::Six;
const H3_CELL_CAP: usize = 300;

/// Query-planning cap: if the estimated res-9 covering of the query window
/// exceeds this, match at res 6 against the materialized parent ladder
/// instead of computing a huge res-9 covering.
const QUERY_RES9_CAP: usize = 512;

/// Page size for the decode phase — the driver's default `limit` ballpark.
const PAGE_LIMIT: usize = 100;

fn main() {
    let args: Vec<String> = std::env::args().collect();
    match args.get(1).map(String::as_str) {
        Some("build") => build(&args[2], &args[3]),
        Some("materialize") => materialize(&args[2], &args[3]),
        Some("bench") => bench(&args[2], &args[3], &args[4], args.contains(&"--scan".into())),
        Some("cold") => cold(&args[2], &args[3]),
        _ => eprintln!(
            "usage: spike-131 <build in.ndjson out.fgb | materialize in.fgb out.sidecar | bench label fgb sidecar [--scan] | cold fgb sidecar>"
        ),
    }
}

// ---------------------------------------------------------------------------
// build: NDJSON -> Hilbert-sorted, packed-R-tree-indexed FlatGeobuf
// ---------------------------------------------------------------------------

fn build(ndjson_path: &str, fgb_path: &str) {
    let start = Instant::now();
    let options = FgbWriterOptions {
        crs: FgbCrs {
            code: 4326,
            ..Default::default()
        },
        description: Some("issue #131 spike fixture — real OSM areas (isole extract), ODbL"),
        ..Default::default()
    };
    let mut fgb = FgbWriter::create_with_options("spike", GeometryType::MultiPolygon, options)
        .expect("create writer");
    fgb.add_column("osm_id", ColumnType::Long, |_, _| {});
    fgb.add_column("kind", ColumnType::String, |_, _| {});

    let reader = BufReader::new(File::open(ndjson_path).expect("open ndjson"));
    let mut count = 0u64;
    for line in io::BufRead::lines(reader) {
        let line = line.expect("read line");
        if line.is_empty() {
            continue;
        }
        fgb.add_feature(GeoJson(&line)).expect("add feature");
        count += 1;
        if count.is_multiple_of(50_000) {
            eprintln!(
                "added {count} features ({:.1}s)",
                start.elapsed().as_secs_f64()
            );
        }
    }
    let file = File::create(fgb_path).expect("create fgb");
    fgb.write(BufWriter::new(file)).expect("write fgb");
    let bytes = std::fs::metadata(fgb_path).unwrap().len();
    eprintln!(
        "wrote {fgb_path}: {count} features, {bytes} bytes, {:.1}s total",
        start.elapsed().as_secs_f64()
    );
}

// ---------------------------------------------------------------------------
// The write-time materialization (the thing this spike measures, then throws
// away): per-feature bbox + H3 coverings, in a sidecar keyed by the
// driver's own feature-index identity.
// ---------------------------------------------------------------------------

struct Sidecar {
    bboxes: Vec<[f64; 4]>,
    /// (cell, feature index), sorted by cell: res-9 coverings of
    /// primary-resolution features.
    pairs9: Vec<(u64, u32)>,
    /// Same, res-6 coverings of estimator-demoted fallback features.
    pairs6_fallback: Vec<(u64, u32)>,
    /// The ladder: res-6 cells (parents of the res-9 covering, or the
    /// fallback covering itself) for every feature.
    pairs6_all: Vec<(u64, u32)>,
}

const SIDECAR_MAGIC: &[u8; 4] = b"TSC1";

fn bbox_union(a: [f64; 4], b: [f64; 4]) -> [f64; 4] {
    [
        a[0].min(b[0]),
        a[1].min(b[1]),
        a[2].max(b[2]),
        a[3].max(b[3]),
    ]
}

fn bbox_of_polys(polys: &[Polygon<f64>]) -> Option<[f64; 4]> {
    let mut acc: Option<[f64; 4]> = None;
    for p in polys {
        for c in p.exterior().coords() {
            let b = [c.x, c.y, c.x, c.y];
            acc = Some(match acc {
                Some(a) => bbox_union(a, b),
                None => b,
            });
        }
    }
    acc
}

fn bbox_intersects(a: [f64; 4], b: [f64; 4]) -> bool {
    a[0] <= b[2] && b[0] <= a[2] && a[1] <= b[3] && b[1] <= a[3]
}

/// #103's estimator, verbatim: rough cell count for a bbox at a resolution.
fn bbox_cell_estimate(bbox: [f64; 4], resolution: Resolution) -> usize {
    let center_lat = (bbox[1] + bbox[3]) / 2.0;
    let center_lng = (bbox[0] + bbox[2]) / 2.0;
    let Ok(center) = LatLng::new(center_lat, center_lng) else {
        return usize::MAX;
    };
    let hex_area_km2 = center.to_cell(resolution).area_km2();
    if hex_area_km2 <= 0.0 {
        return usize::MAX;
    }
    const KM_PER_DEG: f64 = 111.32;
    let width_km = (bbox[2] - bbox[0]) * KM_PER_DEG * center_lat.to_radians().cos().abs().max(0.01);
    let height_km = (bbox[3] - bbox[1]) * KM_PER_DEG;
    let bbox_area_km2 = (width_km * height_km).abs();
    (bbox_area_km2 / hex_area_km2).ceil().max(1.0) as usize
}

fn cover_polys(polys: &[Polygon<f64>], resolution: Resolution) -> Vec<CellIndex> {
    let mut tiler = TilerBuilder::new(resolution)
        .containment_mode(ContainmentMode::Covers)
        .build();
    for p in polys {
        // A handful of OSM rings are degenerate; skip rather than aborting.
        let _ = tiler.add(p.clone());
    }
    let cells: HashSet<CellIndex> = tiler.into_coverage().collect();
    cells.into_iter().collect()
}

fn cover_rect(bbox: [f64; 4], resolution: Resolution) -> Vec<CellIndex> {
    let rect = GeoRect::new((bbox[0], bbox[1]), (bbox[2], bbox[3]));
    let mut cells = cover_polys(&[rect.to_polygon()], resolution);
    if cells.is_empty() {
        // Degenerate (point-like) bbox: fall back to the center cell so no
        // feature is ever invisible to the prefilter.
        if let Ok(center) = LatLng::new((bbox[1] + bbox[3]) / 2.0, (bbox[0] + bbox[2]) / 2.0) {
            cells.push(center.to_cell(resolution));
        }
    }
    cells
}

/// Extracts the polygons of a decoded feature via geozero's geo-types writer.
fn feature_polys(feature: &flatgeobuf::FgbFeature) -> Vec<Polygon<f64>> {
    use geozero::GeozeroGeometry;
    let mut writer = geozero::geo_types::GeoWriter::new();
    if feature.process_geom(&mut writer).is_err() {
        return Vec::new();
    }
    match writer.take_geometry() {
        Some(geo_types::Geometry::Polygon(p)) => vec![p],
        Some(geo_types::Geometry::MultiPolygon(mp)) => mp.0,
        _ => Vec::new(),
    }
}

fn materialize(fgb_path: &str, sidecar_path: &str) {
    let start = Instant::now();
    let file = File::open(fgb_path).expect("open fgb");
    let mut iter = FgbReader::open(BufReader::new(file))
        .expect("fgb open")
        .select_all()
        .expect("select_all");

    let mut bboxes: Vec<[f64; 4]> = Vec::new();
    let mut pairs9: Vec<(u64, u32)> = Vec::new();
    let mut pairs6_fallback: Vec<(u64, u32)> = Vec::new();
    let mut pairs6_all: Vec<(u64, u32)> = Vec::new();
    let mut fallback_count = 0u64;
    let mut idx: u32 = 0;

    while let Some(feature) = iter.next().expect("iterate") {
        let polys = feature_polys(feature);
        let bbox = bbox_of_polys(&polys).unwrap_or([0.0, 0.0, 0.0, 0.0]);
        bboxes.push(bbox);

        // Cover the feature's *bbox*, not its true geometry: the packed
        // R-tree (and the OGC bbox filter the driver serves with it)
        // answers bbox-intersects, and this spike holds that answer
        // constant across contenders. A geometry-true covering is a
        // *tighter* filter than the R-tree — it legitimately drops
        // features whose bbox touches the window but whose geometry does
        // not — which was observed on real data and would make the two
        // answer sets incomparable.
        let use_fallback = bbox_cell_estimate(bbox, H3_RES_PRIMARY) > H3_CELL_CAP;
        if use_fallback {
            fallback_count += 1;
            let cells = cover_rect(bbox, H3_RES_FALLBACK);
            for c in &cells {
                pairs6_fallback.push((u64::from(*c), idx));
                pairs6_all.push((u64::from(*c), idx));
            }
        } else {
            let cells = cover_rect(bbox, H3_RES_PRIMARY);
            let mut parents: HashSet<u64> = HashSet::new();
            for c in &cells {
                pairs9.push((u64::from(*c), idx));
                if let Some(p) = c.parent(H3_RES_FALLBACK) {
                    parents.insert(u64::from(p));
                }
            }
            for p in parents {
                pairs6_all.push((p, idx));
            }
        }
        idx += 1;
        if idx.is_multiple_of(50_000) {
            eprintln!("materialized {idx} ({:.1}s)", start.elapsed().as_secs_f64());
        }
    }
    let cover_secs = start.elapsed().as_secs_f64();

    pairs9.sort_unstable();
    pairs6_fallback.sort_unstable();
    pairs6_all.sort_unstable();

    let mut out = BufWriter::new(File::create(sidecar_path).expect("create sidecar"));
    out.write_all(SIDECAR_MAGIC).unwrap();
    out.write_all(&(bboxes.len() as u64).to_le_bytes()).unwrap();
    for b in &bboxes {
        for v in b {
            out.write_all(&v.to_le_bytes()).unwrap();
        }
    }
    for pairs in [&pairs9, &pairs6_fallback, &pairs6_all] {
        out.write_all(&(pairs.len() as u64).to_le_bytes()).unwrap();
        for (cell, i) in pairs.iter() {
            out.write_all(&cell.to_le_bytes()).unwrap();
            out.write_all(&i.to_le_bytes()).unwrap();
        }
    }
    out.flush().unwrap();
    let bytes = std::fs::metadata(sidecar_path).unwrap().len();
    eprintln!(
        "materialized {} features in {:.1}s cover phase, {:.1}s total ({:.1} us/feature); \
         fallback(res6)={fallback_count}; pairs9={} pairs6_fallback={} pairs6_all={}; \
         sidecar {bytes} bytes",
        bboxes.len(),
        cover_secs,
        start.elapsed().as_secs_f64(),
        cover_secs * 1e6 / bboxes.len() as f64,
        pairs9.len(),
        pairs6_fallback.len(),
        pairs6_all.len(),
    );
}

fn load_sidecar(path: &str) -> Sidecar {
    let mut data = Vec::new();
    File::open(path)
        .expect("open sidecar")
        .read_to_end(&mut data)
        .expect("read sidecar");
    let mut pos = 0usize;
    let mut take = |n: usize| {
        let s = &data[pos..pos + n];
        pos += n;
        s
    };
    assert_eq!(take(4), SIDECAR_MAGIC);
    let n = u64::from_le_bytes(take(8).try_into().unwrap()) as usize;
    let mut bboxes = Vec::with_capacity(n);
    for _ in 0..n {
        let mut b = [0.0f64; 4];
        for v in &mut b {
            *v = f64::from_le_bytes(take(8).try_into().unwrap());
        }
        bboxes.push(b);
    }
    let mut sections: Vec<Vec<(u64, u32)>> = Vec::new();
    for _ in 0..3 {
        let m = u64::from_le_bytes(take(8).try_into().unwrap()) as usize;
        let mut pairs = Vec::with_capacity(m);
        for _ in 0..m {
            let cell = u64::from_le_bytes(take(8).try_into().unwrap());
            let idx = u32::from_le_bytes(take(4).try_into().unwrap());
            pairs.push((cell, idx));
        }
        sections.push(pairs);
    }
    let pairs6_all = sections.pop().unwrap();
    let pairs6_fallback = sections.pop().unwrap();
    let pairs9 = sections.pop().unwrap();
    Sidecar {
        bboxes,
        pairs9,
        pairs6_fallback,
        pairs6_all,
    }
}

// ---------------------------------------------------------------------------
// Query paths
// ---------------------------------------------------------------------------

fn search_pairs(pairs: &[(u64, u32)], cell: u64, out: &mut Vec<u32>) {
    let start = pairs.partition_point(|&(c, _)| c < cell);
    for &(c, i) in &pairs[start..] {
        if c != cell {
            break;
        }
        out.push(i);
    }
}

struct CellsMatchStats {
    query_cells: usize,
    candidates: usize,
    used_res6_path: bool,
}

/// The materialized-prefilter query: covering -> pair lookups -> bbox
/// verification. Returns the exact same match set (feature bbox intersects
/// query bbox) the packed R-tree returns.
fn cells_match(sidecar: &Sidecar, bbox: [f64; 4]) -> (Vec<u32>, CellsMatchStats) {
    let mut cand: Vec<u32> = Vec::new();
    let est9 = bbox_cell_estimate(bbox, H3_RES_PRIMARY);
    let (query_cells, used_res6_path) = if est9 <= QUERY_RES9_CAP {
        let c9 = cover_rect(bbox, H3_RES_PRIMARY);
        for c in &c9 {
            search_pairs(&sidecar.pairs9, u64::from(*c), &mut cand);
        }
        // Fallback features are covered at res 6 with the true geometry, so
        // a same-resolution equality match is a guaranteed superset.
        let c6 = cover_rect(bbox, H3_RES_FALLBACK);
        for c in &c6 {
            search_pairs(&sidecar.pairs6_fallback, u64::from(*c), &mut cand);
        }
        (c9.len() + c6.len(), false)
    } else {
        // Large window: match at res 6 against the parent ladder. Parent
        // derivation is by H3 index, and an H3 child can stick out of its
        // parent's geometric boundary, so expand the query covering by one
        // grid ring to keep the candidate set a true superset.
        let c6 = cover_rect(bbox, H3_RES_FALLBACK);
        let mut set: HashSet<u64> = HashSet::new();
        for c in &c6 {
            set.insert(u64::from(*c));
            for n in c.grid_disk::<Vec<_>>(1) {
                set.insert(u64::from(n));
            }
        }
        for c in &set {
            search_pairs(&sidecar.pairs6_all, *c, &mut cand);
        }
        (set.len(), true)
    };
    cand.sort_unstable();
    cand.dedup();
    let candidates = cand.len();
    cand.retain(|&i| bbox_intersects(sidecar.bboxes[i as usize], bbox));
    (
        cand,
        CellsMatchStats {
            query_cells,
            candidates,
            used_res6_path,
        },
    )
}

/// Degenerate-materialization control: a linear scan over the materialized
/// per-feature bbox array (what the packed R-tree's leaf level already is).
fn bbox_scan_match(sidecar: &Sidecar, bbox: [f64; 4]) -> Vec<u32> {
    let mut out = Vec::new();
    for (i, b) in sidecar.bboxes.iter().enumerate() {
        if bbox_intersects(*b, bbox) {
            out.push(i as u32);
        }
    }
    out
}

// --- Driver-replicated pieces (see tellurion-flatgeobuf/src/driver.rs) ----

fn skip_to_index<R: Read>(reader: &mut R) -> io::Result<()> {
    let mut magic = [0u8; 8];
    reader.read_exact(&mut magic)?;
    assert_eq!(&magic[0..3], b"fgb");
    let mut size_buf = [0u8; 4];
    reader.read_exact(&mut size_buf)?;
    let header_size = u64::from(u32::from_le_bytes(size_buf));
    io::copy(&mut reader.take(header_size), &mut io::sink())?;
    Ok(())
}

struct FgbMeta {
    features_count: u64,
    envelope: [f64; 4],
}

fn read_meta(path: &str) -> FgbMeta {
    let file = File::open(path).expect("open fgb");
    let reader = FgbReader::open(BufReader::new(file)).expect("fgb open");
    let header = reader.header();
    let envelope: Vec<f64> = header.envelope().map(|v| v.iter().collect()).unwrap();
    FgbMeta {
        features_count: header.features_count(),
        envelope: <[f64; 4]>::try_from(envelope).unwrap(),
    }
}

/// The driver's warm-up work: load the packed R-tree into memory.
fn load_rtree(path: &str, features_count: usize) -> PackedRTree {
    let mut reader = BufReader::new(File::open(path).expect("open fgb"));
    skip_to_index(&mut reader).expect("skip to index");
    PackedRTree::from_buf(&mut reader, features_count, PackedRTree::DEFAULT_NODE_SIZE)
        .expect("rtree from_buf")
}

/// The driver's `feature_to_geojson`, in shape. Returns `None` for the
/// handful of real-data degenerate geometries geozero's GeoJSON writer
/// refuses (`GeometryFormat`) — the timing cost of attempting them is still
/// paid, identically, by every contender that decodes.
fn feature_to_geojson(feature: &flatgeobuf::FgbFeature, pk: u64) -> Option<serde_json::Value> {
    use flatgeobuf::FeatureAccess;
    let mut buf: Vec<u8> = Vec::new();
    {
        let mut writer = geozero::geojson::GeoJsonWriter::new(&mut buf);
        feature.process(&mut writer, 0).ok()?;
    }
    let mut value: serde_json::Value = serde_json::from_slice(&buf).ok()?;
    if let serde_json::Value::Object(map) = &mut value {
        map.insert("id".to_string(), serde_json::Value::String(pk.to_string()));
    }
    Some(value)
}

/// The driver's page-decode pass: fresh open + `select_bbox`, decode the
/// first `limit` matched features. Shared by both indexed contenders (the
/// cells side would need an equivalent seek+decode pass of its own; using
/// the same one holds the decode cost constant so the contenders differ
/// only in the match phase).
fn decode_page(
    path: &str,
    bbox: [f64; 4],
    matches: &[SearchResultItem],
    limit: usize,
) -> Vec<serde_json::Value> {
    let end = limit.min(matches.len());
    if end == 0 {
        return Vec::new();
    }
    let file = File::open(path).expect("open fgb");
    let mut iter = FgbReader::open(BufReader::new(file))
        .expect("fgb open")
        .select_bbox(bbox[0], bbox[1], bbox[2], bbox[3])
        .expect("select_bbox");
    let mut features = Vec::with_capacity(end);
    let mut pos = 0usize;
    while pos < end {
        let Some(feature) = iter.next().expect("iterate") else {
            break;
        };
        if let Some(value) = feature_to_geojson(feature, matches[pos].index as u64) {
            features.push(value);
        }
        pos += 1;
    }
    features
}

/// Minimal per-feature bbox collector for the naive-scan control.
struct BboxCollector {
    bbox: Option<[f64; 4]>,
}

impl geozero::GeomProcessor for BboxCollector {
    fn xy(&mut self, x: f64, y: f64, _idx: usize) -> geozero::error::Result<()> {
        let b = [x, y, x, y];
        self.bbox = Some(match self.bbox {
            Some(a) => bbox_union(a, b),
            None => b,
        });
        Ok(())
    }
}

/// The honest no-index control: stream every feature, decode coordinates,
/// test the bbox, decode the first `limit` matches to GeoJSON.
fn naive_scan(path: &str, bbox: [f64; 4], limit: usize) -> (u64, Vec<serde_json::Value>) {
    use geozero::GeozeroGeometry;
    let file = File::open(path).expect("open fgb");
    let mut iter = FgbReader::open(BufReader::new(file))
        .expect("fgb open")
        .select_all()
        .expect("select_all");
    let mut matched = 0u64;
    let mut page = Vec::new();
    let mut idx = 0u64;
    while let Some(feature) = iter.next().expect("iterate") {
        let mut collector = BboxCollector { bbox: None };
        if feature.process_geom(&mut collector).is_ok() {
            if let Some(b) = collector.bbox {
                if bbox_intersects(b, bbox) {
                    matched += 1;
                    if page.len() < limit {
                        if let Some(value) = feature_to_geojson(feature, idx) {
                            page.push(value);
                        }
                    }
                }
            }
        }
        idx += 1;
    }
    (matched, page)
}

// ---------------------------------------------------------------------------
// bench
// ---------------------------------------------------------------------------

struct SplitMix64(u64);

impl SplitMix64 {
    fn next(&mut self) -> u64 {
        self.0 = self.0.wrapping_add(0x9e3779b97f4a7c15);
        let mut z = self.0;
        z = (z ^ (z >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94d049bb133111eb);
        z ^ (z >> 31)
    }
}

fn median(mut xs: Vec<f64>) -> f64 {
    xs.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let n = xs.len();
    if n == 0 {
        return f64::NAN;
    }
    if n % 2 == 1 {
        xs[n / 2]
    } else {
        (xs[n / 2 - 1] + xs[n / 2]) / 2.0
    }
}

fn time_ms<T>(mut f: impl FnMut() -> T) -> (f64, T) {
    let start = Instant::now();
    let r = f();
    (start.elapsed().as_secs_f64() * 1000.0, r)
}

struct Bucket {
    name: &'static str,
    width: Option<f64>, // None = full extent width (pathological strip)
    height: f64,
}

const BUCKETS: [Bucket; 4] = [
    Bucket {
        name: "small_0.01deg",
        width: Some(0.01),
        height: 0.01,
    },
    Bucket {
        name: "medium_0.05deg",
        width: Some(0.05),
        height: 0.05,
    },
    Bucket {
        name: "large_0.2deg",
        width: Some(0.2),
        height: 0.2,
    },
    Bucket {
        name: "strip_fullwidth_0.01deg",
        width: None,
        height: 0.01,
    },
];

const LOCATIONS: usize = 8;
const WARMUP: usize = 2;
const REPEATS: usize = 9;
const SCAN_LOCATIONS: usize = 3;
const SCAN_REPEATS: usize = 7;

fn bench(label: &str, fgb_path: &str, sidecar_path: &str, with_scan: bool) {
    let meta = read_meta(fgb_path);
    let (rtree_load_ms, rtree) = time_ms(|| load_rtree(fgb_path, meta.features_count as usize));
    let (sidecar_load_ms, sidecar) = time_ms(|| load_sidecar(sidecar_path));
    eprintln!(
        "label={label} features={} envelope={:?} rtree_load_ms={rtree_load_ms:.1} sidecar_load_ms={sidecar_load_ms:.1}",
        meta.features_count, meta.envelope
    );

    println!(
        "label,bucket,loc,bbox,rtree_match_ms,cells_match_ms,bboxscan_match_ms,decode100_ms,\
         rtree_e2e_ms,cells_e2e_ms,scan_ms,matched,cells_candidates,cells_query_cells,cells_res6_path,scan_matched"
    );

    let mut correctness_failures = 0u64;
    let mut summary: Vec<String> = Vec::new();

    for (bi, bucket) in BUCKETS.iter().enumerate() {
        let mut rows: Vec<(f64, f64, f64, f64, f64, u64)> = Vec::new(); // per-loc medians
        let mut scan_medians: Vec<f64> = Vec::new();
        for loc in 0..LOCATIONS {
            // Center each query window on a random real feature (the
            // dataset envelope is mostly Mediterranean; envelope-uniform
            // sampling would measure empty sea queries). Clamped to the
            // envelope so window size stays exact.
            let mut rng = SplitMix64(0x1310_0000 + (bi as u64) * 1000 + loc as u64);
            let [minx, miny, maxx, maxy] = meta.envelope;
            let w = bucket.width.unwrap_or(maxx - minx);
            let h = bucket.height;
            let anchor = sidecar.bboxes[(rng.next() % sidecar.bboxes.len() as u64) as usize];
            let cx = (anchor[0] + anchor[2]) / 2.0;
            let cy = (anchor[1] + anchor[3]) / 2.0;
            let x0 = if bucket.width.is_some() {
                (cx - w / 2.0).clamp(minx, (maxx - w).max(minx))
            } else {
                minx
            };
            let y0 = (cy - h / 2.0).clamp(miny, (maxy - h).max(miny));
            let qbbox = [x0, y0, x0 + w, y0 + h];

            // Warmup + timed repeats, median-of-REPEATS per phase.
            let mut t_rtree = Vec::new();
            let mut t_cells = Vec::new();
            let mut t_bscan = Vec::new();
            let mut t_decode = Vec::new();
            let mut matches: Vec<SearchResultItem> = Vec::new();
            let mut cells_result: Vec<u32> = Vec::new();
            let mut stats = CellsMatchStats {
                query_cells: 0,
                candidates: 0,
                used_res6_path: false,
            };
            for rep in 0..(WARMUP + REPEATS) {
                let (ms, m) = time_ms(|| {
                    rtree
                        .search(qbbox[0], qbbox[1], qbbox[2], qbbox[3])
                        .unwrap()
                });
                if rep >= WARMUP {
                    t_rtree.push(ms);
                }
                matches = m;

                let (ms, (c, s)) = time_ms(|| cells_match(&sidecar, qbbox));
                if rep >= WARMUP {
                    t_cells.push(ms);
                }
                cells_result = c;
                stats = s;

                let (ms, _b) = time_ms(|| bbox_scan_match(&sidecar, qbbox));
                if rep >= WARMUP {
                    t_bscan.push(ms);
                }

                let (ms, _p) = time_ms(|| decode_page(fgb_path, qbbox, &matches, PAGE_LIMIT));
                if rep >= WARMUP {
                    t_decode.push(ms);
                }
            }

            // Correctness: the materialized prefilter must reproduce the
            // R-tree's exact match set (both are bbox-intersects semantics).
            let rtree_ids: Vec<u32> = matches.iter().map(|m| m.index as u32).collect();
            if rtree_ids != cells_result {
                correctness_failures += 1;
                let missing = rtree_ids
                    .iter()
                    .filter(|i| !cells_result.contains(i))
                    .count();
                let extra = cells_result
                    .iter()
                    .filter(|i| !rtree_ids.contains(i))
                    .count();
                eprintln!(
                    "CORRECTNESS MISMATCH {} loc={loc}: rtree={} cells={} missing={missing} extra={extra}",
                    bucket.name,
                    rtree_ids.len(),
                    cells_result.len()
                );
            }

            let mut scan_ms = f64::NAN;
            let mut scan_matched = 0u64;
            if with_scan && loc < SCAN_LOCATIONS {
                let mut t_scan = Vec::new();
                for rep in 0..(1 + SCAN_REPEATS) {
                    let (ms, (m, _p)) = time_ms(|| naive_scan(fgb_path, qbbox, PAGE_LIMIT));
                    if rep >= 1 {
                        t_scan.push(ms);
                    }
                    scan_matched = m;
                }
                scan_ms = median(t_scan);
                scan_medians.push(scan_ms);
            }

            let (mr, mc, mb, md) = (
                median(t_rtree),
                median(t_cells),
                median(t_bscan),
                median(t_decode),
            );
            println!(
                "{label},{},{loc},{:.5}:{:.5}:{:.5}:{:.5},{mr:.4},{mc:.4},{mb:.4},{md:.4},{:.4},{:.4},{scan_ms:.1},{},{},{},{},{scan_matched}",
                bucket.name,
                qbbox[0],
                qbbox[1],
                qbbox[2],
                qbbox[3],
                mr + md,
                mc + md,
                matches.len(),
                stats.candidates,
                stats.query_cells,
                stats.used_res6_path,
            );
            rows.push((mr, mc, mb, md, mr + md, matches.len() as u64));
        }

        type Row = (f64, f64, f64, f64, f64, u64);
        let med = |f: &dyn Fn(&Row) -> f64| median(rows.iter().map(f).collect());
        summary.push(format!(
            "| {label} | {} | {:.3} | {:.3} | {:.3} | {:.3} | {:.0} | {} |",
            bucket.name,
            med(&|r| r.0),
            med(&|r| r.1),
            med(&|r| r.2),
            med(&|r| r.3),
            median(rows.iter().map(|r| r.5 as f64).collect()),
            if scan_medians.is_empty() {
                "-".to_string()
            } else {
                format!("{:.0}", median(scan_medians.clone()))
            }
        ));
    }

    eprintln!(
        "\nsummary (medians across {LOCATIONS} locations of per-location median-of-{REPEATS}):"
    );
    eprintln!("| label | bucket | rtree_match_ms | cells_match_ms | bboxscan_ms | decode100_ms | matched | scan_ms |");
    eprintln!("|---|---|---|---|---|---|---|---|");
    for line in &summary {
        eprintln!("{line}");
    }
    eprintln!(
        "correctness: {}",
        if correctness_failures == 0 {
            "OK — cells match set identical to R-tree match set at every sample".to_string()
        } else {
            format!("{correctness_failures} MISMATCHED SAMPLES")
        }
    );
}

// ---------------------------------------------------------------------------
// cold
// ---------------------------------------------------------------------------

fn drop_caches() -> bool {
    let _ = std::process::Command::new("sync").status();
    std::fs::write("/proc/sys/vm/drop_caches", "3").is_ok()
}

fn cold(fgb_path: &str, sidecar_path: &str) {
    let meta = read_meta(fgb_path);
    let center = [
        (meta.envelope[0] + meta.envelope[2]) / 2.0 - 0.005,
        (meta.envelope[1] + meta.envelope[3]) / 2.0 - 0.005,
        (meta.envelope[0] + meta.envelope[2]) / 2.0 + 0.005,
        (meta.envelope[1] + meta.envelope[3]) / 2.0 + 0.005,
    ];
    let mut dropped_any = false;
    let mut rtree_init = Vec::new();
    let mut sidecar_init = Vec::new();
    for _ in 0..7 {
        dropped_any |= drop_caches();
        let (ms, rtree) = time_ms(|| {
            let m = read_meta(fgb_path);
            load_rtree(fgb_path, m.features_count as usize)
        });
        let (qms, _) = time_ms(|| {
            rtree
                .search(center[0], center[1], center[2], center[3])
                .unwrap()
        });
        rtree_init.push(ms + qms);

        dropped_any |= drop_caches();
        let (ms, sc) = time_ms(|| load_sidecar(sidecar_path));
        let (qms, _) = time_ms(|| cells_match(&sc, center));
        sidecar_init.push(ms + qms);
    }
    println!(
        "cold init+first-query, median of 7 (page-cache drop {}): rtree={:.1} ms {:?}; sidecar_cells={:.1} ms {:?}",
        if dropped_any { "effective" } else { "NOT permitted — OS cache warm, numbers are process-cold only" },
        median(rtree_init.clone()),
        rtree_init.iter().map(|v| (v * 10.0).round() / 10.0).collect::<Vec<_>>(),
        median(sidecar_init.clone()),
        sidecar_init.iter().map(|v| (v * 10.0).round() / 10.0).collect::<Vec<_>>(),
    );
}
