#!/usr/bin/env bash
# Minimal adaptation of scenarios.sh for the Python reference stack ("geoid"),
# whose URL shapes differ from tellurion's. Additive file: scenarios.sh itself
# is never modified. Reuses lib/tilewalk.awk verbatim and writes the same
# output shape (*.repN.json / *.warmupN.json / *.metrics_{before,after}.prom)
# so summarize.sh works unchanged against either stack's results directory.
# See bench/compare/README.md for the fairness protocol this pairs with.
#
# Reference stack path templates (verified locally, see bench/compare notes):
#   items:  /features/catalogs/{CATALOG}/collections/{COLLECTION}/items?limit=N
#   item:   /features/catalogs/{CATALOG}/collections/{COLLECTION}/items/{id}
#   MVT:    /tiles/catalogs/{CATALOG}/collections/{COLLECTION}/tiles/{z}/{x}/{y}.mvt
#   PNG:    /tiles/catalogs/{CATALOG}/collections/{COLLECTION}/map/tiles/WebMercatorQuad/{z}/{x}/{y}.png
#
# Env vars (all optional, defaults shown) -- same names/semantics as
# scenarios.sh plus CATALOG and AUTH_HEADER:
#   BASE_URL      http://127.0.0.1:80   reference server under test
#   CATALOG       bench01               catalog id
#   COLLECTION    lisbon_roads          collection id
#   AUTH_HEADER   (unset)               full header line, e.g. "Authorization: Bearer <jwt>"
#   ZMAX, DURATION, CONCURRENCY, SEED, REPS, WARMUP, WALK_COUNT, MAXSTEP,
#   MIXED_ZOOM, BBOX, ITEM_ID, RSS_METRIC, OUT_DIR -- identical to scenarios.sh

set -eu
export LC_ALL=C

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LIB_DIR="$SCRIPT_DIR/lib"

BASE_URL="${BASE_URL:-http://127.0.0.1:80}"
CATALOG="${CATALOG:-bench01}"
COLLECTION="${COLLECTION:-lisbon_roads}"
AUTH_HEADER="${AUTH_HEADER:-}"
ZMAX="${ZMAX:-14}"
DURATION="${DURATION:-10s}"
CONCURRENCY="${CONCURRENCY:-50}"
SEED="${SEED:-42}"
REPS="${REPS:-3}"
WARMUP="${WARMUP:-1}"
WALK_COUNT="${WALK_COUNT:-24}"
MAXSTEP="${MAXSTEP:-2}"
MIXED_ZOOM="${MIXED_ZOOM:-10}"
RSS_METRIC="${RSS_METRIC:-process_resident_memory_bytes}"
OUT_DIR="${OUT_DIR:-$SCRIPT_DIR/results/$(date -u +%Y%m%dT%H%M%SZ)}"

ITEMS_BASE="$BASE_URL/features/catalogs/$CATALOG/collections/$COLLECTION"
TILES_BASE="$BASE_URL/tiles/catalogs/$CATALOG/collections/$COLLECTION"

CURL_AUTH_OPTS=()
OHA_AUTH_OPTS=()
if [ -n "$AUTH_HEADER" ]; then
    CURL_AUTH_OPTS=(-H "$AUTH_HEADER")
    OHA_AUTH_OPTS=(-H "$AUTH_HEADER")
fi

for tool in awk jq curl oha; do
    command -v "$tool" >/dev/null 2>&1 || {
        echo "ERROR: required tool '$tool' not found on PATH" >&2
        exit 1
    }
done

if ! curl -sf --max-time 5 "${CURL_AUTH_OPTS[@]}" "$ITEMS_BASE" -o /dev/null; then
    echo "ERROR: cannot reach $ITEMS_BASE (is the reference stack up? auth header set?)" >&2
    exit 1
fi

mkdir -p "$OUT_DIR"
echo "results -> $OUT_DIR"

# --- bbox discovery -----------------------------------------------------
if [ -n "${BBOX:-}" ]; then
    WEST="$(echo "$BBOX" | cut -d, -f1)"
    SOUTH="$(echo "$BBOX" | cut -d, -f2)"
    EAST="$(echo "$BBOX" | cut -d, -f3)"
    NORTH="$(echo "$BBOX" | cut -d, -f4)"
else
    BBOX_CSV="$(curl -sf --max-time 5 "${CURL_AUTH_OPTS[@]}" "$ITEMS_BASE" \
        | jq -r '.extent.spatial.bbox[0] | @csv' 2>/dev/null || true)"
    if [ -z "$BBOX_CSV" ]; then
        echo "ERROR: could not discover bbox from $ITEMS_BASE; set BBOX=west,south,east,north" >&2
        exit 1
    fi
    WEST="$(echo "$BBOX_CSV" | cut -d, -f1)"
    SOUTH="$(echo "$BBOX_CSV" | cut -d, -f2)"
    EAST="$(echo "$BBOX_CSV" | cut -d, -f3)"
    NORTH="$(echo "$BBOX_CSV" | cut -d, -f4)"
fi
echo "bbox: west=$WEST south=$SOUTH east=$EAST north=$NORTH"

# --- item id discovery ---------------------------------------------------
HAVE_ITEM_ID=1
if [ -z "${ITEM_ID:-}" ]; then
    ITEM_ID="$(curl -sf --max-time 5 "${CURL_AUTH_OPTS[@]}" "$ITEMS_BASE/items?limit=1" \
        | jq -r '.features[0].id // empty' 2>/dev/null || true)"
fi
if [ -z "$ITEM_ID" ]; then
    echo "WARNING: no item id available (set ITEM_ID or seed a non-empty collection); skipping item_by_id and the item share of mixed_70_20_10" >&2
    HAVE_ITEM_ID=0
fi

TOTAL_REPS=$((WARMUP + REPS))

scrape_metrics() {
    curl -s --max-time 5 "${CURL_AUTH_OPTS[@]}" "$BASE_URL/metrics" -o "$OUT_DIR/$1.metrics_$2.prom" || true
}

rep_file() {
    name="$1"; idx="$2"
    if [ "$idx" -le "$WARMUP" ]; then
        echo "$OUT_DIR/$name.warmup$idx.json"
    else
        echo "$OUT_DIR/$name.rep$((idx - WARMUP)).json"
    fi
}

build_alt() {
    awk -f "$LIB_DIR/tilewalk.awk" -v seed="$2" -v z="$1" \
        -v west="$WEST" -v south="$SOUTH" -v east="$EAST" -v north="$NORTH" \
        -v count="$3" -v maxstep="$4" \
        | awk 'BEGIN{ORS=""} {printf "%s%s/%s", (NR>1?"|":""), $3, $2} END{print ""}'
}

run_plain() {
    name="$1"; url="$2"; conc="$3"
    scrape_metrics "$name" before
    i=1
    while [ "$i" -le "$TOTAL_REPS" ]; do
        out="$(rep_file "$name" "$i")"
        oha --no-tui --output-format json -c "$conc" -z "$DURATION" "${OHA_AUTH_OPTS[@]}" -o "$out" "$url"
        i=$((i + 1))
    done
    scrape_metrics "$name" after
}

echo "== MVT sweep (cold/warm) z0..$ZMAX =="
z=0
while [ "$z" -le "$ZMAX" ]; do
    i=1
    cold_name="mvt_cold_z$z"
    scrape_metrics "$cold_name" before
    while [ "$i" -le "$TOTAL_REPS" ]; do
        rep_seed=$((SEED + z * 10000 + i))
        alt="$(build_alt "$z" "$rep_seed" "$WALK_COUNT" "$MAXSTEP")"
        url="$TILES_BASE/tiles/$z/($alt)\\.mvt"
        out="$(rep_file "$cold_name" "$i")"
        oha --no-tui --rand-regex-url --output-format json -c "$CONCURRENCY" -z "$DURATION" "${OHA_AUTH_OPTS[@]}" -o "$out" "$url"
        i=$((i + 1))
    done
    scrape_metrics "$cold_name" after

    i=1
    warm_name="mvt_warm_z$z"
    scrape_metrics "$warm_name" before
    while [ "$i" -le "$TOTAL_REPS" ]; do
        rep_seed=$((SEED + z * 10000 + i))
        alt="$(build_alt "$z" "$rep_seed" "$WALK_COUNT" "$MAXSTEP")"
        url="$TILES_BASE/tiles/$z/($alt)\\.mvt"
        out="$(rep_file "$warm_name" "$i")"
        oha --no-tui --rand-regex-url --output-format json -c "$CONCURRENCY" -z "$DURATION" "${OHA_AUTH_OPTS[@]}" -o "$out" "$url"
        i=$((i + 1))
    done
    scrape_metrics "$warm_name" after

    z=$((z + 1))
done

echo "== PNG sweep (same coords as the MVT sweep) z0..$ZMAX =="
z=0
while [ "$z" -le "$ZMAX" ]; do
    i=1
    png_name="png_z$z"
    scrape_metrics "$png_name" before
    while [ "$i" -le "$TOTAL_REPS" ]; do
        rep_seed=$((SEED + z * 10000 + i))
        alt="$(build_alt "$z" "$rep_seed" "$WALK_COUNT" "$MAXSTEP")"
        url="$TILES_BASE/map/tiles/WebMercatorQuad/$z/($alt)\\.png"
        out="$(rep_file "$png_name" "$i")"
        oha --no-tui --rand-regex-url --output-format json -c "$CONCURRENCY" -z "$DURATION" "${OHA_AUTH_OPTS[@]}" -o "$out" "$url"
        i=$((i + 1))
    done
    scrape_metrics "$png_name" after
    z=$((z + 1))
done

echo "== items pages =="
run_plain "items_limit100" "$ITEMS_BASE/items?limit=100" "$CONCURRENCY"
run_plain "items_limit1000" "$ITEMS_BASE/items?limit=1000" "$CONCURRENCY"

if [ "$HAVE_ITEM_ID" -eq 1 ]; then
    echo "== single item by id =="
    run_plain "item_by_id" "$ITEMS_BASE/items/$ITEM_ID" "$CONCURRENCY"
fi

echo "== mixed 70/20/10 (tiles/items/item-by-id, concurrency-weighted, run concurrently) =="
if [ "$HAVE_ITEM_ID" -eq 1 ]; then
    tile_conc=$(( CONCURRENCY * 70 / 100 )); [ "$tile_conc" -ge 1 ] || tile_conc=1
    items_conc=$(( CONCURRENCY * 20 / 100 )); [ "$items_conc" -ge 1 ] || items_conc=1
    item_conc=$(( CONCURRENCY - tile_conc - items_conc )); [ "$item_conc" -ge 1 ] || item_conc=1

    scrape_metrics "mixed_70_20_10" before
    i=1
    while [ "$i" -le "$TOTAL_REPS" ]; do
        rep_seed=$((SEED + 900000 + i))
        alt="$(build_alt "$MIXED_ZOOM" "$rep_seed" "$WALK_COUNT" "$MAXSTEP")"
        tile_url="$TILES_BASE/tiles/$MIXED_ZOOM/($alt)\\.mvt"
        items_url="$ITEMS_BASE/items?limit=100"
        item_url="$ITEMS_BASE/items/$ITEM_ID"

        tile_out="$(rep_file "mixed_70_20_10.tiles" "$i")"
        items_out="$(rep_file "mixed_70_20_10.items" "$i")"
        item_out="$(rep_file "mixed_70_20_10.item" "$i")"

        oha --no-tui --rand-regex-url --output-format json -c "$tile_conc" -z "$DURATION" "${OHA_AUTH_OPTS[@]}" -o "$tile_out" "$tile_url" &
        oha --no-tui --output-format json -c "$items_conc" -z "$DURATION" "${OHA_AUTH_OPTS[@]}" -o "$items_out" "$items_url" &
        oha --no-tui --output-format json -c "$item_conc" -z "$DURATION" "${OHA_AUTH_OPTS[@]}" -o "$item_out" "$item_url" &
        wait
        i=$((i + 1))
    done
    scrape_metrics "mixed_70_20_10" after
else
    echo "skipping mixed_70_20_10 (no item id available)" >&2
fi

echo "done: $OUT_DIR"
