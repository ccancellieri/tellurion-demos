# Tellurion commercial licensing notice

Tellurion 0.3.0 is source-available under the [Business Source License 1.1](LICENSE).
Before its 2030-07-23 Change Date, production use by or for a business, government, or other organisation requires a commercial licence. Evaluation, development, testing,
training, and other non-production use remain free under the BUSL terms; a natural
person may also make personal, non-commercial production use under the Additional Use
Grant.

This notice is not a commercial licence, EULA, order form, offer, or grant of rights.
Commercial rights exist only in a separate written agreement executed by the copyright
holder and the customer. That agreement defines the licensed software, permitted use,
fees, term, support, warranties, liability, termination, and other commercial terms.

## Request a commercial licence

Use the GitHub profile at <https://github.com/ccancellieri> to request commercial
licensing information. Please do not rely on this notice as permission for
organisational production use.

For the plain-language use categories and automatic AGPL conversion, read the
[licensing guide](docs/licensing.md). This notice is not legal advice and does not
replace the BUSL text or an executed commercial agreement.
