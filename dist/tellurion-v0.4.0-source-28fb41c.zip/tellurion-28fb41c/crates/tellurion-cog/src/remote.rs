//! Ranged HTTP GET reads over a remote GeoTIFF (`#37` slice 2). Adapts
//! `Range: bytes=start-end` requests to `std::io::{Read, Seek}` so
//! `reader.rs`'s `tiff::decoder::Decoder` — which only ever needs
//! random-access byte reads, never a whole-file slurp — can walk a remote
//! GeoTIFF's header/IFD chain and tile data exactly the way it walks a
//! local file. Never issues an un-ranged GET: [`HttpRangeReader::open`]
//! proves the remote source honors `Range` (a real `206 Partial Content`
//! with a well-formed `Content-Range` total) before returning a reader at
//! all, so a source that ignores `Range` and answers `200 OK` with the
//! whole body is refused right there rather than silently downloaded.
//!
//! Built on the *async* `reqwest::Client`, bridged to the synchronous
//! `Read`/`Seek` this reader implements via `tokio::runtime::Handle::
//! block_on` — never `reqwest::blocking`. That client owns a second, nested
//! Tokio runtime internally, and dropping one from inside the workspace's
//! own async runtime (a config reload replacing a `CogBackend`, or plain
//! process shutdown — both routine here) panics ("cannot drop a runtime in
//! a context where blocking is not allowed"). `Handle::block_on` carries no
//! such risk: every call this module makes runs from inside the
//! `tokio::task::spawn_blocking` context `reader.rs`'s own doc already
//! requires ([`HttpRangeReader::open`]/`ensure_window` call
//! `Handle::current()`, which only succeeds there or on an actual runtime
//! worker thread — calling either from a bare thread with no runtime at all
//! is a programmer error this panics on loudly, same as any other contract
//! violation in this crate).

use std::io;
use std::io::{Read, Seek, SeekFrom};

use reqwest::header::{CONTENT_RANGE, RANGE};
use reqwest::{Client, Response, StatusCode, Url};
use tokio::runtime::Handle;

use crate::error::CogError;

/// Bytes fetched per cache miss. Large enough that the handful of small,
/// closely-spaced reads a TIFF header/IFD walk makes (byte-order magic,
/// entry counts, tag values, `next_image` offsets) almost always land
/// inside one already-fetched window instead of each triggering its own
/// round trip; small enough that a single miss stays a bounded, modest
/// fetch rather than approaching a whole-file download. Not tuned against
/// any specific file — a reasonably laid out COG's header/IFD chain fits
/// inside a handful of multiples of this.
const WINDOW_BYTES: u64 = 64 * 1024;

/// One remote GeoTIFF's connection details — built once by
/// `CogDriverFactory::build` (`driver.rs`) and cloned into every
/// [`HttpRangeReader`] this source opens. `Client` is internally
/// `Arc`-backed, so cloning shares one connection pool across every request
/// a collection ever makes rather than dialing fresh each time.
#[derive(Clone, Debug)]
pub struct RemoteCogSource {
    pub client: Client,
    pub url: Url,
}

/// A `Read + Seek` view over one [`RemoteCogSource`], backed by at most one
/// `WINDOW_BYTES`-sized buffer at a time — bounded memory, no cache kept
/// across separate reader instances (see `reader.rs`'s own doc for why this
/// crate re-opens a fresh reader per request, the same choice it already
/// makes for a local file, and this crate's design notes for the decision
/// not to add a byte-range cache on top of that).
#[derive(Debug)]
pub struct HttpRangeReader {
    source: RemoteCogSource,
    handle: Handle,
    len: u64,
    pos: u64,
    window: Option<(u64, Vec<u8>)>,
}

impl HttpRangeReader {
    /// Opens `source`, proving up front that it serves ranged GET requests
    /// — a `206 Partial Content` response with a well-formed `Content-
    /// Range` total. A source that instead answers `200 OK` with the full
    /// body (ignored the `Range` header) is refused here as
    /// [`CogError::RangeUnsupported`], never read from; any other
    /// non-`206` status, or a transport failure, is
    /// [`CogError::RemoteOpen`]. The probe response's own bytes seed the
    /// first window, so this doubles as the reader's initial buffer fill
    /// rather than a wasted extra round trip. Must run inside a `tokio::
    /// task::spawn_blocking` context (see this module's own doc) — that's
    /// where [`Handle::current`] finds the runtime it bridges into.
    pub fn open(source: RemoteCogSource) -> Result<Self, CogError> {
        let handle = Handle::current();
        let (len, bytes) = handle.block_on(async {
            let response = send_range(&source, 0, WINDOW_BYTES - 1).await?;
            let status = response.status();
            if status == StatusCode::OK {
                return Err(CogError::RangeUnsupported {
                    url: source.url.to_string(),
                    status: status.to_string(),
                });
            }
            if status != StatusCode::PARTIAL_CONTENT {
                return Err(CogError::RemoteOpen {
                    url: source.url.to_string(),
                    message: format!("unexpected HTTP status {status}"),
                });
            }
            let len = total_length_from_content_range(&response, &source.url)?;
            let bytes = read_bounded_body(response, WINDOW_BYTES)
                .await
                .map_err(|error| CogError::RemoteOpen {
                    url: source.url.to_string(),
                    message: error.to_string(),
                })?;
            Ok((len, bytes))
        })?;
        Ok(Self {
            source,
            handle,
            len,
            pos: 0,
            window: Some((0, bytes)),
        })
    }

    /// Makes sure the current window covers `[pos, pos + want)`, fetching a
    /// fresh one (discarding whatever was buffered before — only one
    /// window is ever held at a time) when it doesn't. The fetched span is
    /// `max(want, WINDOW_BYTES)`, clamped to the file's real remaining
    /// length: small, scattered reads (the header/IFD walk) coalesce onto
    /// one `WINDOW_BYTES` fetch; a single read already bigger than that
    /// (a tile chunk) fetches exactly what it asked for, never more.
    fn ensure_window(&mut self, want: usize) -> io::Result<()> {
        if self.pos >= self.len {
            return Ok(());
        }
        if let Some((start, data)) = &self.window {
            let end = start + data.len() as u64;
            if self.pos >= *start && self.pos + want as u64 <= end {
                return Ok(());
            }
        }
        let remaining = self.len - self.pos;
        let fetch_len = (want as u64).max(WINDOW_BYTES).min(remaining);
        let end = self.pos + fetch_len - 1;
        let pos = self.pos;
        let source = self.source.clone();
        let bytes = self.handle.block_on(async move {
            let response = send_range(&source, pos, end)
                .await
                .map_err(io::Error::other)?;
            if response.status() != StatusCode::PARTIAL_CONTENT {
                return Err(io::Error::other(format!(
                    "remote source '{}' returned HTTP {} for a ranged read at offset {pos}",
                    source.url,
                    response.status()
                )));
            }
            read_bounded_body(response, fetch_len)
                .await
                .map_err(io::Error::other)
        })?;
        self.window = Some((self.pos, bytes));
        Ok(())
    }
}

impl Read for HttpRangeReader {
    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
        if buf.is_empty() || self.pos >= self.len {
            return Ok(0);
        }
        self.ensure_window(buf.len())?;
        let (start, data) = self
            .window
            .as_ref()
            .expect("ensure_window always leaves a window filled once pos < len");
        let offset = (self.pos - start) as usize;
        let available = data.len().saturating_sub(offset);
        let n = available.min(buf.len());
        buf[..n].copy_from_slice(&data[offset..offset + n]);
        self.pos += n as u64;
        Ok(n)
    }
}

impl Seek for HttpRangeReader {
    fn seek(&mut self, pos: SeekFrom) -> io::Result<u64> {
        let new_pos = match pos {
            SeekFrom::Start(offset) => offset as i64,
            SeekFrom::End(offset) => self.len as i64 + offset,
            SeekFrom::Current(offset) => self.pos as i64 + offset,
        };
        if new_pos < 0 {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "seek to a negative position",
            ));
        }
        self.pos = new_pos as u64;
        Ok(self.pos)
    }
}

async fn send_range(source: &RemoteCogSource, start: u64, end: u64) -> Result<Response, CogError> {
    source
        .client
        .get(source.url.clone())
        .header(RANGE, format!("bytes={start}-{end}"))
        .send()
        .await
        .map_err(|error| CogError::RemoteOpen {
            url: source.url.to_string(),
            message: error.to_string(),
        })
}

/// Reads at most `cap` bytes of `response`'s body — bounded regardless of
/// what the server actually sends, so a misbehaving or malicious remote
/// (ignoring the requested range's length) can never make a single fetch
/// balloon past the range this reader itself asked for.
async fn read_bounded_body(mut response: Response, cap: u64) -> Result<Vec<u8>, reqwest::Error> {
    let mut buf = Vec::new();
    while (buf.len() as u64) < cap {
        let Some(chunk) = response.chunk().await? else {
            break;
        };
        buf.extend_from_slice(&chunk);
    }
    buf.truncate(cap as usize);
    Ok(buf)
}

/// Reads the `Content-Range` header off a `206` response and hands it to
/// [`parse_content_range_total`], turning a missing header or an unparsable
/// one into a named [`CogError::RemoteOpen`].
fn total_length_from_content_range(response: &Response, url: &Url) -> Result<u64, CogError> {
    let header = response
        .headers()
        .get(CONTENT_RANGE)
        .and_then(|value| value.to_str().ok())
        .ok_or_else(|| CogError::RemoteOpen {
            url: url.to_string(),
            message: "206 response carried no Content-Range header".to_string(),
        })?;
    parse_content_range_total(header).ok_or_else(|| CogError::RemoteOpen {
        url: url.to_string(),
        message: format!("could not parse a total length from Content-Range '{header}'"),
    })
}

/// Parses the `total` half of a `Content-Range: bytes start-end/total`
/// header value. `total` must be a concrete number — a server replying with
/// the unknown-length placeholder (`bytes start-end/*`) gives this reader
/// no way to bound `Seek`/window math, so `None` covers that case the same
/// as a header this crate doesn't otherwise recognize.
fn parse_content_range_total(header: &str) -> Option<u64> {
    header
        .rsplit('/')
        .next()
        .filter(|total| *total != "*")
        .and_then(|total| total.parse::<u64>().ok())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::test_support::{test_client, MockServer};

    /// Every test here drives `HttpRangeReader` from inside
    /// `spawn_blocking`, the same contract production code is bound to
    /// (this module's own doc) — calling it directly from an async test
    /// body would try to `Handle::block_on` a runtime from a thread that
    /// runtime already owns, which panics.
    async fn in_blocking<T: Send + 'static>(f: impl FnOnce() -> T + Send + 'static) -> T {
        tokio::task::spawn_blocking(f).await.unwrap()
    }

    #[tokio::test]
    async fn open_reads_the_probe_window_and_the_body_round_trips() {
        let body: Vec<u8> = (0..2_000u32).map(|i| (i % 251) as u8).collect();
        let server = MockServer::range_aware(body.clone());
        let source = RemoteCogSource {
            client: test_client(),
            url: server.url("/f"),
        };
        let got = in_blocking(move || {
            let mut reader = HttpRangeReader::open(source).unwrap();
            let mut got = vec![0u8; 2_000];
            reader.read_exact(&mut got).unwrap();
            got
        })
        .await;
        assert_eq!(got, body);
    }

    #[tokio::test]
    async fn a_source_that_ignores_range_is_refused_without_reading_the_body() {
        let body = vec![0u8; 10];
        let server = MockServer::ignoring_range(body);
        let source = RemoteCogSource {
            client: test_client(),
            url: server.url("/f"),
        };
        let error = in_blocking(move || HttpRangeReader::open(source).unwrap_err()).await;
        assert!(
            matches!(error, CogError::RangeUnsupported { .. }),
            "expected RangeUnsupported, got {error:?}"
        );
    }

    #[tokio::test]
    async fn reads_scattered_inside_the_probed_window_cost_no_extra_requests() {
        let body: Vec<u8> = (0..2_000u32).map(|i| (i % 251) as u8).collect();
        let server = MockServer::range_aware(body);
        let source = RemoteCogSource {
            client: test_client(),
            url: server.url("/f"),
        };
        in_blocking(move || {
            let mut reader = HttpRangeReader::open(source).unwrap();
            let mut small = [0u8; 4];
            reader.seek(SeekFrom::Start(500)).unwrap();
            reader.read_exact(&mut small).unwrap();
            reader.seek(SeekFrom::Start(1000)).unwrap();
            reader.read_exact(&mut small).unwrap();
        })
        .await;
        assert_eq!(
            server.request_count(),
            1,
            "small reads already covered by the probed window must not issue requests beyond the open-time probe"
        );
    }

    #[tokio::test]
    async fn a_read_beyond_the_window_issues_exactly_one_more_request() {
        let body = vec![9u8; (WINDOW_BYTES * 3) as usize];
        let server = MockServer::range_aware(body);
        let source = RemoteCogSource {
            client: test_client(),
            url: server.url("/f"),
        };
        in_blocking(move || {
            let mut reader = HttpRangeReader::open(source).unwrap();
            reader.seek(SeekFrom::Start(WINDOW_BYTES + 10)).unwrap();
            let mut buf = [0u8; 4];
            reader.read_exact(&mut buf).unwrap();
        })
        .await;
        assert_eq!(
            server.request_count(),
            2,
            "one open-time probe plus one follow-up fetch"
        );
    }

    #[tokio::test]
    async fn a_read_larger_than_the_window_fetches_exactly_its_own_size() {
        let body = vec![3u8; (WINDOW_BYTES * 4) as usize];
        let server = MockServer::range_aware(body);
        let source = RemoteCogSource {
            client: test_client(),
            url: server.url("/f"),
        };
        let big = in_blocking(move || {
            let mut reader = HttpRangeReader::open(source).unwrap();
            let big_len = (WINDOW_BYTES * 2) as usize;
            let mut big = vec![0u8; big_len];
            reader.seek(SeekFrom::Start(WINDOW_BYTES)).unwrap();
            reader.read_exact(&mut big).unwrap();
            big
        })
        .await;
        assert!(big.iter().all(|&b| b == 3));
    }

    #[test]
    fn parse_content_range_total_reads_a_well_formed_header() {
        assert_eq!(
            parse_content_range_total("bytes 0-65535/200000"),
            Some(200_000)
        );
    }

    #[test]
    fn parse_content_range_total_rejects_an_unknown_total() {
        assert_eq!(parse_content_range_total("bytes 0-65535/*"), None);
    }

    #[test]
    fn parse_content_range_total_rejects_garbage() {
        assert_eq!(parse_content_range_total("nonsense"), None);
    }

    #[tokio::test]
    async fn an_unknown_total_length_is_refused() {
        let body = vec![1u8; 10];
        let server = MockServer::range_aware_with_unknown_total(body);
        let source = RemoteCogSource {
            client: test_client(),
            url: server.url("/f"),
        };
        let error = in_blocking(move || HttpRangeReader::open(source).unwrap_err()).await;
        assert!(
            matches!(error, CogError::RemoteOpen { .. }),
            "expected RemoteOpen, got {error:?}"
        );
    }
}
