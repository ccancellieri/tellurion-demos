//! Request correlation (`#189`): accept or mint an `X-Request-ID`, echo it on
//! the response, and stamp it on the request's trace span so every log line a
//! request produces — including the `event=slow_request` diagnostic — carries
//! one id a client or proxy can quote back.
//!
//! The middleware sits outermost, outside even `observe_request`: a minted id
//! must already be on the request when the observation layer captures it for
//! slow-request events, and the echo must survive on responses synthesized by
//! load-shed and timeout, which never reach an inner layer.
//!
//! An inbound id is honored only when it is short, visible ASCII. Anything
//! else — absent, oversized, control bytes, non-ASCII — is replaced by a
//! freshly minted UUID rather than rejected: correlation is a diagnostic aid,
//! never a reason to fail a request, and echoing arbitrary client bytes into
//! response headers and structured logs is exactly the injection surface the
//! validation exists to close.

use axum::body::Body;
use axum::extract::Request;
use axum::http::{HeaderName, HeaderValue};
use axum::middleware::Next;
use axum::response::Response;
use tracing::Span;

pub const REQUEST_ID_HEADER: HeaderName = HeaderName::from_static("x-request-id");

/// Longest inbound id honored verbatim. Generous enough for every tracing
/// scheme observed in the wild (UUIDs, W3C traceparent, load-balancer ids),
/// small enough that a hostile header can't bloat every downstream log line.
const MAX_INBOUND_LEN: usize = 128;

fn is_honored(value: &HeaderValue) -> bool {
    let bytes = value.as_bytes();
    !bytes.is_empty()
        && bytes.len() <= MAX_INBOUND_LEN
        && bytes.iter().all(|byte| byte.is_ascii_graphic())
}

pub async fn propagate_request_id(mut request: Request, next: Next) -> Response {
    let id = match request.headers().get(&REQUEST_ID_HEADER) {
        Some(value) if is_honored(value) => value.clone(),
        _ => {
            let minted = uuid::Uuid::new_v4().to_string();
            // A UUID's hyphenated form is always a valid header value.
            let minted = HeaderValue::from_str(&minted).expect("uuid is valid header value");
            request
                .headers_mut()
                .insert(&REQUEST_ID_HEADER, minted.clone());
            minted
        }
    };
    let mut response = next.run(request).await;
    response.headers_mut().insert(&REQUEST_ID_HEADER, id);
    response
}

/// `TraceLayer` span factory: the default `DefaultMakeSpan` fields plus
/// `request_id`, which [`propagate_request_id`] has already guaranteed is
/// present and clean by the time this layer runs.
pub fn trace_span(request: &axum::http::Request<Body>) -> Span {
    let request_id = request
        .headers()
        .get(&REQUEST_ID_HEADER)
        .and_then(|value| value.to_str().ok())
        .unwrap_or("unknown");
    tracing::info_span!(
        "request",
        method = %request.method(),
        uri = %request.uri(),
        version = ?request.version(),
        request_id,
    )
}

/// The id `observe_request` folds into `event=slow_request`, captured before
/// the inner layers consume the request.
pub fn current_id(headers: &axum::http::HeaderMap) -> String {
    headers
        .get(&REQUEST_ID_HEADER)
        .and_then(|value| value.to_str().ok())
        .unwrap_or("unknown")
        .to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn honors_a_clean_inbound_id() {
        assert!(is_honored(&HeaderValue::from_static("req-abc.123_DEF")));
    }

    #[test]
    fn rejects_empty_oversized_and_non_graphic_ids() {
        assert!(!is_honored(&HeaderValue::from_static("")));
        let oversized = "a".repeat(MAX_INBOUND_LEN + 1);
        assert!(!is_honored(&HeaderValue::from_str(&oversized).unwrap()));
        assert!(!is_honored(&HeaderValue::from_static("has space")));
        assert!(!is_honored(&HeaderValue::from_bytes(b"tab\there").unwrap()));
    }
}
