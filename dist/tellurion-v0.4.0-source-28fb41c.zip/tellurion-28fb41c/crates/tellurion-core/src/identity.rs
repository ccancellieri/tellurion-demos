//! Authentication identities shared by the control plane and request path.
//!
//! Issuer selection deliberately uses an unverified JWT payload only as a
//! lookup key into a preconfigured set. No discovery request is made until
//! that exact issuer is already trusted; the selected validator then verifies
//! the signature and all registered claims before any identity is returned.

use std::collections::HashMap;
use std::sync::Arc;

use serde_json::Value;

use crate::auth::{OidcError, OidcValidator};
use crate::config::OidcConfig;
use crate::control_model::PrincipalIdentity;

#[derive(Debug, Clone, PartialEq)]
pub struct AuthenticatedSubject {
    pub principal: PrincipalIdentity,
    pub claims: HashMap<String, Value>,
}

/// A data-free authentication error. It can be logged or rendered in tests
/// without risking disclosure of the bearer token.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IdentityError {
    Malformed,
    UnknownIssuer,
    InvalidToken,
    MissingSubject,
}

pub struct TrustedIssuerSet {
    validators: HashMap<String, Arc<OidcValidator>>,
}

impl TrustedIssuerSet {
    pub fn new(configs: impl IntoIterator<Item = OidcConfig>) -> Self {
        let validators = configs
            .into_iter()
            .map(|config| {
                let issuer = config.issuer.clone();
                (issuer, Arc::new(OidcValidator::new(config)))
            })
            .collect();
        Self { validators }
    }

    pub fn is_empty(&self) -> bool {
        self.validators.is_empty()
    }

    pub async fn authenticate(&self, token: &str) -> Result<AuthenticatedSubject, IdentityError> {
        let unverified = jsonwebtoken::dangerous::insecure_decode::<Value>(token)
            .map_err(|_| IdentityError::Malformed)?;
        let issuer = unverified
            .claims
            .get("iss")
            .and_then(Value::as_str)
            .ok_or(IdentityError::UnknownIssuer)?;
        let validator = self
            .validators
            .get(issuer)
            .ok_or(IdentityError::UnknownIssuer)?;

        let claims_value = validator
            .decode_claims(token)
            .await
            .map_err(IdentityError::from)?;
        let subject = claims_value
            .get("sub")
            .and_then(Value::as_str)
            .filter(|subject| !subject.is_empty())
            .ok_or(IdentityError::MissingSubject)?;
        let claims = claims_value
            .as_object()
            .cloned()
            .unwrap_or_default()
            .into_iter()
            .collect();
        Ok(AuthenticatedSubject {
            principal: PrincipalIdentity {
                issuer: issuer.to_string(),
                subject: subject.to_string(),
            },
            claims,
        })
    }
}

impl From<OidcError> for IdentityError {
    fn from(_: OidcError) -> Self {
        Self::InvalidToken
    }
}
