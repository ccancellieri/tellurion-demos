//! Normalizes polygon ring winding on the way into `geozero::mvt::MvtWriter`
//! — this driver's own encode-time fix for `#100`.
//!
//! `MvtWriter::xy` (`mvt_writer.rs`) scales an incoming world-space
//! coordinate and flips its y axis into tile space (`extent - y`), but never
//! touches vertex *order* — it assumes whatever ring order it receives
//! already matches the MVT spec's own winding rule (exterior clockwise,
//! interior counter-clockwise, in the tile's coordinate space). A y-flip
//! reverses a ring's signed area, so a ring that is wound according to the
//! OGC Simple Features / GeoJSON convention most real-world tools (ogr2ogr
//! included) actually follow — exterior counter-clockwise, interior
//! clockwise, in the *source* coordinate space — lands on the wrong side of
//! that rule once flipped. Fed straight through, such a feature's very first
//! ring reads back, to geozero's own MVT reader (`mvt_reader.rs`'s
//! `is_area_positive`), as an interior ring with no exterior yet to attach
//! to, and the tile fails to decode.
//!
//! [`WindingNormalizer`] sits between a geometry source's `process_geom` and
//! the real `MvtWriter`, buffering each polygon ring's vertices as they
//! stream through and reordering them — if needed — so the *encoded* tile
//! always carries the spec's winding, regardless of which way the source
//! happened to wind its rings. Ring role (exterior vs. hole) is read
//! straight off the geometry's own structure (`GeomProcessor::polygon_begin`
//! numbers rings `0, 1, 2, ...` in encounter order, exterior always `0`) —
//! never guessed at from a signed area the way decoding has to — which is
//! exactly what lets this *fix* the winding instead of merely detecting it.

use geozero::error::Result;
use geozero::mvt::MvtWriter;
use geozero::GeomProcessor;

/// Twice the shoelace-formula signed area of a closed ring, in whatever
/// coordinate space its points are given: positive for the conventional
/// counter-clockwise orientation, negative for clockwise. Callers only ever
/// compare its sign, so the factor of two never matters, and zero (a
/// degenerate ring — too few distinct points, or a self-retracing line) is a
/// legitimate, deliberately unresolved answer; see [`WindingNormalizer::
/// linestring_end`].
fn signed_area(points: &[(f64, f64)]) -> f64 {
    let mut area = 0.0;
    for pair in points.windows(2) {
        let (x0, y0) = pair[0];
        let (x1, y1) = pair[1];
        area += x0 * y1 - x1 * y0;
    }
    area
}

/// One polygon ring's vertices, buffered while they stream through, plus its
/// role-determining position (`0` = exterior, `1..` = a hole) among the
/// enclosing `polygon_begin`'s rings.
struct RingBuffer {
    idx: usize,
    points: Vec<(f64, f64)>,
}

/// See this module's own top-level doc. Wraps `inner`, the real
/// `MvtWriter`, forwarding every event unchanged except polygon rings, which
/// are buffered in [`linestring_begin`][GeomProcessor::linestring_begin] and
/// replayed — in their original order, or reversed — from
/// [`linestring_end`][GeomProcessor::linestring_end].
pub(crate) struct WindingNormalizer<'a> {
    inner: &'a mut MvtWriter,
    in_polygon: bool,
    ring: Option<RingBuffer>,
}

impl<'a> WindingNormalizer<'a> {
    pub(crate) fn new(inner: &'a mut MvtWriter) -> Self {
        WindingNormalizer {
            inner,
            in_polygon: false,
            ring: None,
        }
    }
}

impl GeomProcessor for WindingNormalizer<'_> {
    fn xy(&mut self, x: f64, y: f64, idx: usize) -> Result<()> {
        if let Some(ring) = &mut self.ring {
            ring.points.push((x, y));
            Ok(())
        } else {
            self.inner.xy(x, y, idx)
        }
    }

    fn point_begin(&mut self, idx: usize) -> Result<()> {
        self.inner.point_begin(idx)
    }

    fn point_end(&mut self, idx: usize) -> Result<()> {
        self.inner.point_end(idx)
    }

    fn multipoint_begin(&mut self, size: usize, idx: usize) -> Result<()> {
        self.inner.multipoint_begin(size, idx)
    }

    fn multipoint_end(&mut self, idx: usize) -> Result<()> {
        self.inner.multipoint_end(idx)
    }

    fn multilinestring_begin(&mut self, size: usize, idx: usize) -> Result<()> {
        self.inner.multilinestring_begin(size, idx)
    }

    fn multilinestring_end(&mut self, idx: usize) -> Result<()> {
        self.inner.multilinestring_end(idx)
    }

    fn linestring_begin(&mut self, tagged: bool, size: usize, idx: usize) -> Result<()> {
        // Only a polygon ring (`tagged == false` *and* inside a `polygon_begin`/
        // `polygon_end` pair — a `MultiLineString` component is also untagged,
        // but has no orientation to normalize) is buffered; every other
        // `LineString` passes straight through.
        if !tagged && self.in_polygon {
            self.ring = Some(RingBuffer {
                idx,
                points: Vec::with_capacity(size),
            });
            Ok(())
        } else {
            self.inner.linestring_begin(tagged, size, idx)
        }
    }

    fn linestring_end(&mut self, tagged: bool, idx: usize) -> Result<()> {
        let Some(ring) = self.ring.take() else {
            return self.inner.linestring_end(tagged, idx);
        };
        let mut points = ring.points;

        // Ring 0 is always the exterior, every later ring a hole
        // (`GeomProcessor::polygon_begin`'s own doc). `MvtWriter`'s y-flip
        // reverses signed area, so the world-space order handed to it must
        // already be the mirror image of the spec's tile-space rule: an
        // exterior ring needs negative signed area here so it comes out
        // positive (the spec's clockwise exterior) once flipped; a hole
        // needs positive here so it comes out negative (counter-clockwise)
        // there. A perfectly degenerate ring (zero area) has no orientation
        // to fix and is passed through exactly as given rather than guessed
        // at — `MvtWriter` itself already refuses a ring with too few
        // coordinates to be valid (`MvtError::TooFewCoordinates`), which
        // this leaves untouched.
        let is_exterior = ring.idx == 0;
        let area = signed_area(&points);
        let needs_reversal = if is_exterior { area > 0.0 } else { area < 0.0 };
        if needs_reversal {
            points.reverse();
        }

        let size = points.len();
        self.inner.linestring_begin(false, size, ring.idx)?;
        for (i, (x, y)) in points.into_iter().enumerate() {
            self.inner.xy(x, y, i)?;
        }
        self.inner.linestring_end(false, ring.idx)
    }

    fn polygon_begin(&mut self, tagged: bool, size: usize, idx: usize) -> Result<()> {
        self.in_polygon = true;
        self.inner.polygon_begin(tagged, size, idx)
    }

    fn polygon_end(&mut self, tagged: bool, idx: usize) -> Result<()> {
        self.in_polygon = false;
        self.inner.polygon_end(tagged, idx)
    }

    fn multipolygon_begin(&mut self, size: usize, idx: usize) -> Result<()> {
        self.inner.multipolygon_begin(size, idx)
    }

    fn multipolygon_end(&mut self, idx: usize) -> Result<()> {
        self.inner.multipolygon_end(idx)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use geozero::mvt::{Message, Tile};
    use geozero::FeatureProcessor;
    use geozero::GeozeroGeometry;
    use geozero::ProcessToJson;

    /// Drives `geojson` (a bare GeoJSON geometry object, whatever ring
    /// winding it uses) through a real, scaled `MvtWriter` — the same one
    /// `driver.rs`'s `mvt_tile_inner` builds, extent 10 over a `[0, 10] x
    /// [0, 10]` world-space square so every coordinate lands on an exact
    /// integer with no floating-point rounding to reason about — wrapped in
    /// [`WindingNormalizer`], then returns the resulting single-feature
    /// layer's GeoJSON re-decoded via geozero's own MVT reader. `scaled`
    /// (not `new_unscaled`) matters: only the scaled writer performs the
    /// y-flip this module exists to compensate for.
    fn encode_and_redecode(geojson: &serde_json::Value) -> Result<serde_json::Value> {
        let mut writer = MvtWriter::new(10, 0.0, 0.0, 10.0, 10.0).unwrap();
        writer.feature_begin(0)?;
        writer.geometry_begin()?;
        let text = geojson.to_string();
        geozero::geojson::GeoJson(&text).process_geom(&mut WindingNormalizer::new(&mut writer))?;
        writer.geometry_end()?;
        writer.feature_end(0)?;

        let layer = writer.layer("test");
        let bytes = Tile {
            layers: vec![layer],
        }
        .encode_to_vec();
        let mut decoded = Tile::decode(bytes.as_slice()).expect("valid MVT protobuf bytes");
        let mut decoded_layer = decoded.layers.remove(0);
        let json_text = decoded_layer.to_json()?;
        let feature_collection: serde_json::Value = serde_json::from_str(&json_text).unwrap();
        Ok(feature_collection["features"][0]["geometry"].clone())
    }

    /// The OGC Simple Features / GeoJSON convention: exterior ring
    /// counter-clockwise, hole clockwise — the winding real-world
    /// ogr2ogr-produced GeoPackages actually carry, and the opposite of what
    /// `MvtWriter`'s y-flip needs. Before this module existed, this exact
    /// shape's exterior ring read back to geozero's reader as an orphan
    /// hole and `layer.process`/`to_json` failed with `MvtError::
    /// GeometryFormat`.
    #[test]
    fn a_conventionally_wound_polygon_with_a_hole_decodes_without_a_ring_winding_error() {
        let geojson = serde_json::json!({
            "type": "Polygon",
            "coordinates": [
                // exterior, counter-clockwise
                [[1.0, 1.0], [9.0, 1.0], [9.0, 9.0], [1.0, 9.0], [1.0, 1.0]],
                // hole, clockwise
                [[3.0, 3.0], [3.0, 7.0], [7.0, 7.0], [7.0, 3.0], [3.0, 3.0]],
            ]
        });

        let decoded = encode_and_redecode(&geojson)
            .expect("a conventionally-wound exterior must not read back as an orphan hole");
        assert_eq!(decoded["type"], "Polygon");
        let rings = decoded["coordinates"].as_array().unwrap();
        assert_eq!(
            rings.len(),
            2,
            "both the exterior and the hole must survive"
        );
    }

    /// The same shape, already wound the way the *tile* needs it pre-flip
    /// (exterior clockwise, hole counter-clockwise) — must decode cleanly
    /// too: normalization must be a no-op for input that was already
    /// correct, not merely for the one convention this fix targets.
    #[test]
    fn a_polygon_already_wound_for_tile_space_still_decodes_correctly() {
        let geojson = serde_json::json!({
            "type": "Polygon",
            "coordinates": [
                [[1.0, 1.0], [1.0, 9.0], [9.0, 9.0], [9.0, 1.0], [1.0, 1.0]],
                [[3.0, 3.0], [7.0, 3.0], [7.0, 7.0], [3.0, 7.0], [3.0, 3.0]],
            ]
        });

        let decoded = encode_and_redecode(&geojson).expect("already-correct winding must decode");
        assert_eq!(decoded["type"], "Polygon");
        assert_eq!(decoded["coordinates"].as_array().unwrap().len(), 2);
    }

    /// A `MultiPolygon` with one plain polygon and one polygon with a hole —
    /// both conventionally wound — must decode back to exactly that shape:
    /// two polygons, the second carrying one interior ring, not two
    /// unrelated exteriors or a hole misattached to the wrong polygon.
    #[test]
    fn a_conventionally_wound_multipolygon_keeps_its_hole_attached_to_the_right_polygon() {
        let geojson = serde_json::json!({
            "type": "MultiPolygon",
            "coordinates": [
                [
                    [[0.0, 0.0], [2.0, 0.0], [2.0, 2.0], [0.0, 2.0], [0.0, 0.0]]
                ],
                [
                    [[4.0, 4.0], [9.0, 4.0], [9.0, 9.0], [4.0, 9.0], [4.0, 4.0]],
                    [[5.0, 5.0], [5.0, 8.0], [8.0, 8.0], [8.0, 5.0], [5.0, 5.0]],
                ]
            ]
        });

        let decoded = encode_and_redecode(&geojson).expect("must decode without a winding error");
        assert_eq!(decoded["type"], "MultiPolygon");
        let polygons = decoded["coordinates"].as_array().unwrap();
        assert_eq!(polygons.len(), 2, "both polygons must survive");
        assert_eq!(
            polygons[0].as_array().unwrap().len(),
            1,
            "the first polygon has no hole"
        );
        assert_eq!(
            polygons[1].as_array().unwrap().len(),
            2,
            "the second polygon's hole must stay attached to it, not become a stray exterior"
        );
    }

    #[test]
    fn signed_area_is_positive_for_counter_clockwise_and_negative_for_clockwise() {
        let ccw = [
            (0.0, 0.0),
            (10.0, 0.0),
            (10.0, 10.0),
            (0.0, 10.0),
            (0.0, 0.0),
        ];
        assert!(signed_area(&ccw) > 0.0);
        let cw: Vec<(f64, f64)> = ccw.iter().rev().copied().collect();
        assert!(signed_area(&cw) < 0.0);
    }
}
